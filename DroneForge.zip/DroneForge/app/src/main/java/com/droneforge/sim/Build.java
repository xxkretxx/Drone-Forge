package com.droneforge.sim;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.Random;

/** Complete state of the drone on the bench: mechanics, every solder joint, wiring and flight-controller settings. */
final class Build {
    // ---------------------------------------------------------------- motor positions (Betaflight numbering)
    /** 0 = M1 rear-right, 1 = M2 front-right, 2 = M3 rear-left, 3 = M4 front-left. x right, y towards the rear. */
    static final float[] MX = {1, 1, -1, -1}, MY = {1, -1, 1, -1};
    static final String[] POS_NAME = {"REAR RIGHT", "FRONT RIGHT", "REAR LEFT", "FRONT LEFT"};
    /** Default ("props in") Betaflight spin: true = clockwise seen from above. */
    static final boolean[] CW_DEFAULT = {true, false, false, true};

    // ---------------------------------------------------------------- FC pads (board unrotated, mm, 30.5 board)
    static final String[] FC_PAD = {"5V", "GND", "R1", "T1", "R2", "T2", "VBAT", "GND", "CAM", "VTX", "9V", "LED", "R3", "T3", "BZ+", "BZ-", "R4", "T4", "R5", "T5"};
    static final float[] FC_PX = {-16.3f, -16.3f, -16.3f, -16.3f, -16.3f, -16.3f, 16.3f, 16.3f, 16.3f, 16.3f, 16.3f, 16.3f, -6, -2, 2, 6, -9, -5, 5, 9};
    static final float[] FC_PY = {-9, -5.5f, -2, 1.5f, 5, 8.5f, -9, -5.5f, -2, 1.5f, 5, 8.5f, -16.3f, -16.3f, -16.3f, -16.3f, 16.3f, 16.3f, 16.3f, 16.3f};
    static final int P_5V = 0, P_GND1 = 1, P_R1 = 2, P_T1 = 3, P_R2 = 4, P_T2 = 5, P_VBAT = 6, P_GND2 = 7, P_CAM = 8, P_VTX = 9, P_9V = 10,
            P_LED = 11, P_R3 = 12, P_T3 = 13, P_BZP = 14, P_BZN = 15, P_R4 = 16, P_T4 = 17, P_R5 = 18, P_T5 = 19;

    /** Is this pad present on the given flight controller? */
    static boolean fcHasPad(Parts.Part fc, int pad) {
        if (fc == null) return false;
        if (pad >= P_R5) return fc.uarts >= 5;
        if (pad >= P_R4) return fc.uarts >= 4;
        if (pad == P_R3 || pad == P_T3) return fc.uarts >= 3;
        return true;
    }

    /** UART number of a pad (1..5), or 0. isTx true for Tn pads. */
    static int uartOf(int pad) {
        switch (pad) {
            case P_R1: case P_T1: return 1;
            case P_R2: case P_T2: return 2;
            case P_R3: case P_T3: return 3;
            case P_R4: case P_T4: return 4;
            case P_R5: case P_T5: return 5;
        }
        return 0;
    }

    static boolean isTx(int pad) {
        return pad == P_T1 || pad == P_T2 || pad == P_T3 || pad == P_T4 || pad == P_T5;
    }

    static boolean isRxPad(int pad) {
        return uartOf(pad) > 0 && !isTx(pad);
    }

    // ---------------------------------------------------------------- ESC pads
    /** Per motor: 3 phase pads along the side edge. Returns local (unrotated) coordinates in mm on a 30.5 board. */
    static float escPadX(int m, int w) {
        return MX[m] * 16.2f;
    }

    static float escPadY(int m, int w) {
        return MY[m] * (3.5f + w * 3.7f);
    }

    static final float BAT_PX = 5.5f, BAT_PY = 16.0f; // + at (-BAT_PX), - at (+BAT_PX)

    // ---------------------------------------------------------------- devices & their wires
    static final int DEV_RX = 0, DEV_CAM = 1, DEV_VTX = 2;
    static final String[][] DEV_WIRE = {{"5V", "GND", "TX", "RX"}, {"V+", "GND", "VIDEO"}, {"V+", "GND", "VIDEO", "SMARTAUDIO"}};
    static final int[][] DEV_WIRE_COL = {{0xFFE53935, 0xFF222222, 0xFFF5F5F5, 0xFF43A047}, {0xFFE53935, 0xFF222222, 0xFFFDD835},
            {0xFFE53935, 0xFF222222, 0xFFFDD835, 0xFFF5F5F5}};

    // ---------------------------------------------------------------- mechanical state
    int frame = -1;                 // item uid
    final int[] motor = {-1, -1, -1, -1};
    final int[][] screw = new int[4][4];   // hardware index (Parts.HW_*) or -1
    final float[][] torque = new float[4][4]; // 0..1.2 (stripped > 1)
    final boolean[] standoff = new boolean[4];
    final float[] standoffT = new float[4];
    int esc = -1, escRot;
    int fc = -1, fcRot;
    boolean harness;
    // motor wires
    final int[][] wireCut = new int[4][3];     // 0 uncut, 1 good, 2 too short, 3 long (cut sloppy)
    final float[][] mJoint = new float[4][3];  // -1 none, else quality 0..1
    final int[][] mFlag = new int[4][3];       // 0 ok, 1 cold, 2 bridge, 3 burnt pad
    final boolean[] motorParity = new boolean[4]; // depends on wire order: true = spins opposite to "normal"
    // power
    int pigtail = -1;
    final int[] pigPad = {-1, -1};              // [red wire, black wire] -> 0 '+' pad, 1 '-' pad
    final float[] pigJoint = {-1, -1};
    final int[] pigFlag = new int[2];
    int cap = -1;
    final int[] capPad = {-1, -1};              // [long leg (+), striped leg (-)]
    final float[] capJoint = {-1, -1};
    final int[] capFlag = new int[2];
    // devices
    final int[] dev = {-1, -1, -1};             // item uids
    final int[][] devPad = {{-1, -1, -1, -1}, {-1, -1, -1}, {-1, -1, -1, -1}};
    final float[][] devJoint = {{-1, -1, -1, -1}, {-1, -1, -1}, {-1, -1, -1, -1}};
    final int[][] devFlag = new int[3][4];
    final boolean[] devMounted = new boolean[3];
    int antenna = -1;
    boolean rxAntenna;
    int top = -1;
    final float[] topT = new float[4];
    final int[] topScrew = {-1, -1, -1, -1};
    // props
    final int[] propType = {-1, -1, -1, -1};    // -1 none, 0 CW, 1 CCW
    final float[] propNut = new float[4];
    int propsItem = -1;
    // ---------------------------------------------------------------- electronics / firmware state
    boolean fcDead, escDead, rxDead, camDead, vtxDead;
    final boolean[] motorDead = new boolean[4];
    boolean flashed;             // latest firmware flashed
    String fwTarget = "";        // what is on the chip ("" = factory firmware for its own target)
    boolean bricked;             // wrong target flashed
    boolean accelCal;
    int boardYaw;                // 0..3 (x90 deg)
    int serialRxUart;            // 0 = none
    int saUart;                  // SmartAudio uart, 0 = none
    int rxProvider;              // 0 none, 1 SBUS, 2 CRSF, 3 IBUS
    int escProto = 1;            // 0 PWM, 1 DSHOT300, 2 DSHOT600
    boolean reversed;            // "motor direction is reversed" (props out)
    final boolean[] dirRev = new boolean[4];   // per-motor ESC direction reversal
    final int[] remap = {0, 1, 2, 3};          // logical motor -> ESC output
    int armAux;                  // 0 none, 1..4
    int armLo = 1700, armHi = 2100;
    int vtxBand = 0, vtxChan = 1, vtxPower = 1;  // band index into Elec.BANDS, channel 1..8
    boolean vtxBandSet;
    boolean bound;
    String craftName = "";
    // tests performed
    boolean smokeTest, motorTest, videoTest, rxTest, propCheck;
    float vtxHotT;               // seconds powered without antenna
    int orderId = -1;

    Build() {
        clearAll();
    }

    void clearAll() {
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                screw[i][j] = -1;
                torque[i][j] = 0;
            }
            for (int w = 0; w < 3; w++) {
                wireCut[i][w] = 0;
                mJoint[i][w] = -1;
                mFlag[i][w] = 0;
            }
        }
        Random r = new Random();
        for (int i = 0; i < 4; i++) motorParity[i] = r.nextBoolean();
    }

    /** Firmware target name currently on the board. */
    String fwName(Parts.Part fcp) {
        return fwTarget.isEmpty() ? (fcp == null ? "-" : fcp.target) : fwTarget;
    }

    boolean hasFrame() {
        return frame >= 0;
    }

    int motorsPlaced() {
        int n = 0;
        for (int m : motor) if (m >= 0) n++;
        return n;
    }

    boolean motorScrewed(int m) {
        for (int j = 0; j < 4; j++) if (screw[m][j] < 0 || torque[m][j] < 0.6f) return false;
        return true;
    }

    boolean allMotorsScrewed() {
        for (int m = 0; m < 4; m++) if (motor[m] < 0 || !motorScrewed(m)) return false;
        return true;
    }

    boolean standoffsDone() {
        for (int i = 0; i < 4; i++) if (!standoff[i] || standoffT[i] < 0.6f) return false;
        return true;
    }

    boolean motorWiresDone() {
        for (int m = 0; m < 4; m++) for (int w = 0; w < 3; w++) if (mJoint[m][w] < 0) return false;
        return true;
    }

    boolean powerDone() {
        return pigtail >= 0 && pigJoint[0] >= 0 && pigJoint[1] >= 0;
    }

    boolean devWired(int d) {
        if (dev[d] < 0) return false;
        int n = DEV_WIRE[d].length;
        for (int w = 0; w < n; w++) {
            if (d == DEV_VTX && w == 3) continue; // SmartAudio optional
            if (devPad[d][w] < 0 || devJoint[d][w] < 0) return false;
        }
        return true;
    }

    boolean topDone() {
        if (top < 0) return false;
        for (int i = 0; i < 4; i++) if (topScrew[i] < 0 || topT[i] < 0.6f) return false;
        return true;
    }

    boolean propsDone() {
        for (int i = 0; i < 4; i++) if (propType[i] < 0 || propNut[i] < 0.6f) return false;
        return true;
    }

    boolean anyPropOn() {
        for (int i = 0; i < 4; i++) if (propType[i] >= 0) return true;
        return false;
    }

    /** Wires connected to a given FC pad (for drawing and shorts). */
    int wiresOnFcPad(int pad) {
        int n = 0;
        for (int d = 0; d < 3; d++) for (int w = 0; w < devPad[d].length; w++) if (devPad[d][w] == pad) n++;
        return n;
    }

    /** Rotation-aware transform of a board-local point (mm). rot in 90 degree steps clockwise. */
    static float rx(float x, float y, int rot) {
        switch (rot & 3) {
            case 1: return -y;
            case 2: return -x;
            case 3: return y;
            default: return x;
        }
    }

    static float ry(float x, float y, int rot) {
        switch (rot & 3) {
            case 1: return x;
            case 2: return -y;
            case 3: return -x;
            default: return y;
        }
    }

    // ---------------------------------------------------------------- serialisation
    void write(DataOutputStream o) throws IOException {
        o.writeInt(frame);
        for (int i = 0; i < 4; i++) {
            o.writeInt(motor[i]);
            for (int j = 0; j < 4; j++) {
                o.writeInt(screw[i][j]);
                o.writeFloat(torque[i][j]);
            }
            o.writeBoolean(standoff[i]);
            o.writeFloat(standoffT[i]);
            for (int w = 0; w < 3; w++) {
                o.writeInt(wireCut[i][w]);
                o.writeFloat(mJoint[i][w]);
                o.writeInt(mFlag[i][w]);
            }
            o.writeBoolean(motorParity[i]);
            o.writeBoolean(motorDead[i]);
            o.writeBoolean(dirRev[i]);
            o.writeInt(remap[i]);
            o.writeInt(propType[i]);
            o.writeFloat(propNut[i]);
            o.writeFloat(topT[i]);
            o.writeInt(topScrew[i]);
        }
        o.writeInt(esc);
        o.writeInt(escRot);
        o.writeInt(fc);
        o.writeInt(fcRot);
        o.writeBoolean(harness);
        o.writeInt(pigtail);
        for (int i = 0; i < 2; i++) {
            o.writeInt(pigPad[i]);
            o.writeFloat(pigJoint[i]);
            o.writeInt(pigFlag[i]);
            o.writeInt(capPad[i]);
            o.writeFloat(capJoint[i]);
            o.writeInt(capFlag[i]);
        }
        o.writeInt(cap);
        for (int d = 0; d < 3; d++) {
            o.writeInt(dev[d]);
            o.writeBoolean(devMounted[d]);
            for (int w = 0; w < devPad[d].length; w++) {
                o.writeInt(devPad[d][w]);
                o.writeFloat(devJoint[d][w]);
                o.writeInt(devFlag[d][w]);
            }
        }
        o.writeInt(antenna);
        o.writeBoolean(rxAntenna);
        o.writeInt(top);
        o.writeInt(propsItem);
        o.writeBoolean(fcDead);
        o.writeBoolean(escDead);
        o.writeBoolean(rxDead);
        o.writeBoolean(camDead);
        o.writeBoolean(vtxDead);
        o.writeBoolean(flashed);
        o.writeUTF(fwTarget);
        o.writeBoolean(bricked);
        o.writeBoolean(accelCal);
        o.writeInt(boardYaw);
        o.writeInt(serialRxUart);
        o.writeInt(saUart);
        o.writeInt(rxProvider);
        o.writeInt(escProto);
        o.writeBoolean(reversed);
        o.writeInt(armAux);
        o.writeInt(armLo);
        o.writeInt(armHi);
        o.writeInt(vtxBand);
        o.writeInt(vtxChan);
        o.writeInt(vtxPower);
        o.writeBoolean(vtxBandSet);
        o.writeBoolean(bound);
        o.writeUTF(craftName);
        o.writeBoolean(smokeTest);
        o.writeBoolean(motorTest);
        o.writeBoolean(videoTest);
        o.writeBoolean(rxTest);
        o.writeBoolean(propCheck);
        o.writeInt(orderId);
    }

    void read(DataInputStream in) throws IOException {
        frame = in.readInt();
        for (int i = 0; i < 4; i++) {
            motor[i] = in.readInt();
            for (int j = 0; j < 4; j++) {
                screw[i][j] = in.readInt();
                torque[i][j] = in.readFloat();
            }
            standoff[i] = in.readBoolean();
            standoffT[i] = in.readFloat();
            for (int w = 0; w < 3; w++) {
                wireCut[i][w] = in.readInt();
                mJoint[i][w] = in.readFloat();
                mFlag[i][w] = in.readInt();
            }
            motorParity[i] = in.readBoolean();
            motorDead[i] = in.readBoolean();
            dirRev[i] = in.readBoolean();
            remap[i] = in.readInt();
            propType[i] = in.readInt();
            propNut[i] = in.readFloat();
            topT[i] = in.readFloat();
            topScrew[i] = in.readInt();
        }
        esc = in.readInt();
        escRot = in.readInt();
        fc = in.readInt();
        fcRot = in.readInt();
        harness = in.readBoolean();
        pigtail = in.readInt();
        for (int i = 0; i < 2; i++) {
            pigPad[i] = in.readInt();
            pigJoint[i] = in.readFloat();
            pigFlag[i] = in.readInt();
            capPad[i] = in.readInt();
            capJoint[i] = in.readFloat();
            capFlag[i] = in.readInt();
        }
        cap = in.readInt();
        for (int d = 0; d < 3; d++) {
            dev[d] = in.readInt();
            devMounted[d] = in.readBoolean();
            for (int w = 0; w < devPad[d].length; w++) {
                devPad[d][w] = in.readInt();
                devJoint[d][w] = in.readFloat();
                devFlag[d][w] = in.readInt();
            }
        }
        antenna = in.readInt();
        rxAntenna = in.readBoolean();
        top = in.readInt();
        propsItem = in.readInt();
        fcDead = in.readBoolean();
        escDead = in.readBoolean();
        rxDead = in.readBoolean();
        camDead = in.readBoolean();
        vtxDead = in.readBoolean();
        flashed = in.readBoolean();
        fwTarget = in.readUTF();
        bricked = in.readBoolean();
        accelCal = in.readBoolean();
        boardYaw = in.readInt();
        serialRxUart = in.readInt();
        saUart = in.readInt();
        rxProvider = in.readInt();
        escProto = in.readInt();
        reversed = in.readBoolean();
        armAux = in.readInt();
        armLo = in.readInt();
        armHi = in.readInt();
        vtxBand = in.readInt();
        vtxChan = in.readInt();
        vtxPower = in.readInt();
        vtxBandSet = in.readBoolean();
        bound = in.readBoolean();
        craftName = in.readUTF();
        smokeTest = in.readBoolean();
        motorTest = in.readBoolean();
        videoTest = in.readBoolean();
        rxTest = in.readBoolean();
        propCheck = in.readBoolean();
        orderId = in.readInt();
    }
}
