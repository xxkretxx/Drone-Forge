package com.droneforge.sim;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

/** Top-down assembly bench: place parts, drive screws, trim wires, solder joints, wire the electronics and power up. */
final class BuildScreen extends Screen {
    // tools
    static final int T_HAND = 0, T_DRIVER = 1, T_IRON = 2, T_CUTTER = 3, T_METER = 4;
    static final String[] TOOL_NAME = {"HAND", "HEX DRIVER", "IRON", "CUTTERS", "METER"};
    // ids
    private static final int B_TOOL = 1, B_FLIP = 10, B_ZOOM = 11, B_ROT = 12, B_EXIT = 13, B_BAT = 14, B_USB = 15, B_BOOT = 16,
            B_TRAY = 100, B_PROP_CW = 300, B_PROP_CCW = 301, B_VTXBTN = 302;

    int tool = T_HAND;
    boolean flipped, zoomed;
    int placeRot;               // rotation for the next board you place
    boolean bootHeld;
    // camera
    private float cs = 2.2f, ccx = 800, ccy = 360;
    // drag from tray
    private Game.Item drag;
    private int dragProp = -1;  // 0 CW, 1 CCW
    private float dragX, dragY;
    private float trayScroll, trayY0, trayS0;
    private boolean trayScrolling;
    // wire routing
    private int selWireKind = -1, selWireA = -1, selWireB = -1; // kind: 0 device(d,w) 1 pigtail(w) 2 cap(leg)
    // hold mini-games
    private int holdKind = -1;  // 0 screw, 1 solder, 2 standoff, 3 top screw, 4 prop nut
    private int holdA, holdB, holdC;
    private float holdHeat, holdT;
    private int sizzle;
    private float holdX, holdY;
    // cutter mini-game
    private int cutM = -1, cutW = -1;
    private float cutPhase;
    // meter
    private int meterA = -1;
    private String meterMsg;
    private float meterT;
    private final Random rnd = new Random();

    BuildScreen(GameView v) {
        super(v);
    }

    Game gm() {
        return v.game;
    }

    Build b() {
        return v.game.build;
    }

    Parts.Part frame() {
        return gm().partOf(b().frame);
    }

    float baseScale() {
        Parts.Part f = frame();
        if (f == null) return 2.2f;
        return f.size == 7 ? 1.65f : f.size == 3 ? 3.0f : 2.2f;
    }

    /** Board scale: 30.5 mm stack boards are 36 mm, 20 mm boards 26 mm. */
    float boardK(Parts.Part board) {
        return board != null && board.mount == 20 ? 0.72f : 1f;
    }

    // ---------------------------------------------------------------- geometry (frame mm -> screen)
    float sx(float x) {
        return ccx + (flipped ? -x : x) * cs;
    }

    float sy(float y) {
        return ccy + y * cs;
    }

    float motorR() {
        Parts.Part f = frame();
        return (f == null ? 225 : f.size == 7 ? 295 : f.size == 3 ? 140 : 225) / 2f * 0.7071f;
    }

    float mx(int pos) {
        return Build.MX[pos] * motorR();
    }

    float my(int pos) {
        return Build.MY[pos] * motorR();
    }

    float frameL() {
        Parts.Part f = frame();
        return f == null ? 128 : f.size == 7 ? 150 : f.size == 3 ? 74 : 128;
    }

    // device placement (frame mm)
    float devX(int d) {
        return d == Build.DEV_RX ? -13 * stackK() : 0;
    }

    float devY(int d) {
        if (d == Build.DEV_CAM) return -frameL() / 2 + 6;
        if (d == Build.DEV_VTX) return 21 * stackK() + 17;
        return -34 * stackK();
    }

    float stackK() {
        Parts.Part f = frame();
        return f != null && f.mount == 20 ? 0.72f : 1f;
    }

    /** ESC pad position (frame mm) for ESC output k, phase w. */
    float escPx(int k, int w) {
        Parts.Part e = gm().partOf(b().esc);
        float kk = boardK(e);
        return Build.rx(Build.escPadX(k, w) * kk, Build.escPadY(k, w) * kk, b().escRot);
    }

    float escPy(int k, int w) {
        Parts.Part e = gm().partOf(b().esc);
        float kk = boardK(e);
        return Build.ry(Build.escPadX(k, w) * kk, Build.escPadY(k, w) * kk, b().escRot);
    }

    /** Battery pad (0 '+', 1 '-') position in frame mm. */
    float batPx(int pad) {
        Parts.Part e = gm().partOf(b().esc);
        float kk = boardK(e);
        float x = (pad == 0 ? -Build.BAT_PX : Build.BAT_PX) * kk, y = Build.BAT_PY * kk;
        return Build.rx(x, y, b().escRot);
    }

    float batPy(int pad) {
        Parts.Part e = gm().partOf(b().esc);
        float kk = boardK(e);
        float x = (pad == 0 ? -Build.BAT_PX : Build.BAT_PX) * kk, y = Build.BAT_PY * kk;
        return Build.ry(x, y, b().escRot);
    }

    float fcPx(int pad) {
        Parts.Part f = gm().partOf(b().fc);
        float kk = boardK(f);
        return Build.rx(Build.FC_PX[pad] * kk, Build.FC_PY[pad] * kk, b().fcRot);
    }

    float fcPy(int pad) {
        Parts.Part f = gm().partOf(b().fc);
        float kk = boardK(f);
        return Build.ry(Build.FC_PX[pad] * kk, Build.FC_PY[pad] * kk, b().fcRot);
    }

    /** Motor screw hole positions (frame mm, bottom view uses mirrored x automatically). */
    float holeX(int pos, int j) {
        Parts.Part f = frame();
        float hp = (f != null && f.m2 ? 4.5f : 8f);
        float dx = (j % 2 == 0 ? hp : -hp), dy = (j < 2 ? hp : -hp);
        return mx(pos) + dx;
    }

    float holeY(int pos, int j) {
        Parts.Part f = frame();
        float hp = (f != null && f.m2 ? 4.5f : 8f);
        float dy = (j < 2 ? hp : -hp);
        return my(pos) + dy;
    }

    float stackHole(int i, boolean y) {
        Parts.Part f = frame();
        float h = (f != null && f.mount == 20 ? 10 : 15.25f);
        if (!y) return (i % 2 == 0 ? h : -h);
        return (i < 2 ? h : -h);
    }

    float topHoleX(int i) {
        Parts.Part f = frame();
        float w = f == null ? 42 : (f.size == 7 ? 46 : f.size == 3 ? 30 : 42);
        return (i % 2 == 0 ? 1 : -1) * (w / 2 - 4);
    }

    float topHoleY(int i) {
        float L = frameL();
        return (i < 2 ? 1 : -1) * ((L - 20) / 2 - 4) + 6;
    }

    // ---------------------------------------------------------------- update
    @Override
    void enter() {
        cs = baseScale();
        ccx = 800;
        ccy = 360;
    }

    @Override
    void update(float dt) {
        float ts = zoomed && !flipped ? 8.0f : baseScale();
        float tcx = 800, tcy = zoomed && !flipped ? 360 - 4 * 8f : 360;
        float k = Math.min(1, dt * 7);
        cs += (ts - cs) * k;
        ccx += (tcx - ccx) * k;
        ccy += (tcy - ccy) * k;
        if (meterT > 0) meterT -= dt;
        if (cutM >= 0) cutPhase += dt * 1.3f;
        if (holdKind >= 0) updateHold(dt);
    }

    private float ironRate(float mass) {
        int temp = Elec.TEMPS[gm().ironTemp];
        float mult = gm().hasTool("tl_t12") ? 1.6f : 1f;
        return 0.6f * (temp - 220) / 100f * mult / mass;
    }

    private float ironMax(float mass) {
        int temp = Elec.TEMPS[gm().ironTemp];
        float mult = gm().hasTool("tl_t12") ? 1.35f : 1f;
        return Math.min(1.25f, (temp - 260) * mult / (mass * 42f));
    }

    private float padMass(int kind) {
        // 0 motor pad, 1 battery pad, 2 small FC pad, 3 cap leg
        switch (kind) {
            case 1: return 3.5f;
            case 2: return 0.8f;
            case 3: return 2.2f;
            default: return 1.4f;
        }
    }

    private int solderPadKind;

    private void updateHold(float dt) {
        holdT += dt;
        if (holdKind == 1) {
            float mass = padMass(solderPadKind);
            float max = ironMax(mass);
            float rate = ironRate(mass);
            holdHeat = Math.min(max + 0.02f, holdHeat + rate * dt * (holdHeat < max ? 1 : 0));
            if (holdHeat > 1.05f) releaseHold();
        } else {
            float rate = 0.45f + holdT * 0.5f;
            holdHeat += rate * dt;
            if (((int) (holdT * 10)) != ((int) ((holdT - dt) * 10))) v.sfx.play(Sfx.TAP, 0.15f);
            if (holdHeat > 1.15f) releaseHold();
        }
    }

    // ---------------------------------------------------------------- drawing
    @Override
    void draw(Canvas c) {
        float bs = cs / 2.2f * Math.max(1, Math.max((v.R - v.L) / 1600f, (v.Bm - v.T) / 720f));
        float bx0 = ccx - 800 * bs, by0 = ccy - 360 * bs;
        if (!v.res.draw(c, "bg_bench", bx0, by0, bx0 + 1600 * bs, by0 + 720 * bs, 255)) {
            g.p.setShader(null);
            g.p.setColor(0xFF2E5068);
            c.drawRect(v.L, v.T, v.R, v.Bm, g.p);
        }
        if (bs > 1.4f) {
            // the background gets blurry when zoomed - darken slightly to focus on the board
            g.p.setShader(null);
            g.p.setColor(0x33000000);
            c.drawRect(v.L, v.T, v.R, v.Bm, g.p);
        }
        drawBuild(c);
        drawBenchBattery(c);
        drawOverlay(c);
        drawTray(c);
        drawSteps(c);
        drawToolbar(c);
        if (drag != null || dragProp >= 0) drawDragged(c);
        v.drawHud(c, false);
    }

    private void drawBenchBattery(Canvas c) {
        Parts.Part bat = v.benchBatteryPart();
        if (bat == null || flipped) return;
        float x = sx(motorR() + 70), y = sy(-20);
        if (flipped) x = sx(-(motorR() + 70));
        v.res.sprite(c, bat.sprite, x, y, cs, 0, 255, false);
        if (b().pigtail >= 0) {
            // lead through the smoke stopper
            float px = sx(0), py = sy(frameL() / 2 + 30);
            int col = v.batteryOn ? (gm().smokeOn ? G.GREEN : G.YELLOW) : 0x88FFFFFF;
            g.s.setColor(0xFF111111);
            g.s.setStrokeWidth(Math.max(3, 3 * cs));
            g.path.reset();
            g.path.moveTo(x, y + 60 * cs * 0.5f);
            g.path.quadTo(x, py + 40 * cs, px, py);
            c.drawPath(g.path, g.s);
            if (gm().smokeOn && gm().hasTool("tl_smoke")) {
                float mxp = (x + px) / 2, myp = py + 22 * cs;
                g.r.set(mxp - 18 * cs, myp - 12 * cs, mxp + 18 * cs, myp + 12 * cs);
                g.p.setShader(null);
                g.p.setColor(0xFFB3261E);
                c.drawRoundRect(g.r, 4 * cs, 4 * cs, g.p);
                if (v.batteryOn || v.smokeRedT > 0) {
                    g.p.setColor(v.smokeRedT > 0 ? G.RED : G.GREEN);
                    c.drawCircle(mxp, myp, 4 * cs, g.p);
                }
            }
            if (v.batteryOn) {
                g.p.setColor(col);
                c.drawCircle(px, py, 5, g.p);
            }
        }
    }

    /** Draws the drone as currently built. Used by other screens too (simple = no pad details). */
    void drawDrone(Canvas c, float cx, float cy, float s, boolean simple) {
        float scs = cs, sccx = ccx, sccy = ccy;
        boolean sflip = flipped;
        cs = s;
        ccx = cx;
        ccy = cy;
        flipped = false;
        drawBuildInner(c, simple);
        cs = scs;
        ccx = sccx;
        ccy = sccy;
        flipped = sflip;
    }

    private void drawBuild(Canvas c) {
        drawBuildInner(c, false);
    }

    private void drawBuildInner(Canvas c, boolean simple) {
        Build b = b();
        Parts.Part fr = frame();
        if (fr == null) {
            if (!simple) {
                g.s.setColor(0x55FFFFFF);
                g.s.setStrokeWidth(2);
                g.r.set(sx(-90), sy(-90), sx(90), sy(90));
                c.drawRoundRect(g.r, 12, 12, g.s);
                g.text(c, "DRAG A FRAME FROM THE BENCH TRAY", sx(0), sy(0), 22, 0xAAFFFFFF, g.bold, Paint.Align.CENTER);
            }
            return;
        }
        // frame bottom plate
        v.res.sprite(c, fr.sprite, sx(0), sy(0), cs, 0, 255, flipped);
        if (flipped) {
            drawBottom(c);
            return;
        }
        // standoffs
        for (int i = 0; i < 4; i++) {
            if (!b.standoff[i]) continue;
            float x = sx(stackHole(i, false)), y = sy(stackHole(i, true));
            g.p.setShader(null);
            g.p.setColor(0xFFC9A227);
            c.drawCircle(x, y, 2.6f * cs, g.p);
            g.p.setColor(0xFF6B5410);
            c.drawCircle(x, y, 1.2f * cs, g.p);
        }
        // ESC
        Parts.Part esc = gm().partOf(b.esc);
        if (esc != null) drawBoard(c, false, esc, b.escRot, simple && b.fc >= 0);
        // motor wires (from motors to ESC pads or loose)
        for (int pos = 0; pos < 4; pos++) {
            if (b.motor[pos] < 0) continue;
            int out = esc != null ? Elec.outputAtPos(b, pos) : pos;
            for (int w = 0; w < 3; w++) drawMotorWire(c, pos, out, w, esc != null, simple);
        }
        // battery lead + cap
        drawPower(c, simple);
        // motors
        for (int pos = 0; pos < 4; pos++) {
            if (b.motor[pos] < 0) continue;
            Parts.Part mp = gm().partOf(b.motor[pos]);
            float rot = v.pc.config.rotA[pos];
            v.res.sprite(c, mp.sprite, sx(mx(pos)), sy(my(pos)), cs, rot, 255, false);
            if (b.motorDead[pos]) {
                g.p.setColor(0x88301010);
                c.drawCircle(sx(mx(pos)), sy(my(pos)), 12 * cs, g.p);
            }
        }
        // FC
        Parts.Part fc = gm().partOf(b.fc);
        if (fc != null) drawBoard(c, true, fc, b.fcRot, simple);
        // devices + wires
        for (int d = 0; d < 3; d++) drawDevice(c, d, simple);
        if (b.antenna >= 0) {
            v.res.sprite(c, "antenna", sx(devX(Build.DEV_VTX) + 9), sy(devY(Build.DEV_VTX) + 34), cs, 0, 255, false);
        }
        // top plate
        if (b.top >= 0) {
            Parts.Part tp = gm().partOf(b.top);
            v.res.sprite(c, "frametop" + fr.size, sx(0), sy(-6 + 6), cs, 0, 255, false);
            for (int i = 0; i < 4; i++) {
                if (b.topScrew[i] < 0) continue;
                drawScrewHead(c, sx(topHoleX(i)), sy(topHoleY(i)), b.topT[i]);
            }
            if (tp == null) g.text(c, "", 0, 0, 1, 0);
        }
        // props
        for (int pos = 0; pos < 4; pos++) {
            if (b.propType[pos] < 0) continue;
            Parts.Part pr = null;
            for (Game.Item it : gm().items) if (it.uid == b.propsItem) pr = it.p();
            String spr = pr != null ? pr.sprite : "prop" + fr.size;
            boolean ccw = b.propType[pos] == 1;
            v.res.sprite(c, spr, sx(mx(pos)), sy(my(pos)), cs, v.pc.config.rotA[pos] * 3, 235, ccw);
            g.p.setColor(0xFF20242A);
            c.drawCircle(sx(mx(pos)), sy(my(pos)), 4.2f * cs, g.p);
        }
    }

    private void drawBottom(Canvas c) {
        Build b = b();
        for (int pos = 0; pos < 4; pos++) {
            if (b.motor[pos] < 0) continue;
            Parts.Part mp = gm().partOf(b.motor[pos]);
            String spr = mp.sprite.replace("motor_", "motorb_");
            // the motor sits on top of the arm: seen from below only its base shows through the arm
            g.p.setShader(null);
            g.p.setColor(0x66000000);
            c.drawCircle(sx(mx(pos)), sy(my(pos)), 14.5f * cs, g.p);
            v.res.sprite(c, spr, sx(mx(pos)), sy(my(pos)), cs, 0, 200, true);
            for (int j = 0; j < 4; j++) {
                float x = sx(holeX(pos, j)), y = sy(holeY(pos, j));
                if (b.screw[pos][j] >= 0) drawScrewHead(c, x, y, b.torque[pos][j]);
                else {
                    g.p.setColor(0xFF050505);
                    c.drawCircle(x, y, 1.7f * cs, g.p);
                    g.s.setColor(G.alpha(G.CYAN, 120 + (int) (100 * Math.sin(v.time * 5))));
                    g.s.setStrokeWidth(2);
                    c.drawCircle(x, y, 3.2f * cs, g.s);
                }
            }
        }
        for (int i = 0; i < 4; i++) {
            float x = sx(stackHole(i, false)), y = sy(stackHole(i, true));
            if (b.standoff[i]) drawScrewHead(c, x, y, b.standoffT[i]);
            else {
                g.p.setColor(0xFF050505);
                c.drawCircle(x, y, 1.7f * cs, g.p);
                g.s.setColor(G.alpha(G.ORANGE, 120 + (int) (100 * Math.sin(v.time * 5))));
                g.s.setStrokeWidth(2);
                c.drawCircle(x, y, 3.2f * cs, g.s);
            }
        }
        g.text(c, "BOTTOM VIEW", 800, v.T + 110, 26, G.ORANGE, g.bold, Paint.Align.CENTER);
    }

    private void drawScrewHead(Canvas c, float x, float y, float torque) {
        float r = 2.6f * cs;
        g.p.setShader(new RadialGradient(x - r * 0.3f, y - r * 0.3f, r * 1.4f, 0xFF7A7F88, 0xFF22252A, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, r, g.p);
        g.p.setShader(null);
        g.p.setColor(0xFF0C0D0F);
        g.path.reset();
        for (int i = 0; i < 6; i++) {
            double a = i * Math.PI / 3 + torque * 3;
            float px = x + (float) Math.cos(a) * r * 0.42f, py = y + (float) Math.sin(a) * r * 0.42f;
            if (i == 0) g.path.moveTo(px, py);
            else g.path.lineTo(px, py);
        }
        g.path.close();
        c.drawPath(g.path, g.p);
        if (torque > 1f) {
            g.s.setColor(G.RED);
            g.s.setStrokeWidth(2);
            c.drawCircle(x, y, r + 3, g.s);
        } else if (torque < 0.6f) {
            g.s.setColor(G.YELLOW);
            g.s.setStrokeWidth(2);
            c.drawCircle(x, y, r + 3, g.s);
        }
    }

    // ---------------------------------------------------------------- boards (drawn procedurally for crisp pads)
    private void drawBoard(Canvas c, boolean isFc, Parts.Part part, int rot, boolean simple) {
        float kk = boardK(part);
        float half = 18 * kk;
        c.save();
        c.translate(sx(0), sy(0));
        c.rotate(rot * 90);
        float s = cs;
        g.r.set(-half * s, -half * s, half * s, half * s);
        g.p.setShader(null);
        g.p.setColor(0x66000000);
        c.drawRoundRect(g.r.left + 3, g.r.top + 5, g.r.right + 3, g.r.bottom + 5, 3 * s, 3 * s, g.p);
        g.p.setShader(new LinearGradient(0, -half * s, 0, half * s, isFc ? 0xFF15181C : 0xFF101A14, isFc ? 0xFF0B0D10 : 0xFF0A110D, Shader.TileMode.CLAMP));
        c.drawRoundRect(g.r, 3 * s, 3 * s, g.p);
        g.p.setShader(null);
        // mounting holes
        float hh = (part.mount == 20 ? 10 : 15.25f);
        for (int i = 0; i < 4; i++) {
            float x = (i % 2 == 0 ? hh : -hh) * s, y = (i < 2 ? hh : -hh) * s;
            g.p.setColor(0xFFC8A65A);
            c.drawCircle(x, y, 2.6f * s, g.p);
            g.p.setColor(0xFF1F2A33);
            c.drawCircle(x, y, 1.6f * s, g.p);
        }
        if (isFc) {
            // MCU + gyro + regulators
            c.save();
            c.rotate(45);
            g.p.setColor(0xFF2A2D33);
            c.drawRect(-4.5f * s * kk, -4.5f * s * kk, 4.5f * s * kk, 4.5f * s * kk, g.p);
            c.restore();
            g.p.setColor(0xFF33373E);
            c.drawRect(4 * s * kk, 4 * s * kk, 8 * s * kk, 8 * s * kk, g.p);
            for (int i = 0; i < 6; i++) {
                g.p.setColor(0xFF8B6B3D);
                c.drawRect((-10 + i * 3.5f) * s * kk, -10 * s * kk, (-8.8f + i * 3.5f) * s * kk, -9.2f * s * kk, g.p);
            }
            // USB-C + BOOT button
            g.p.setColor(0xFFB0B4BA);
            c.drawRoundRect(16.5f * s * kk, 9 * s * kk, 19.5f * s * kk, 15 * s * kk, 1 * s, 1 * s, g.p);
            g.p.setColor(0xFFEEEEEE);
            c.drawRect(9 * s * kk, 10 * s * kk, 12 * s * kk, 13 * s * kk, g.p);
            if (s > 4) {
                g.text(c, part.target, 0, 8.5f * s * kk, 1.9f * s * kk, 0xFFDDDDDD, g.mono, Paint.Align.CENTER);
                g.text(c, "BOOT", 10.5f * s * kk, 14.8f * s * kk, 1.4f * s * kk, 0xFFBBBBBB, g.bold, Paint.Align.CENTER);
            }
        } else {
            for (int k = 0; k < 4; k++) {
                for (int w = 0; w < 3; w++) {
                    float x = Build.escPadX(k, w) * kk, y = Build.escPadY(k, w) * kk;
                    g.p.setColor(0xFF2F3A33);
                    c.drawRect((x - 5.5f * Math.signum(x)) * s - 2.2f * s, y * s - 1.3f * s, (x - 5.5f * Math.signum(x)) * s + 2.2f * s, y * s + 1.3f * s, g.p);
                }
            }
            g.p.setColor(0xFF3A3F44);
            c.drawRect(-5 * s * kk, -15.5f * s * kk, 5 * s * kk, -12.5f * s * kk, g.p);
        }
        // arrow
        g.s.setColor(0xFFE6E6E6);
        g.s.setStrokeWidth(Math.max(1.2f, 0.45f * s));
        float ay = isFc ? -4 : -6;
        c.drawLine(-12 * s * kk, ay * s * kk, -12 * s * kk, (ay - 6) * s * kk, g.s);
        c.drawLine(-12 * s * kk, (ay - 6) * s * kk, -13.6f * s * kk, (ay - 4) * s * kk, g.s);
        c.drawLine(-12 * s * kk, (ay - 6) * s * kk, -10.4f * s * kk, (ay - 4) * s * kk, g.s);
        c.restore();
        if (simple) return;
        // pads in frame space (unrotated helpers already include rotation)
        Build b = b();
        if (isFc) {
            for (int p = 0; p < Build.FC_PAD.length; p++) {
                if (!Build.fcHasPad(part, p)) continue;
                pad(c, fcPx(p), fcPy(p), 1.4f * kk, 1.0f * kk, joinedFc(p));
                if (cs > 4) {
                    float lx = fcPx(p), ly = fcPy(p);
                    float ox = Math.abs(lx) > Math.abs(ly) ? -Math.signum(lx) * 3.3f * kk : 0, oy = Math.abs(ly) >= Math.abs(lx) ? -Math.signum(ly) * 2.6f * kk : 0;
                    g.text(c, Build.FC_PAD[p], sx(lx + ox), sy(ly + oy), 1.6f * cs * kk, 0xFFE0E0E0, g.mono, Paint.Align.CENTER);
                }
            }
        } else if (b.fc < 0) {
            for (int k = 0; k < 4; k++) for (int w = 0; w < 3; w++) {
                pad(c, escPx(k, w), escPy(k, w), 1.6f * kk, 1.2f * kk, b.mJoint[k][w] >= 0);
                if (cs > 4 && w == 1) {
                    float lx = escPx(k, w), ly = escPy(k, w);
                    g.text(c, "M" + (k + 1), sx(lx - Math.signum(lx) * 5 * kk), sy(ly), 1.8f * cs * kk, 0xFFE0E0E0, g.mono, Paint.Align.CENTER);
                }
            }
            for (int pd = 0; pd < 2; pd++) {
                pad(c, batPx(pd), batPy(pd), 3.0f * kk, 2.0f * kk, b.pigJoint[pd] >= 0);
                if (cs > 4) g.text(c, pd == 0 ? "+" : "-", sx(batPx(pd)), sy(batPy(pd) - 3.4f * kk), 2.6f * cs, pd == 0 ? 0xFFFF6B6B : 0xFFE0E0E0, g.bold, Paint.Align.CENTER);
            }
        }
    }

    private boolean joinedFc(int pad) {
        Build b = b();
        for (int d = 0; d < 3; d++) for (int w = 0; w < b.devPad[d].length; w++) if (b.devPad[d][w] == pad && b.devJoint[d][w] >= 0) return true;
        return false;
    }

    private void pad(Canvas c, float x, float y, float hw, float hh, boolean tinned) {
        float l = sx(x) - hw * cs, t = sy(y) - hh * cs, r = sx(x) + hw * cs, b = sy(y) + hh * cs;
        g.r.set(l, t, r, b);
        g.p.setShader(new LinearGradient(0, t, 0, b, tinned ? 0xFFE8E8EA : 0xFFF2C46A, tinned ? 0xFF9EA2A8 : 0xFFB8862E, Shader.TileMode.CLAMP));
        c.drawRoundRect(g.r, 0.5f * cs, 0.5f * cs, g.p);
        g.p.setShader(null);
    }

    private void joint(Canvas c, float x, float y, float r, float q, int flag) {
        float X = sx(x), Y = sy(y), R = r * cs;
        if (flag == 3) {
            g.p.setShader(null);
            g.p.setColor(0xFF3A2410);
            c.drawCircle(X, Y, R * 1.2f, g.p);
            g.p.setColor(0xFF120A05);
            c.drawCircle(X + R * 0.3f, Y, R * 0.6f, g.p);
            return;
        }
        int hi = q < 0.45f ? 0xFFA6A49C : 0xFFFFFFFF, lo = q < 0.45f ? 0xFF5E5C56 : 0xFF8C9096;
        g.p.setShader(new RadialGradient(X - R * 0.35f, Y - R * 0.35f, R * 1.3f, hi, lo, Shader.TileMode.CLAMP));
        c.drawCircle(X, Y, R, g.p);
        if (flag == 2) c.drawCircle(X + R * 1.2f, Y, R * 0.9f, g.p);
        g.p.setShader(null);
        if (q < 0.45f) {
            g.p.setColor(0x55000000);
            for (int i = 0; i < 5; i++) c.drawCircle(X + (i - 2) * R * 0.3f, Y + ((i * 7) % 3 - 1) * R * 0.3f, R * 0.12f, g.p);
        }
    }

    private void wire(Canvas c, float x0, float y0, float x1, float y1, int col, float thick, float bend) {
        float X0 = sx(x0), Y0 = sy(y0), X1 = sx(x1), Y1 = sy(y1);
        float mxp = (X0 + X1) / 2 + (Y1 - Y0) * bend, myp = (Y0 + Y1) / 2 - (X1 - X0) * bend;
        g.path.reset();
        g.path.moveTo(X0, Y0);
        g.path.quadTo(mxp, myp, X1, Y1);
        g.s.setColor(0xFF000000);
        g.s.setStrokeWidth(thick * cs + 2);
        c.drawPath(g.path, g.s);
        g.s.setColor(col);
        g.s.setStrokeWidth(thick * cs);
        c.drawPath(g.path, g.s);
        g.s.setColor(0x40FFFFFF);
        g.s.setStrokeWidth(Math.max(1, thick * cs * 0.3f));
        c.drawPath(g.path, g.s);
    }

    // ---------------------------------------------------------------- motor wires
    private static final int[] PHASE_COL = {0xFF2B2B2B, 0xFF2B2B2B, 0xFF2B2B2B};

    float wireEndX(int pos, int out, int w, boolean escOn) {
        if (escOn && (b().wireCut[pos][w] != 0)) return escPx(out, w);
        // untrimmed wires hang loose half way to the stack
        return mx(pos) * 0.42f + (w - 1) * 3;
    }

    float wireEndY(int pos, int out, int w, boolean escOn) {
        if (escOn && (b().wireCut[pos][w] != 0)) return escPy(out, w);
        return my(pos) * 0.42f + (w - 1) * 3;
    }

    private void drawMotorWire(Canvas c, int pos, int out, int w, boolean escOn, boolean simple) {
        Build b = b();
        float sxp = mx(pos) * 0.82f + (w - 1) * 1.6f, syp = my(pos) * 0.82f;
        float ex = wireEndX(pos, out, w, escOn), ey = wireEndY(pos, out, w, escOn);
        boolean hidden = b.fc >= 0;
        if (hidden) {
            // run to the stack edge, under the FC
            float k = 0.78f;
            ex = ex * k;
            ey = ey * k;
        }
        float bend = b.wireCut[pos][w] == 3 ? 0.35f : b.wireCut[pos][w] == 0 ? 0.25f : 0.04f;
        wire(c, sxp, syp, ex, ey, PHASE_COL[w], 1.1f, bend * (w - 1 + 0.5f));
        if (!simple && !hidden && escOn && b.wireCut[pos][w] != 0 && b.mJoint[out][w] >= 0) joint(c, ex, ey, 1.5f, b.mJoint[out][w], b.mFlag[out][w]);
        if (!simple && b.wireCut[pos][w] == 0) {
            g.p.setShader(null);
            g.p.setColor(0xFFB87333);
            c.drawCircle(sx(ex), sy(ey), 0.6f * cs, g.p);
        }
        if (!simple && cutM == pos && cutW == w && escOn) {
            // cutter marker sliding along the wire
            float t = 0.5f + 0.5f * (float) Math.sin(cutPhase * 2.2f);
            float px = mx(pos) * 0.82f + (escPx(out, w) - mx(pos) * 0.82f) * (0.55f + t * 0.6f);
            float py = my(pos) * 0.82f + (escPy(out, w) - my(pos) * 0.82f) * (0.55f + t * 0.6f);
            float gx0 = mx(pos) * 0.82f + (escPx(out, w) - mx(pos) * 0.82f) * 0.92f, gy0 = my(pos) * 0.82f + (escPy(out, w) - my(pos) * 0.82f) * 0.92f;
            float gx1 = mx(pos) * 0.82f + (escPx(out, w) - mx(pos) * 0.82f) * 1.02f, gy1 = my(pos) * 0.82f + (escPy(out, w) - my(pos) * 0.82f) * 1.02f;
            g.s.setColor(0xAA3DDC84);
            g.s.setStrokeWidth(8);
            c.drawLine(sx(gx0), sy(gy0), sx(gx1), sy(gy1), g.s);
            g.p.setColor(G.YELLOW);
            c.drawCircle(sx(px), sy(py), 7, g.p);
        }
    }

    float cutT() {
        return 0.55f + (0.5f + 0.5f * (float) Math.sin(cutPhase * 2.2f)) * 0.6f;
    }

    // ---------------------------------------------------------------- battery lead
    float pigEndX(int w) {
        Build b = b();
        if (b.pigPad[w] >= 0 && b.esc >= 0) return batPx(b.pigPad[w]);
        return (w == 0 ? -6 : 6);
    }

    float pigEndY(int w) {
        Build b = b();
        if (b.pigPad[w] >= 0 && b.esc >= 0) return batPy(b.pigPad[w]);
        return Build.BAT_PY * stackK() + 9;
    }

    float capEndX(int leg) {
        Build b = b();
        if (b.capPad[leg] >= 0 && b.esc >= 0) return batPx(b.capPad[leg]) + (leg == 0 ? 1.2f : -1.2f);
        return 18 + leg * 4;
    }

    float capEndY(int leg) {
        Build b = b();
        if (b.capPad[leg] >= 0 && b.esc >= 0) return batPy(b.capPad[leg]) + 0.5f;
        return 30;
    }

    private void drawPower(Canvas c, boolean simple) {
        Build b = b();
        if (b.pigtail >= 0) {
            float cx = 0, cy = frameL() / 2 + 30;
            for (int w = 0; w < 2; w++) {
                wire(c, cx + (w == 0 ? -3.5f : 3.5f), cy - 8, pigEndX(w), pigEndY(w), w == 0 ? 0xFFD32F2F : 0xFF1E1E1E, 3.2f, w == 0 ? 0.08f : -0.08f);
                if (!simple && b.pigJoint[w] >= 0 && b.fc < 0) joint(c, pigEndX(w), pigEndY(w), 2.6f, b.pigJoint[w], b.pigFlag[w]);
                if (!simple) wireTip(c, 1, w, pigEndX(w), pigEndY(w), b.pigPad[w] < 0);
            }
            v.res.sprite(c, "xt60", sx(cx), sy(cy), cs, 180, 255, false);
        }
        if (b.cap >= 0) {
            float cx = 26, cy = 34;
            v.res.sprite(c, "cap", sx(cx), sy(cy), cs, 90, 255, false);
            for (int leg = 0; leg < 2; leg++) {
                wire(c, cx - 10, cy + (leg == 0 ? -2 : 2), capEndX(leg), capEndY(leg), 0xFFB0B0B0, 0.7f, 0.05f);
                if (!simple && b.capJoint[leg] >= 0 && b.fc < 0) joint(c, capEndX(leg), capEndY(leg), 1.4f, b.capJoint[leg], b.capFlag[leg]);
                if (!simple) wireTip(c, 2, leg, capEndX(leg), capEndY(leg), b.capPad[leg] < 0);
            }
        }
    }

    /** Loose wire ends get a pulsing ring; the selected one is highlighted. */
    private void wireTip(Canvas c, int kind, int idx, float x, float y, boolean loose) {
        boolean sel = selWireKind == kind && selWireA == idx;
        if (!loose && !sel) return;
        g.s.setColor(sel ? G.CYAN : G.alpha(G.ORANGE, 140 + (int) (100 * Math.sin(v.time * 6))));
        g.s.setStrokeWidth(sel ? 3 : 2);
        c.drawCircle(sx(x), sy(y), Math.max(9, 2.2f * cs), g.s);
    }

    // ---------------------------------------------------------------- devices
    float devWireEndX(int d, int w) {
        Build b = b();
        int p = b.devPad[d][w];
        if (p >= 0 && b.fc >= 0) return fcPx(p);
        int n = Build.DEV_WIRE[d].length;
        return devX(d) + (w - (n - 1) / 2f) * 4.2f;
    }

    float devWireEndY(int d, int w) {
        Build b = b();
        int p = b.devPad[d][w];
        if (p >= 0 && b.fc >= 0) return fcPy(p);
        float dy = d == Build.DEV_CAM ? 16 : d == Build.DEV_VTX ? -19 : 14;
        return devY(d) + dy;
    }

    private void drawDevice(Canvas c, int d, boolean simple) {
        Build b = b();
        if (b.dev[d] < 0) return;
        Parts.Part p = gm().partOf(b.dev[d]);
        float x = devX(d), y = devY(d);
        String spr = p.sprite;
        float rot = d == Build.DEV_RX ? 0 : 0;
        v.res.sprite(c, spr, sx(x), sy(y), cs * (p.cat == Parts.VTX && !p.wideInput ? 0.7f : 1f), rot, 255, false);
        if (Elec.devDead(b, d)) {
            g.p.setShader(null);
            g.p.setColor(0x99201008);
            c.drawCircle(sx(x), sy(y), 9 * cs, g.p);
        }
        // RX LED status
        if (d == Build.DEV_RX && Elec.devWorks(gm(), 0, v.batteryOn, v.usbOn, v.benchBatteryPart())) {
            boolean on;
            if (v.bindModeT > 0) on = ((int) (v.time * 8)) % 4 < 2;
            else if (b.bound && v.radioOn) on = true;
            else on = ((int) (v.time * 2)) % 2 == 0;
            if (on) {
                g.p.setColor(0xFF4CFF6A);
                c.drawCircle(sx(x + 3), sy(y + 7), Math.max(3, 1.2f * cs), g.p);
                g.p.setColor(0x554CFF6A);
                c.drawCircle(sx(x + 3), sy(y + 7), Math.max(8, 3f * cs), g.p);
            }
        }
        // VTX LED shows the channel blink when powered
        if (d == Build.DEV_VTX && Elec.devWorks(gm(), 2, v.batteryOn, false, v.benchBatteryPart())) {
            g.p.setColor(((int) (v.time * 3)) % 2 == 0 ? 0xFFFF3B3B : 0xFF551111);
            c.drawCircle(sx(x + 11), sy(y - 11), Math.max(3, 1.1f * cs), g.p);
        }
        int n = Build.DEV_WIRE[d].length;
        for (int w = 0; w < n; w++) {
            float sxp = x + (w - (n - 1) / 2f) * 3.0f, syp = y + (d == Build.DEV_CAM ? 10 : d == Build.DEV_VTX ? -13 : 8);
            float ex = devWireEndX(d, w), ey = devWireEndY(d, w);
            boolean hiddenByTop = b.top >= 0 && b.devPad[d][w] >= 0;
            if (hiddenByTop) continue;
            wire(c, sxp, syp, ex, ey, Build.DEV_WIRE_COL[d][w], 0.75f, 0.12f * (w - (n - 1) / 2f));
            if (!simple && b.devJoint[d][w] >= 0) joint(c, ex, ey, 1.1f, b.devJoint[d][w], b.devFlag[d][w]);
            if (!simple && b.fc >= 0) {
                wireTip(c, 0, d * 10 + w, ex, ey, b.devPad[d][w] < 0);
                if (b.devPad[d][w] < 0 && cs > 4) g.text(c, Build.DEV_WIRE[d][w], sx(ex), sy(ey) + 16, 13, 0xFFFFFFFF, g.bold, Paint.Align.CENTER);
            }
        }
    }

    // ---------------------------------------------------------------- overlays: hints, hold gauges, meter
    private void drawOverlay(Canvas c) {
        if (holdKind >= 0) {
            float x = holdX, y = holdY - 70;
            float r = 34;
            g.p.setShader(null);
            g.p.setColor(0xE00C0F13);
            c.drawCircle(x, y, r + 10, g.p);
            g.r.set(x - r, y - r, x + r, y + r);
            if (holdKind == 1) {
                float w0 = 0.62f - flux(), w1 = 0.82f + flux();
                g.s.setStrokeWidth(8);
                g.s.setColor(0xFF2A3038);
                c.drawArc(g.r, 135, 270, false, g.s);
                g.s.setColor(0xFF3DDC84);
                c.drawArc(g.r, 135 + 270 * w0, 270 * (w1 - w0), false, g.s);
                g.s.setColor(0xFF7A4E2A);
                c.drawArc(g.r, 135 + 270 * 0.95f, 270 * 0.05f, false, g.s);
                g.s.setColor(holdHeat < 0.5f ? 0xFF8888FF : holdHeat < w0 ? G.YELLOW : holdHeat <= w1 ? G.GREEN : G.RED);
                g.s.setStrokeWidth(4);
                float a = (float) Math.toRadians(135 + 270 * Math.min(1, holdHeat));
                c.drawLine(x, y, x + (float) Math.cos(a) * r, y + (float) Math.sin(a) * r, g.s);
                g.text(c, holdHeat < 0.5f ? "HEATING" : holdHeat < w0 ? "FLOWING" : holdHeat <= w1 ? "RELEASE!" : "TOO HOT", x, y + r + 26, 18,
                        holdHeat <= w1 && holdHeat >= w0 ? G.GREEN : G.TEXT, g.bold, Paint.Align.CENTER);
                // smoke wisps
                for (int i = 0; i < 4; i++) {
                    float t = (v.time * 0.8f + i * 0.25f) % 1f;
                    g.p.setColor(G.alpha(0xFFDDDDDD, (int) (90 * (1 - t) * Math.min(1, holdHeat * 2))));
                    c.drawCircle(holdX + (float) Math.sin(t * 6 + i) * 10, holdY - t * 60, 6 + t * 12, g.p);
                }
            } else {
                g.s.setStrokeWidth(8);
                g.s.setColor(0xFF2A3038);
                c.drawArc(g.r, 135, 270, false, g.s);
                g.s.setColor(0xFF3DDC84);
                c.drawArc(g.r, 135 + 270 * 0.6f, 270 * 0.25f, false, g.s);
                g.s.setColor(G.RED);
                c.drawArc(g.r, 135 + 270 * 0.92f, 270 * 0.08f, false, g.s);
                g.s.setColor(G.TEXT);
                g.s.setStrokeWidth(4);
                float a = (float) Math.toRadians(135 + 270 * Math.min(1, holdHeat));
                c.drawLine(x, y, x + (float) Math.cos(a) * r, y + (float) Math.sin(a) * r, g.s);
                g.text(c, "TORQUE", x, y + r + 26, 18, G.TEXT, g.bold, Paint.Align.CENTER);
            }
        }
        if (meterT > 0 && meterMsg != null) {
            float w = g.width(meterMsg, 22, g.bold) + 40;
            g.r.set(800 - w / 2, v.Bm - 150, 800 + w / 2, v.Bm - 106);
            g.p.setShader(null);
            g.p.setColor(0xEE1A1508);
            c.drawRoundRect(g.r, 8, 8, g.p);
            g.s.setColor(G.YELLOW);
            g.s.setStrokeWidth(2);
            c.drawRoundRect(g.r, 8, 8, g.s);
            g.text(c, meterMsg, 800, v.Bm - 128, 22, G.YELLOW, g.bold, Paint.Align.CENTER);
        }
        if (cutM >= 0) g.text(c, "TAP ANYWHERE TO CUT WHEN THE MARKER IS IN THE GREEN ZONE", 800, v.T + 110, 20, G.YELLOW, g.bold, Paint.Align.CENTER);
        if (selWireKind >= 0) g.text(c, "NOW TAP THE PAD FOR THIS WIRE", 800, v.T + 110, 22, G.CYAN, g.bold, Paint.Align.CENTER);
    }

    private float flux() {
        return (gm().hasTool("tl_flux") ? 0.04f : 0) + (gm().hasTool("tl_t12") ? 0.02f : 0);
    }

    // ---------------------------------------------------------------- tray (left)
    private ArrayList<Game.Item> trayItems() {
        ArrayList<Game.Item> l = gm().itemsAt(Game.L_BENCH, -1);
        return l;
    }

    private void drawTray(Canvas c) {
        float l = v.L + 12, t = v.T + 76, r = v.L + 236, bt = v.Bm - 96;
        g.panelTitle(c, l, t, r, bt, "BENCH TRAY");
        ArrayList<Game.Item> its = trayItems();
        c.save();
        c.clipRect(l + 6, t + 58, r - 6, bt - 6);
        float y = t + 64 - trayScroll;
        Build b = b();
        boolean propsMode = b.propsItem >= 0;
        if (propsMode) {
            for (int k = 0; k < 2; k++) {
                int left = 2;
                for (int pos = 0; pos < 4; pos++) if (b.propType[pos] == k) left--;
                float ry = y;
                g.r.set(l + 10, ry, r - 10, ry + 84);
                g.p.setShader(null);
                g.p.setColor(G.PANEL2);
                c.drawRoundRect(g.r, 6, 6, g.p);
                Parts.Part pp = gm().partOf(b.propsItem);
                v.res.sprite(c, pp == null ? "prop5" : pp.sprite, l + 56, ry + 42, 0.5f * (pp != null && pp.size == 7 ? 0.7f : pp != null && pp.size == 3 ? 1.6f : 1f), 0, 255, k == 1);
                g.text(c, k == 0 ? "CW PROP" : "CCW PROP", l + 100, ry + 30, 18, G.TEXT, g.bold, Paint.Align.LEFT);
                g.text(c, "x" + Math.max(0, left), l + 100, ry + 56, 18, G.DIM, g.bold, Paint.Align.LEFT);
                g.hit(k == 0 ? B_PROP_CW : B_PROP_CCW, l + 10, ry, r - 10, ry + 84);
                y += 92;
            }
        }
        if (its.isEmpty() && !propsMode) g.para(c, "Empty. Turn LEFT to the shelves and take parts to the bench.", l + 18, t + 90, r - l - 36, 18, G.DIM, g.med, 24);
        for (int i = 0; i < its.size(); i++) {
            Game.Item it = its.get(i);
            Parts.Part p = it.p();
            float ry = y + i * 92;
            if (ry > bt || ry + 84 < t + 58) continue;
            g.r.set(l + 10, ry, r - 10, ry + 84);
            g.p.setShader(null);
            g.p.setColor(it == drag ? 0xFF243444 : G.PANEL2);
            c.drawRoundRect(g.r, 6, 6, g.p);
            v.res.fit(c, p.icon, l + 52, ry + 42, 72, 70, it == drag ? 90 : 255);
            String n = p.name;
            if (n.length() > 14) n = n.substring(0, 13) + "…";
            g.text(c, Parts.CAT_SHORT[p.cat], l + 94, ry + 22, 13, G.ORANGE, g.bold, Paint.Align.LEFT);
            g.text(c, n, l + 94, ry + 46, 16, G.TEXT, g.bold, Paint.Align.LEFT);
            if (it.damaged) g.text(c, "DAMAGED", l + 94, ry + 68, 13, G.RED, g.bold, Paint.Align.LEFT);
            else g.text(c, p.brand, l + 94, ry + 68, 13, G.DIM, g.med, Paint.Align.LEFT);
            g.hit(B_TRAY + i, l + 10, ry, r - 10, ry + 84);
        }
        c.restore();
    }

    private void drawDragged(Canvas c) {
        if (dragProp >= 0) {
            Parts.Part pp = gm().partOf(b().propsItem);
            v.res.sprite(c, pp == null ? "prop5" : pp.sprite, dragX, dragY, cs, 0, 200, dragProp == 1);
            return;
        }
        Parts.Part p = drag.p();
        boolean board = p.cat == Parts.ESC || p.cat == Parts.FC;
        if (p.sprite != null && !board) v.res.sprite(c, p.cat == Parts.FRAME ? p.sprite : p.sprite, dragX, dragY, cs, 0, 200, false);
        else {
            c.save();
            c.translate(dragX, dragY);
            c.rotate(placeRot * 90);
            float h = 18 * boardK(p) * cs;
            g.r.set(-h, -h, h, h);
            g.p.setShader(null);
            g.p.setColor(0xCC15181C);
            c.drawRoundRect(g.r, 6, 6, g.p);
            g.s.setColor(G.CYAN);
            g.s.setStrokeWidth(2);
            c.drawRoundRect(g.r, 6, 6, g.s);
            g.p.setColor(G.TEXT);
            g.path.reset();
            g.path.moveTo(0, -h * 0.7f);
            g.path.lineTo(-h * 0.25f, -h * 0.3f);
            g.path.lineTo(h * 0.25f, -h * 0.3f);
            g.path.close();
            c.drawPath(g.path, g.p);
            c.restore();
        }
        g.text(c, p.name, dragX, dragY - 40, 18, G.TEXT, g.bold, Paint.Align.CENTER);
    }

    // ---------------------------------------------------------------- steps (right)
    static final class Step {
        String name, hint;
        boolean done;
    }

    ArrayList<Step> steps() {
        Build b = b();
        ArrayList<Step> l = new ArrayList<>();
        add(l, "Frame on the mat", b.hasFrame(), "Drag the frame from the bench tray onto the mat.");
        add(l, "4 motors mounted", b.allMotorsScrewed(), b.motorsPlaced() < 4 ? "Drag motors onto the arm ends." : "FLIP the frame, pick screws in the organiser (look down) and drive them with the hex driver.");
        add(l, "Standoffs + ESC", b.standoffsDone() && b.esc >= 0, !b.standoffsDone() ? "FLIP, take M3 standoffs from the organiser and screw them into the 4 stack holes." : "Drag the ESC onto the stack, arrow pointing forward (ROTATE before placing).");
        add(l, "Motor wires soldered", b.motorWiresDone(), "CUTTERS: trim each wire to length. IRON: hold on each pad until the gauge is green, then release. ZOOM in!");
        add(l, "Battery lead + cap", b.powerDone() && b.cap >= 0 && b.capJoint[0] >= 0 && b.capJoint[1] >= 0, "Drag the XT60 pigtail and capacitor in. Tap a wire end, then its pad (red +, black -, cap stripe -). Solder hot!");
        add(l, "Flight controller", b.fc >= 0 && b.harness, b.fc < 0 ? "Drag the FC onto the stack (arrow forward)." : "Tap the FC to plug in the ESC harness.");
        add(l, "Receiver wired", b.devWired(0), "Place the receiver, then route 5V, GND, TX->Rx pad, RX->Tx pad and solder.");
        add(l, "Camera wired", b.devWired(1), "Place the camera, wire V+, GND and VIDEO -> CAM.");
        add(l, "VTX + antenna", b.devWired(2) && b.antenna >= 0, "Place the VTX, wire power, GND, VIDEO -> VTX (SmartAudio optional). Screw the antenna on!");
        add(l, "Top plate", b.topDone(), "Drag the top plate on (it comes with the frame) and screw it down.");
        add(l, "Smoke test", b.smokeTest, "Put a battery on the bench and plug it in through the smoke stopper.");
        add(l, "Flash + configure", Elec.fwOk(gm()) && b.serialRxUart > 0 && b.rxProvider == 2 && b.armAux > 0, "Plug in USB and open FC Configurator on the PC.");
        add(l, "Bind + tests", b.bound && b.rxTest && b.motorTest && b.videoTest, "Bind the radio, check the Receiver tab, test motors (props off!), check the goggles.");
        add(l, "Props on", b.propsDone(), "Drag the props pack in, then a CW prop onto clockwise motors, CCW onto the others. Tighten the nuts.");
        return l;
    }

    private void add(ArrayList<Step> l, String n, boolean d, String hint) {
        Step s = new Step();
        s.name = n;
        s.done = d;
        s.hint = hint;
        l.add(s);
    }

    private void drawSteps(Canvas c) {
        float l = v.R - 316, t = v.T + 76, r = v.R - 12, bt = v.Bm - 96;
        g.panelTitle(c, l, t, r, bt, "BUILD STEPS");
        ArrayList<Step> st = steps();
        int cur = -1;
        for (int i = 0; i < st.size(); i++) if (!st.get(i).done) {
            cur = i;
            break;
        }
        float y = t + 72;
        for (int i = 0; i < st.size(); i++) {
            Step s = st.get(i);
            boolean isCur = i == cur;
            if (isCur) {
                g.p.setShader(null);
                g.p.setColor(0xFF2A2013);
                c.drawRect(l + 8, y - 15, r - 8, y + 15, g.p);
            }
            if (s.done) g.icon(c, G.I_CHECK, l + 26, y, 8, G.GREEN);
            else {
                g.s.setColor(isCur ? G.ORANGE : G.DIM2);
                g.s.setStrokeWidth(1.6f);
                c.drawCircle(l + 26, y, 7, g.s);
            }
            g.text(c, (i + 1) + ". " + s.name, l + 42, y, 16, s.done ? G.DIM : isCur ? G.TEXT : G.DIM, g.bold, Paint.Align.LEFT);
            y += 26;
        }
        if (cur >= 0) {
            float hy = y + 6;
            g.s.setColor(G.LINE);
            c.drawLine(l + 12, hy - 6, r - 12, hy - 6, g.s);
            g.para(c, st.get(cur).hint, l + 18, hy + 14, r - l - 36, 16, 0xFFFFC48A, g.med, 21);
        }
    }

    // ---------------------------------------------------------------- toolbar (bottom)
    private void drawToolbar(Canvas c) {
        float y = v.Bm - 46;
        g.p.setShader(new LinearGradient(0, v.Bm - 88, 0, v.Bm, 0xEE0C0F13, 0xFF0C0F13, Shader.TileMode.CLAMP));
        c.drawRect(v.L, v.Bm - 88, v.R, v.Bm, g.p);
        g.p.setShader(null);
        float x = v.L + 14;
        for (int i = 0; i < 5; i++) {
            g.button(c, B_TOOL + i, x, y - 30, x + 112, y + 30, TOOL_NAME[i], tool == i ? G.B_PRIMARY : G.B_DARK);
            x += 118;
        }
        x += 10;
        g.button(c, B_FLIP, x, y - 30, x + 86, y + 30, flipped ? "TOP" : "FLIP", flipped ? G.B_CYAN : G.B_DARK);
        x += 92;
        g.button(c, B_ZOOM, x, y - 30, x + 94, y + 30, zoomed ? "ZOOM -" : "ZOOM +", zoomed ? G.B_CYAN : G.B_DARK);
        x += 100;
        g.button(c, B_ROT, x, y - 30, x + 104, y + 30, "ROT " + placeRot * 90 + "°", G.B_DARK);
        x += 110;
        Build b = b();
        String bat = v.benchBattery < 0 ? "NO BATTERY" : v.batteryOn ? "UNPLUG" : "PLUG BAT";
        g.button(c, B_BAT, x, y - 30, x + 118, y + 30, bat, v.batteryOn ? G.B_DANGER : v.benchBattery < 0 ? G.B_DISABLED : G.B_GOOD);
        x += 124;
        g.button(c, B_USB, x, y - 30, x + 92, y + 30, v.usbOn ? "USB OUT" : "USB IN", v.usbOn ? G.B_CYAN : (b.fc >= 0 ? G.B_DARK : G.B_DISABLED));
        x += 98;
        if (b.fc >= 0) {
            g.button(c, B_BOOT, x, y - 30, x + 92, y + 30, bootHeld ? "BOOT ON" : "BOOT", bootHeld ? G.B_PRIMARY : G.B_DARK);
            x += 98;
        }
        if (b.dev[2] >= 0) {
            g.button(c, B_VTXBTN, x, y - 30, x + 96, y + 30, "VTX " + Elec.BAND_NAME[b.vtxBand] + b.vtxChan, G.B_DARK);
        }
        g.button(c, B_EXIT, v.R - 124, y - 30, v.R - 12, y + 30, "STAND UP", G.B_DARK);
    }

    // ---------------------------------------------------------------- input
    @Override
    void touch(int action, float x, float y, int id) {
        // tray dragging
        if (action == 0 && id >= B_TRAY && id < B_TRAY + 200) {
            ArrayList<Game.Item> its = trayItems();
            int i = id - B_TRAY;
            if (i < its.size()) {
                drag = its.get(i);
                dragX = x;
                dragY = y;
                trayY0 = y;
                trayS0 = trayScroll;
                trayScrolling = false;
            }
            return;
        }
        if (action == 0 && (id == B_PROP_CW || id == B_PROP_CCW)) {
            dragProp = id == B_PROP_CW ? 0 : 1;
            dragX = x;
            dragY = y;
            return;
        }
        if (drag != null || dragProp >= 0) {
            if (action == 1) {
                if (drag != null && !trayScrolling && x < v.L + 240 && Math.abs(y - trayY0) > 20 && Math.abs(x - dragX) < 30) trayScrolling = true;
                if (trayScrolling) {
                    trayScroll = Math.max(0, trayS0 - (y - trayY0));
                } else {
                    dragX = x;
                    dragY = y;
                }
                if (v.moved) v.consumed = true;
            } else if (action >= 2) {
                if (v.moved && !trayScrolling && action == 2 && x > v.L + 240) drop(x, y);
                else if (!v.moved && drag != null) inspect(drag);
                drag = null;
                dragProp = -1;
                v.consumed = true;
            }
            return;
        }
        if (holdKind >= 0) {
            if (action >= 2) releaseHold();
            return;
        }
        if (id > 0) return;
        if (action != 0) return;
        if (x < v.L + 240 || x > v.R - 320 || y > v.Bm - 90) return;
        if (cutM >= 0) {
            doCut();
            return;
        }
        worldTap(x, y);
    }

    private void inspect(Game.Item it) {
        Parts.Part p = it.p();
        v.info(p.full(), p.spec() + "\n\n" + p.desc + "\n\nDrag it onto the drone to install it." + (it.damaged ? "\n\nDAMAGED: " + it.note : ""));
    }

    private float fx(float x) {
        return (flipped ? -(x - ccx) : (x - ccx)) / cs;
    }

    private float fy(float y) {
        return (y - ccy) / cs;
    }

    private boolean near(float x, float y, float px, float py, float rmm) {
        float dx = sx(px) - x, dy = sy(py) - y;
        float r = Math.max(rmm * cs, 18);
        return dx * dx + dy * dy < r * r;
    }

    /** Drop a dragged part onto the drone. */
    private void drop(float x, float y) {
        Build b = b();
        Game gm = gm();
        if (dragProp >= 0) {
            for (int pos = 0; pos < 4; pos++) {
                if (near(x, y, mx(pos), my(pos), 25) && b.motor[pos] >= 0 && b.propType[pos] < 0) {
                    int left = 2;
                    for (int p = 0; p < 4; p++) if (b.propType[p] == dragProp) left--;
                    if (left <= 0) {
                        v.toast("NO " + (dragProp == 0 ? "CW" : "CCW") + " PROPS LEFT IN THE PACK", G.RED);
                        return;
                    }
                    b.propType[pos] = dragProp;
                    b.propNut[pos] = 0;
                    v.sfx.play(Sfx.PLACE, 0.7f);
                    v.toast("PROP ON - TIGHTEN THE NUT WITH THE HEX DRIVER (HOLD)", G.CYAN);
                    return;
                }
            }
            return;
        }
        Parts.Part p = drag.p();
        if (drag.damaged) {
            v.info("DAMAGED PART", drag.note + "\n\nThis part can't be used any more. Order a replacement in PartHub.");
            return;
        }
        if (p.cat == Parts.BATT) {
            if (v.batteryOn) {
                v.toast("UNPLUG THE CURRENT BATTERY FIRST", G.RED);
                return;
            }
            v.benchBattery = drag.uid;
            v.sfx.play(Sfx.PLACE, 0.7f);
            v.toast("BATTERY READY ON THE BENCH - USE 'PLUG BAT'", G.CYAN);
            return;
        }
        if (p.cat == Parts.FRAME) {
            if (b.hasFrame()) {
                v.toast("THERE IS ALREADY A FRAME ON THE MAT", G.RED);
                return;
            }
            place(drag);
            b.frame = drag.uid;
            enter();
            return;
        }
        if (!b.hasFrame()) {
            v.toast("START WITH THE FRAME", G.RED);
            return;
        }
        if (flipped) {
            v.toast("FLIP THE FRAME BACK (TOP) TO INSTALL PARTS", G.RED);
            return;
        }
        Parts.Part fr = frame();
        switch (p.cat) {
            case Parts.MOTOR: {
                int best = -1;
                for (int pos = 0; pos < 4; pos++) if (b.motor[pos] < 0 && near(x, y, mx(pos), my(pos), 30)) best = pos;
                if (best < 0) {
                    v.toast("DROP THE MOTOR ON AN EMPTY ARM END", G.DIM);
                    return;
                }
                if (p.m2 != fr.m2) {
                    v.info("DOESN'T FIT", "This motor uses a " + (p.m2 ? "9x9 M2" : "16x16 M3") + " mounting pattern, the frame arms have " + (fr.m2 ? "9x9 M2" : "16x16 M3") + " holes.");
                    return;
                }
                place(drag);
                b.motor[best] = drag.uid;
                return;
            }
            case Parts.ESC: {
                if (b.esc >= 0) {
                    v.toast("ESC ALREADY INSTALLED", G.RED);
                    return;
                }
                if (p.mount != fr.mount) {
                    v.info("WRONG STACK SIZE", "This ESC is " + Parts.fmtMount(p.mount) + " but the frame has " + Parts.fmtMount(fr.mount) + " stack holes.");
                    return;
                }
                if (!b.standoffsDone()) {
                    v.info("STANDOFFS FIRST", "FLIP the frame and screw in the 4 stack standoffs first (M3 standoffs in the organiser).");
                    return;
                }
                if (!near(x, y, 0, 0, 30)) {
                    v.toast("DROP THE ESC ON THE STACK IN THE MIDDLE", G.DIM);
                    return;
                }
                place(drag);
                b.esc = drag.uid;
                b.escRot = placeRot;
                if (placeRot != 0) v.toast("ESC MOUNTED ROTATED " + placeRot * 90 + "° - MOTOR ORDER WILL NEED A REMAP", G.YELLOW);
                return;
            }
            case Parts.FC: {
                if (b.fc >= 0) {
                    v.toast("FC ALREADY INSTALLED", G.RED);
                    return;
                }
                if (b.esc < 0) {
                    v.toast("INSTALL THE ESC FIRST", G.RED);
                    return;
                }
                if (p.mount != fr.mount) {
                    v.info("WRONG STACK SIZE", "This FC is " + Parts.fmtMount(p.mount) + " but the frame has " + Parts.fmtMount(fr.mount) + " stack holes.");
                    return;
                }
                if (!near(x, y, 0, 0, 30)) return;
                if (!b.motorWiresDone() || !b.powerDone()) {
                    final Game.Item it = drag;
                    final int rot = placeRot;
                    v.dialog("ESC PADS STILL OPEN", "Once the FC is on top you can't reach the ESC pads any more. Solder the motor wires and the battery lead first. Install the FC anyway?",
                            new String[]{"WAIT", "INSTALL"}, new int[]{G.B_PRIMARY, G.B_DARK}, new GameView.DialogCb() {
                                @Override
                                public void on(int i) {
                                    if (i == 1) {
                                        place(it);
                                        b().fc = it.uid;
                                        b().fcRot = rot;
                                    }
                                }
                            });
                    return;
                }
                place(drag);
                b.fc = drag.uid;
                b.fcRot = placeRot;
                return;
            }
            case Parts.PIGTAIL:
                if (b.pigtail >= 0) return;
                if (b.esc < 0) {
                    v.toast("INSTALL THE ESC FIRST", G.RED);
                    return;
                }
                place(drag);
                b.pigtail = drag.uid;
                return;
            case Parts.CAP:
                if (b.cap >= 0) return;
                if (b.esc < 0) {
                    v.toast("INSTALL THE ESC FIRST", G.RED);
                    return;
                }
                place(drag);
                b.cap = drag.uid;
                return;
            case Parts.RX: case Parts.CAM: case Parts.VTX: {
                int d = p.cat == Parts.RX ? 0 : p.cat == Parts.CAM ? 1 : 2;
                if (b.dev[d] >= 0) {
                    v.toast("ALREADY INSTALLED", G.RED);
                    return;
                }
                if (b.fc < 0) {
                    v.toast("INSTALL THE FLIGHT CONTROLLER FIRST", G.RED);
                    return;
                }
                if (d == 1 && p.size != 19 && fr.size != 3) v.toast("NANO CAMERA IN A MICRO CAMERA CAGE - IT WILL NEED ADAPTERS", G.YELLOW);
                place(drag);
                b.dev[d] = drag.uid;
                return;
            }
            case Parts.ANT: {
                if (b.dev[2] < 0) {
                    v.toast("INSTALL THE VTX FIRST", G.RED);
                    return;
                }
                Parts.Part vtx = gm.partOf(b.dev[2]);
                if (!vtx.conn.equals(p.conn)) {
                    v.info("WRONG CONNECTOR", "This antenna has a " + p.conn + " plug but the VTX has a " + vtx.conn + " socket.");
                    return;
                }
                if (b.antenna >= 0) return;
                place(drag);
                b.antenna = drag.uid;
                v.sfx.play(Sfx.SCREW, 0.6f);
                return;
            }
            case Parts.PROPS: {
                if (p.size != fr.size) {
                    v.info("WRONG PROPS", "These are " + p.size + "-inch props, the frame takes " + fr.size + "-inch props.");
                    return;
                }
                if (!b.allMotorsScrewed()) {
                    v.toast("MOUNT THE MOTORS FIRST", G.RED);
                    return;
                }
                if (b.propsItem >= 0) return;
                place(drag);
                b.propsItem = drag.uid;
                v.toast("DRAG CW / CCW PROPS FROM THE TRAY ONTO THE MOTORS", G.CYAN);
                return;
            }
        }
        v.toast("THAT PART DOESN'T GO THERE", G.DIM);
    }

    private void place(Game.Item it) {
        it.loc = Game.L_BUILD;
        v.sfx.play(Sfx.PLACE, 0.8f);
        v.vibrate(12);
    }

    /** A tap on the drone with the current tool. */
    private void worldTap(float x, float y) {
        Build b = b();
        Game gm = gm();
        if (!b.hasFrame()) return;
        // route the selected wire first, then allow picking another loose wire (any tool)
        if (selWireKind >= 0 && !flipped) {
            if (tryAssignPad(x, y)) return;
            selWireKind = -1;
        }
        if (!flipped && trySelectWire(x, y)) return;
        if (!flipped && tool == T_HAND && tryUnroute(x, y)) return;
        switch (tool) {
            case T_DRIVER: driverTap(x, y); return;
            case T_IRON: ironTap(x, y); return;
            case T_CUTTER: cutterTap(x, y); return;
            case T_METER: meterTap(x, y); return;
            default: handTap(x, y);
        }
    }

    private boolean trySelectWire(float x, float y) {
        Build b = b();
        if (b.pigtail >= 0 && b.esc >= 0 && b.fc < 0) {
            for (int w = 0; w < 2; w++) if (b.pigPad[w] < 0 && near(x, y, pigEndX(w), pigEndY(w), 4)) {
                select(1, w, 0);
                return true;
            }
        }
        if (b.cap >= 0 && b.esc >= 0 && b.fc < 0) {
            for (int l = 0; l < 2; l++) if (b.capPad[l] < 0 && near(x, y, capEndX(l), capEndY(l), 3)) {
                select(2, l, 0);
                return true;
            }
        }
        if (b.fc >= 0 && b.top < 0) {
            for (int d = 0; d < 3; d++) {
                if (b.dev[d] < 0) continue;
                for (int w = 0; w < Build.DEV_WIRE[d].length; w++) {
                    if (b.devPad[d][w] >= 0) continue;
                    if (near(x, y, devWireEndX(d, w), devWireEndY(d, w), 2.5f)) {
                        select(0, d * 10 + w, 0);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /** HAND on a routed but not yet soldered wire end: pull it off the pad again. */
    private boolean tryUnroute(float x, float y) {
        Build b = b();
        if (b.fc < 0 && b.esc >= 0) {
            for (int w = 0; w < 2; w++) if (b.pigtail >= 0 && b.pigPad[w] >= 0 && b.pigJoint[w] < 0 && near(x, y, pigEndX(w), pigEndY(w), 2)) {
                b.pigPad[w] = -1;
                select(1, w, 0);
                return true;
            }
            for (int l = 0; l < 2; l++) if (b.cap >= 0 && b.capPad[l] >= 0 && b.capJoint[l] < 0 && near(x, y, capEndX(l), capEndY(l), 1.5f)) {
                b.capPad[l] = -1;
                select(2, l, 0);
                return true;
            }
        }
        if (b.fc >= 0 && b.top < 0) {
            for (int d = 0; d < 3; d++) {
                if (b.dev[d] < 0) continue;
                for (int w = 0; w < Build.DEV_WIRE[d].length; w++) {
                    if (b.devPad[d][w] >= 0 && b.devJoint[d][w] < 0 && near(x, y, devWireEndX(d, w), devWireEndY(d, w), 1.2f)) {
                        b.devPad[d][w] = -1;
                        select(0, d * 10 + w, 0);
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private void select(int kind, int a, int bb) {
        selWireKind = kind;
        selWireA = a;
        selWireB = bb;
        v.sfx.play(Sfx.TAP, 0.6f);
        if (!zoomed) zoomed = true;
    }

    private boolean tryAssignPad(float x, float y) {
        Build b = b();
        if (selWireKind == 1 || selWireKind == 2) {
            for (int pd = 0; pd < 2; pd++) {
                if (near(x, y, batPx(pd), batPy(pd), 3.5f)) {
                    if (selWireKind == 1) b.pigPad[selWireA] = pd;
                    else b.capPad[selWireA] = pd;
                    v.sfx.play(Sfx.SNAP, 0.5f);
                    selWireKind = -1;
                    return true;
                }
            }
            return false;
        }
        if (selWireKind == 0) {
            Parts.Part fc = gm().partOf(b.fc);
            int d = selWireA / 10, w = selWireA % 10;
            for (int p = 0; p < Build.FC_PAD.length; p++) {
                if (!Build.fcHasPad(fc, p)) continue;
                if (near(x, y, fcPx(p), fcPy(p), 1.6f)) {
                    if (b.wiresOnFcPad(p) >= 2) {
                        v.toast("THAT PAD ALREADY HAS TWO WIRES", G.RED);
                        return true;
                    }
                    b.devPad[d][w] = p;
                    v.sfx.play(Sfx.SNAP, 0.5f);
                    selWireKind = -1;
                    return true;
                }
            }
        }
        return false;
    }

    private void handTap(float x, float y) {
        Build b = b();
        if (flipped) return;
        // ESC harness
        if (b.fc >= 0 && !b.harness && near(x, y, 0, 0, 18 * stackK())) {
            b.harness = true;
            v.sfx.play(Sfx.SNAP, 0.9f);
            v.toast("ESC HARNESS PLUGGED IN", G.GREEN);
            return;
        }
        // top plate (ships with the frame)
        if (b.top < 0 && near(x, y, 0, 0, 22)) {
            if (b.fc >= 0 && b.harness) {
                v.dialog("INSTALL THE TOP PLATE?", "After this you can't reach the FC pads without removing it again. Make sure all devices are wired.", new String[]{"WAIT", "INSTALL"},
                        new int[]{G.B_DARK, G.B_PRIMARY}, new GameView.DialogCb() {
                            @Override
                            public void on(int i) {
                                if (i == 1) {
                                    b().top = b().frame;
                                    v.sfx.play(Sfx.PLACE, 0.8f);
                                    v.toast("TOP PLATE ON - NOW SCREW IT DOWN (HEX DRIVER + M3 SCREWS)", G.CYAN);
                                }
                            }
                        });
                return;
            }
        }
        // remove things: props, devices, antenna
        for (int pos = 0; pos < 4; pos++) {
            if (b.propType[pos] >= 0 && near(x, y, mx(pos), my(pos), 20)) {
                b.propType[pos] = -1;
                b.propNut[pos] = 0;
                v.sfx.play(Sfx.PLACE, 0.5f);
                return;
            }
        }
        if (b.antenna >= 0 && near(x, y, devX(2) + 9, devY(2) + 34, 10)) {
            Game.Item it = gm().item(b.antenna);
            if (it != null) it.loc = Game.L_BENCH;
            b.antenna = -1;
            v.toast("ANTENNA REMOVED", G.DIM);
            return;
        }
        for (int d = 0; d < 3; d++) {
            if (b.dev[d] >= 0 && near(x, y, devX(d), devY(d), 9)) {
                boolean wired = false;
                for (int w = 0; w < b.devJoint[d].length; w++) if (b.devJoint[d][w] >= 0) wired = true;
                if (wired) {
                    v.toast("DESOLDER ITS WIRES FIRST (IRON)", G.DIM);
                    return;
                }
                if (d == 2 && b.antenna >= 0) {
                    v.toast("REMOVE THE ANTENNA FIRST", G.DIM);
                    return;
                }
                final int dd = d;
                v.dialog("REMOVE " + gm().partOf(b.dev[d]).name.toUpperCase(Locale.US) + "?", "It goes back to the bench tray.", new String[]{"KEEP", "REMOVE"},
                        new int[]{G.B_DARK, G.B_PRIMARY}, new GameView.DialogCb() {
                            @Override
                            public void on(int i) {
                                if (i == 1) {
                                    Game.Item it = gm().item(b().dev[dd]);
                                    if (it != null) it.loc = Game.L_BENCH;
                                    b().dev[dd] = -1;
                                    for (int w = 0; w < b().devPad[dd].length; w++) {
                                        b().devPad[dd][w] = -1;
                                        b().devJoint[dd][w] = -1;
                                        b().devFlag[dd][w] = 0;
                                    }
                                }
                            }
                        });
                return;
            }
        }
        if (b.fc >= 0 && b.top < 0 && near(x, y, 0, 0, 14)) {
            boolean any = false;
            for (int d = 0; d < 3; d++) for (int w = 0; w < b.devJoint[d].length; w++) if (b.devJoint[d][w] >= 0) any = true;
            if (any) {
                v.toast("DESOLDER THE DEVICE WIRES TO REMOVE THE FC", G.DIM);
                return;
            }
            v.dialog("REMOVE THE FLIGHT CONTROLLER?", "Lifts the FC off the stack so you can reach the ESC pads.", new String[]{"KEEP", "REMOVE"}, new int[]{G.B_DARK, G.B_PRIMARY},
                    new GameView.DialogCb() {
                        @Override
                        public void on(int i) {
                            if (i == 1) {
                                Game.Item it = gm().item(b().fc);
                                if (it != null) it.loc = Game.L_BENCH;
                                b().fc = -1;
                                b().harness = false;
                                for (int d = 0; d < 3; d++) for (int w = 0; w < b().devPad[d].length; w++) b().devPad[d][w] = -1;
                                v.usbOn = false;
                            }
                        }
                    });
        }
    }

    private void driverTap(float x, float y) {
        Build b = b();
        Game gm = gm();
        Parts.Part fr = frame();
        if (flipped) {
            for (int pos = 0; pos < 4; pos++) {
                if (b.motor[pos] < 0) continue;
                for (int j = 0; j < 4; j++) {
                    if (!near(x, y, holeX(pos, j), holeY(pos, j), 3)) continue;
                    if (b.screw[pos][j] >= 0) {
                        if (gm.hand < 0 || b.torque[pos][j] > 1f || b.torque[pos][j] >= 0.6f) {
                            unscrewDialog(pos, j);
                            return;
                        }
                        startHold(0, pos, j, x, y);
                        holdHeat = b.torque[pos][j];
                        return;
                    }
                    if (gm.hand < 0 || Parts.HW_LEN[gm.hand] == 0) {
                        v.toast("PICK SCREWS FROM THE ORGANISER FIRST (LOOK DOWN AT THE BENCH)", G.RED);
                        return;
                    }
                    if (Parts.HW_M2[gm.hand] != fr.m2) {
                        v.toast((fr.m2 ? "THESE ARE M2 MOTORS" : "THESE ARE M3 MOTORS") + " - WRONG SCREW THREAD", G.RED);
                        return;
                    }
                    b.screw[pos][j] = gm.hand;
                    b.torque[pos][j] = 0;
                    v.sfx.play(Sfx.SCREW, 0.6f);
                    startHold(0, pos, j, x, y);
                    return;
                }
            }
            for (int i = 0; i < 4; i++) {
                if (!near(x, y, stackHole(i, false), stackHole(i, true), 3)) continue;
                if (b.standoff[i]) {
                    if (b.standoffT[i] < 0.6f) {
                        startHold(2, i, 0, x, y);
                        holdHeat = b.standoffT[i];
                    }
                    return;
                }
                if (gm.hand != Parts.HW_STANDOFF) {
                    v.toast("PICK M3 STANDOFFS FROM THE ORGANISER", G.RED);
                    return;
                }
                b.standoff[i] = true;
                b.standoffT[i] = 0;
                startHold(2, i, 0, x, y);
                return;
            }
            return;
        }
        // top side: top plate screws and prop nuts
        if (b.top >= 0) {
            for (int i = 0; i < 4; i++) {
                if (!near(x, y, topHoleX(i), topHoleY(i), 3)) continue;
                if (b.topScrew[i] >= 0) {
                    if (b.topT[i] < 0.6f) {
                        startHold(3, i, 0, x, y);
                        holdHeat = b.topT[i];
                    }
                    return;
                }
                if (gm.hand < 0 || Parts.HW_LEN[gm.hand] == 0 || Parts.HW_M2[gm.hand] != fr.m2) {
                    v.toast("PICK " + (fr.m2 ? "M2" : "M3") + " SCREWS FROM THE ORGANISER", G.RED);
                    return;
                }
                b.topScrew[i] = gm.hand;
                b.topT[i] = 0;
                startHold(3, i, 0, x, y);
                return;
            }
        }
        for (int pos = 0; pos < 4; pos++) {
            if (b.propType[pos] >= 0 && near(x, y, mx(pos), my(pos), 8)) {
                if (b.propNut[pos] < 0.6f) {
                    startHold(4, pos, 0, x, y);
                    holdHeat = b.propNut[pos];
                }
                return;
            }
        }
        if (b.motor[0] >= 0 && b.esc < 0) v.toast("MOTOR SCREWS GO IN FROM BELOW - TAP FLIP", G.DIM);
    }

    private void unscrewDialog(final int pos, final int j) {
        v.dialog("REMOVE SCREW?", "Unscrew this " + Parts.HW_NAME[b().screw[pos][j]] + " screw" + (b().torque[pos][j] > 1 ? " (stripped)" : "") + "?", new String[]{"KEEP", "UNSCREW"},
                new int[]{G.B_DARK, G.B_PRIMARY}, new GameView.DialogCb() {
                    @Override
                    public void on(int i) {
                        if (i == 1) {
                            b().screw[pos][j] = -1;
                            b().torque[pos][j] = 0;
                            v.sfx.play(Sfx.SCREW, 0.5f);
                        }
                    }
                });
    }

    private void startHold(int kind, int a, int bb, float x, float y) {
        holdKind = kind;
        holdA = a;
        holdB = bb;
        holdT = 0;
        holdHeat = 0;
        holdX = x;
        holdY = y;
        v.consumed = true;
    }

    private void releaseHold() {
        Build b = b();
        float h = holdHeat;
        int kind = holdKind;
        holdKind = -1;
        if (sizzle != 0) {
            v.sfx.stop(sizzle);
            sizzle = 0;
        }
        switch (kind) {
            case 0: b.torque[holdA][holdB] = h; torqueFeedback(h); break;
            case 2: b.standoffT[holdA] = h; torqueFeedback(h); break;
            case 3: b.topT[holdA] = h; torqueFeedback(h); break;
            case 4: b.propNut[holdA] = h; torqueFeedback(h); break;
            case 1: finishSolder(h); break;
        }
        if (kind == 0 && b.allMotorsScrewed()) v.toast("ALL MOTORS MOUNTED", G.GREEN);
    }

    private void torqueFeedback(float h) {
        if (h > 1f) {
            v.sfx.play(Sfx.STRIP, 0.8f);
            v.toast("STRIPPED! TOO MUCH TORQUE - UNSCREW AND REDO", G.RED);
            v.vibrate(80);
        } else if (h >= 0.6f) {
            v.sfx.play(Sfx.TORQUE, 0.7f);
            v.vibrate(15);
        } else v.toast("STILL LOOSE - HOLD A BIT LONGER", G.YELLOW);
    }

    // ---------------------------------------------------------------- soldering
    private void ironTap(float x, float y) {
        Build b = b();
        if (flipped) return;
        // motor pads (only reachable without FC)
        if (b.esc >= 0 && b.fc < 0) {
            for (int pos = 0; pos < 4; pos++) {
                if (b.motor[pos] < 0) continue;
                int out = Elec.outputAtPos(b, pos);
                for (int w = 0; w < 3; w++) {
                    if (!near(x, y, escPx(out, w), escPy(out, w), 1.8f)) continue;
                    if (b.mJoint[out][w] >= 0) {
                        desolderDialog(0, out, w);
                        return;
                    }
                    if (b.wireCut[pos][w] == 0) {
                        v.toast("TRIM THIS WIRE TO LENGTH FIRST (CUTTERS)", G.RED);
                        return;
                    }
                    solderPadKind = 0;
                    startHold(1, 0, out, x, y);
                    holdC = w;
                    sizzle = v.sfx.play(Sfx.SIZZLE, 0.5f, 1f, true);
                    return;
                }
            }
            for (int pd = 0; pd < 2; pd++) {
                if (!near(x, y, batPx(pd), batPy(pd), 3)) continue;
                // which wire(s) sit on this pad?
                for (int w = 0; w < 2; w++) {
                    if (b.pigtail >= 0 && b.pigPad[w] == pd && b.pigJoint[w] < 0) {
                        solderPadKind = 1;
                        startHold(1, 1, w, x, y);
                        sizzle = v.sfx.play(Sfx.SIZZLE, 0.6f, 0.9f, true);
                        return;
                    }
                }
                for (int l = 0; l < 2; l++) {
                    if (b.cap >= 0 && b.capPad[l] == pd && b.capJoint[l] < 0) {
                        solderPadKind = 3;
                        startHold(1, 2, l, x, y);
                        sizzle = v.sfx.play(Sfx.SIZZLE, 0.5f, 1f, true);
                        return;
                    }
                }
                for (int w = 0; w < 2; w++) if (b.pigtail >= 0 && b.pigPad[w] == pd && b.pigJoint[w] >= 0) {
                    desolderDialog(1, w, 0);
                    return;
                }
                for (int l = 0; l < 2; l++) if (b.cap >= 0 && b.capPad[l] == pd && b.capJoint[l] >= 0) {
                    desolderDialog(2, l, 0);
                    return;
                }
                v.toast("ROUTE A WIRE TO THIS PAD FIRST (TAP THE WIRE END, THEN THE PAD)", G.DIM);
                return;
            }
        }
        if (b.fc >= 0 && b.top < 0) {
            Parts.Part fc = gm().partOf(b.fc);
            for (int p = 0; p < Build.FC_PAD.length; p++) {
                if (!Build.fcHasPad(fc, p) || !near(x, y, fcPx(p), fcPy(p), 1.4f)) continue;
                for (int d = 0; d < 3; d++) for (int w = 0; w < b.devPad[d].length; w++) {
                    if (b.devPad[d][w] == p && b.devJoint[d][w] < 0) {
                        solderPadKind = 2;
                        startHold(1, 3, d * 10 + w, x, y);
                        sizzle = v.sfx.play(Sfx.SIZZLE, 0.4f, 1.1f, true);
                        return;
                    }
                }
                for (int d = 0; d < 3; d++) for (int w = 0; w < b.devPad[d].length; w++) {
                    if (b.devPad[d][w] == p && b.devJoint[d][w] >= 0) {
                        desolderDialog(3, d, w);
                        return;
                    }
                }
                v.toast("NO WIRE ROUTED TO " + Build.FC_PAD[p] + " - TAP A WIRE END, THEN THIS PAD", G.DIM);
                return;
            }
        }
        if (b.esc >= 0 && b.fc >= 0 && !b.motorWiresDone()) v.toast("THE FC COVERS THE ESC PADS - REMOVE THE FC (HAND) TO SOLDER MOTORS", G.DIM);
        else if (!zoomed) v.toast("ZOOM IN AND TAP A PAD WITH A WIRE ON IT", G.DIM);
    }

    private void desolderDialog(final int kind, final int a, final int bb) {
        v.dialog("DESOLDER?", "Heat the joint and pull the wire off the pad?", new String[]{"KEEP", "DESOLDER"}, new int[]{G.B_DARK, G.B_PRIMARY}, new GameView.DialogCb() {
            @Override
            public void on(int i) {
                if (i != 1) return;
                Build b = b();
                switch (kind) {
                    case 0: b.mJoint[a][bb] = -1; b.mFlag[a][bb] = 0; break;
                    case 1: b.pigJoint[a] = -1; b.pigFlag[a] = 0; b.pigPad[a] = -1; break;
                    case 2: b.capJoint[a] = -1; b.capFlag[a] = 0; b.capPad[a] = -1; break;
                    case 3: b.devJoint[a][bb] = -1; b.devFlag[a][bb] = 0; b.devPad[a][bb] = -1; break;
                }
                v.sfx.play(Sfx.SIZZLE, 0.4f);
                b.smokeTest = false;
            }
        });
    }

    private void finishSolder(float h) {
        Build b = b();
        float w0 = 0.62f - flux(), w1 = 0.82f + flux();
        float q;
        int flag = 0;
        if (h < 0.5f) {
            v.toast("THE SOLDER NEVER MELTED - HOLD LONGER" + (solderPadKind == 1 && h < 0.45f ? " OR TURN THE IRON UP (BIG PADS NEED 400°C+)" : ""), G.YELLOW);
            return;
        } else if (h < w0) {
            q = 0.2f + (h - 0.5f) / (w0 - 0.5f) * 0.25f;
            flag = 1;
            v.toast("COLD JOINT - DULL AND GRAINY", G.YELLOW);
        } else if (h <= w1) {
            float mid = (w0 + w1) / 2;
            q = 1f - Math.abs(h - mid) / (w1 - w0) * 0.5f;
            v.sfx.play(Sfx.TORQUE, 0.4f);
        } else if (h < 0.95f) {
            q = 0.5f;
            boolean smallPad = solderPadKind == 0 || solderPadKind == 2;
            if (smallPad && rnd.nextFloat() < 0.55f) {
                flag = 2;
                v.toast("SOLDER BRIDGE TO THE NEXT PAD!", G.RED);
            } else v.toast("OVERHEATED - TOO MUCH SOLDER", G.YELLOW);
        } else {
            q = 0.1f;
            flag = 3;
            v.toast("PAD LIFTED - THE BOARD IS DAMAGED", G.RED);
            v.sfx.play(Sfx.STRIP, 0.7f);
        }
        switch (holdA) {
            case 0: {
                int out = holdB, w = holdC;
                int pos = -1;
                for (int p = 0; p < 4; p++) if (Elec.outputAtPos(b, p) == out) pos = p;
                if (pos >= 0 && b.wireCut[pos][w] == 2) {
                    q = Math.min(q, 0.3f);
                    v.toast("WIRE TOO SHORT - THE JOINT IS UNDER TENSION", G.YELLOW);
                }
                b.mJoint[out][w] = q;
                b.mFlag[out][w] = flag;
                if (flag == 3) damage(b.esc, "Lifted motor pad");
                if (b.motorWiresDone()) v.toast("ALL MOTOR WIRES SOLDERED", G.GREEN);
                break;
            }
            case 1:
                b.pigJoint[holdB] = q;
                b.pigFlag[holdB] = flag;
                if (flag == 3) damage(b.esc, "Lifted battery pad");
                break;
            case 2:
                b.capJoint[holdB] = q;
                b.capFlag[holdB] = flag;
                break;
            case 3: {
                int d = holdB / 10, w = holdB % 10;
                b.devJoint[d][w] = q;
                b.devFlag[d][w] = flag;
                if (flag == 3) damage(b.fc, "Lifted pad " + Build.FC_PAD[b.devPad[d][w]]);
                break;
            }
        }
        b.smokeTest = false;
    }

    private void damage(int uid, String note) {
        Game.Item it = gm().item(uid);
        if (it != null) {
            it.damaged = true;
            it.note = note;
        }
    }

    // ---------------------------------------------------------------- cutters & meter
    private void cutterTap(float x, float y) {
        Build b = b();
        if (flipped || b.esc < 0 || b.fc >= 0) {
            v.toast(b.esc < 0 ? "INSTALL THE ESC FIRST SO YOU KNOW HOW LONG THE WIRES MUST BE" : "NOTHING TO CUT HERE", G.DIM);
            return;
        }
        for (int pos = 0; pos < 4; pos++) {
            if (b.motor[pos] < 0) continue;
            for (int w = 0; w < 3; w++) {
                if (b.wireCut[pos][w] != 0) continue;
                if (near(x, y, wireEndX(pos, 0, w, false), wireEndY(pos, 0, w, false), 6) || near(x, y, mx(pos) * 0.6f, my(pos) * 0.6f, 8)) {
                    cutM = pos;
                    cutW = w;
                    cutPhase = rnd.nextFloat() * 3;
                    return;
                }
            }
        }
    }

    private void doCut() {
        Build b = b();
        float t = cutT();
        int r;
        if (t < 0.92f) r = 2;
        else if (t <= 1.02f) r = 1;
        else r = 3;
        b.wireCut[cutM][cutW] = r;
        v.sfx.play(Sfx.SNAP, 0.8f);
        v.toast(r == 1 ? "PERFECT LENGTH" : r == 2 ? "TOO SHORT! THE WIRE BARELY REACHES" : "A BIT LONG - SLOPPY BUT OK", r == 1 ? G.GREEN : r == 2 ? G.RED : G.YELLOW);
        cutM = -1;
        cutW = -1;
    }

    private void meterTap(float x, float y) {
        Build b = b();
        int pad = -1;
        boolean isFc = false;
        if (b.fc >= 0 && b.top < 0) {
            Parts.Part fc = gm().partOf(b.fc);
            for (int p = 0; p < Build.FC_PAD.length; p++) if (Build.fcHasPad(fc, p) && near(x, y, fcPx(p), fcPy(p), 1.4f)) {
                pad = p;
                isFc = true;
            }
        } else if (b.esc >= 0) {
            for (int pd = 0; pd < 2; pd++) if (near(x, y, batPx(pd), batPy(pd), 3)) pad = 100 + pd;
        }
        if (pad < 0) return;
        if (meterA < 0) {
            meterA = pad;
            meterMsg = "PROBE ON " + (isFc ? Build.FC_PAD[pad] : pad == 100 ? "BAT +" : "BAT -") + " - TAP A SECOND PAD";
            meterT = 4;
            v.sfx.play(Sfx.TAP, 0.6f);
            return;
        }
        boolean shorted = false;
        if (meterA >= 100 && pad >= 100) shorted = meterA != pad && Elec.hardShort(gm()) != null && Elec.hardShort(gm()).contains("battery");
        else if (meterA < 100 && pad < 100) {
            if (Elec.isGnd(meterA) && Elec.isGnd(pad)) shorted = true;
            for (int d = 0; d < 3; d++) for (int w = 0; w < b.devPad[d].length; w++)
                if (b.devFlag[d][w] == 2 && ((b.devPad[d][w] == meterA && Elec.neighbourPad(meterA) == pad) || (b.devPad[d][w] == pad && Elec.neighbourPad(pad) == meterA))) shorted = true;
        }
        meterMsg = shorted ? "BEEEP - 0.2 Ω  CONNECTED (SHORT?)" : "OL - NOT CONNECTED";
        meterT = 3;
        v.sfx.play(shorted ? Sfx.IRON : Sfx.TAP, 0.8f);
        meterA = -1;
    }

    // ---------------------------------------------------------------- buttons
    @Override
    void button(int id) {
        Build b = b();
        if (id >= B_TOOL && id < B_TOOL + 5) {
            tool = id - B_TOOL;
            cutM = -1;
            meterA = -1;
            return;
        }
        switch (id) {
            case B_FLIP:
                if (!b.hasFrame()) return;
                if (b.esc >= 0 && !flipped) v.toast("BOTTOM VIEW (THE STACK IS ON TOP)", G.DIM);
                flipped = !flipped;
                v.sfx.play(Sfx.WHOOSH, 0.4f);
                return;
            case B_ZOOM: zoomed = !zoomed; return;
            case B_ROT: placeRot = (placeRot + 1) % 4; return;
            case B_EXIT: back(); return;
            case B_BAT:
                if (v.benchBattery < 0) {
                    v.toast("DRAG A BATTERY FROM THE TRAY ONTO THE MAT", G.DIM);
                    return;
                }
                if (!v.batteryOn && b.anyPropOn()) {
                    v.dialog("PROPS ARE ON!", "Testing with props installed is dangerous. Plug in the battery anyway?", new String[]{"NO", "PLUG IN"}, new int[]{G.B_PRIMARY, G.B_DANGER},
                            new GameView.DialogCb() {
                                @Override
                                public void on(int i) {
                                    if (i == 1) v.setBattery(true);
                                }
                            });
                    return;
                }
                if (!v.batteryOn && b.dev[2] >= 0 && b.antenna < 0) v.toast("CAREFUL: THE VTX HAS NO ANTENNA!", G.RED);
                v.setBattery(!v.batteryOn);
                return;
            case B_USB:
                if (b.fc < 0) return;
                v.setUsb(!v.usbOn);
                if (v.usbOn && bootHeld) {
                    v.dfu = true;
                    v.toast("BOARD IN DFU MODE - FLASH IT IN FC CONFIGURATOR", G.CYAN);
                } else if (!v.usbOn) v.dfu = false;
                return;
            case B_BOOT:
                bootHeld = !bootHeld;
                return;
            case B_VTXBTN:
                if (!Elec.devWorks(gm(), 2, v.batteryOn, false, v.benchBatteryPart())) {
                    v.toast("THE VTX BUTTON ONLY WORKS WHEN THE VTX HAS POWER", G.DIM);
                    return;
                }
                b.vtxChan++;
                if (b.vtxChan > 8) {
                    b.vtxChan = 1;
                    b.vtxBand = (b.vtxBand + 1) % 5;
                }
                v.sfx.play(Sfx.TAP, 0.6f);
                return;
        }
    }

    @Override
    boolean back() {
        if (cutM >= 0) {
            cutM = -1;
            return true;
        }
        if (selWireKind >= 0) {
            selWireKind = -1;
            return true;
        }
        v.room.view = RoomScreen.V_FRONT;
        v.go(v.room);
        return true;
    }
}
