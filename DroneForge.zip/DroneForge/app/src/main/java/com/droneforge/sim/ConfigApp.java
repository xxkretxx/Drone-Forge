package com.droneforge.sim;

import android.graphics.Canvas;
import android.graphics.Paint;

import java.util.Locale;

/** Betaflight-style flight controller configurator running on the workshop PC. */
final class ConfigApp {
    private final GameView v;
    private final PcScreen pc;
    private final G g;
    static final String[] TABS = {"Setup", "Ports", "Configuration", "Receiver", "Modes", "Motors", "Video TX", "Firmware Flasher"};
    static final int T_SETUP = 0, T_PORTS = 1, T_CONF = 2, T_RX = 3, T_MODES = 4, T_MOTORS = 5, T_VTX = 6, T_FLASH = 7;
    int tab = T_SETUP;
    boolean connected;
    float flashT = -1;
    int target = 0, version = 0;
    boolean fullErase = true;
    boolean propsOffAck;
    final float[] motorVal = {1000, 1000, 1000, 1000};
    float master = 1000;
    private int dragSlider = -1;
    private float sl, sr; // slider track extents
    private boolean dirPanel;
    int wizard = -1;            // reorder wizard step 0..3, -1 off
    private final int[] newRemap = new int[4];
    private final boolean[] spun = new boolean[4];
    private final float[] spinT = new float[4];
    private float rxOkT, savedT = -1;
    private String toastMsg;
    // motor animation
    final float[] rotA = new float[4];

    ConfigApp(GameView v, PcScreen pc) {
        this.v = v;
        this.pc = pc;
        this.g = v.g;
    }

    private int id(int n) {
        return pc.aid(PcScreen.APP_CONFIG, n);
    }

    Build b() {
        return v.game.build;
    }

    Parts.Part fc() {
        return v.game.partOf(b().fc);
    }

    boolean canTalk() {
        return connected && v.usbOn && b().fc >= 0 && !b().fcDead && !b().bricked;
    }

    void update(float dt) {
        Build b = b();
        if (connected && (!v.usbOn || b.fc < 0)) {
            connected = false;
            stopMotors();
        }
        if (flashT >= 0) {
            flashT += dt;
            if (flashT > 6.5f) finishFlash();
        }
        if (savedT >= 0) {
            savedT += dt;
            if (savedT > 1.6f) savedT = -1;
        }
        // receiver check
        if (canTalk() && tab == T_RX && Elec.rxLink(v.game, v.batteryOn, v.usbOn, v.radioOn)) {
            float dev = 0;
            for (int i = 0; i < 4; i++) dev = Math.max(dev, Math.abs(v.radio.ch[i] - (i == 2 ? 1000 : 1500)));
            if (dev > 150) rxOkT += dt;
            if (rxOkT > 1f && !b.rxTest) {
                b.rxTest = true;
                v.sfx.play(Sfx.SUCCESS, 0.6f);
                v.toast("RECEIVER CHECK PASSED - STICKS MOVE THE RIGHT CHANNELS", G.GREEN);
            }
        }
        // motors
        boolean spinning = false;
        float maxT = 1000;
        for (int m = 0; m < 4; m++) {
            float val = Math.max(motorVal[m], master);
            boolean on = val > 1040 && motorsLive();
            if (on) {
                int pos = Elec.spinsPos(b, m);
                spinning = true;
                maxT = Math.max(maxT, val);
                spinT[m] += dt;
                boolean cw = Elec.actualCW(b, pos);
                rotA[pos] += (cw ? 1 : -1) * dt * (val - 1000) * 1.6f;
                if (spinT[m] > 1.2f) spun[m] = true;
                String prob = Elec.motorProblem(v.game, pos);
                if (prob != null && spinT[m] > 1.5f && spinT[m] - dt <= 1.5f) motorFault(pos, prob);
                if (b.propType[pos] >= 0 && spinT[m] > 0.3f && spinT[m] - dt <= 0.3f) accident(pos);
            } else spinT[m] = 0;
        }
        if (wizard >= 0 && motorsLive()) {
            int pos = Elec.outputPos(wizard, b.escRot);
            rotA[pos] += (Elec.actualCW(b, pos) ? 1 : -1) * dt * 240;
            spinning = true;
            maxT = Math.max(maxT, 1150);
        }
        if (spinning && v.motorStream == 0) v.motorStream = v.sfx.play(Sfx.MOTOR, 0.5f, 0.8f, true);
        if (v.motorStream != 0) {
            if (!spinning) {
                v.sfx.stop(v.motorStream);
                v.motorStream = 0;
            } else v.sfx.setRate(v.motorStream, 0.7f + (maxT - 1000) / 600f);
        }
        if (!b.motorTest && spun[0] && spun[1] && spun[2] && spun[3] && Elec.motorOrderOk(b) && Elec.directionsOk(b)) {
            boolean probs = false;
            for (int p = 0; p < 4; p++) if (Elec.motorProblem(v.game, p) != null) probs = true;
            if (!probs) {
                b.motorTest = true;
                v.sfx.play(Sfx.SUCCESS, 0.6f);
                v.toast("MOTOR TEST PASSED - ORDER AND DIRECTION CORRECT", G.GREEN);
            }
        }
    }

    boolean motorsLive() {
        Build b = b();
        return canTalk() && v.batteryOn && Elec.powerPath(b) && b.harness && !b.escDead && propsOffAck && tab == T_MOTORS;
    }

    void stopMotors() {
        for (int i = 0; i < 4; i++) motorVal[i] = 1000;
        master = 1000;
    }

    private void motorFault(int pos, String prob) {
        Build b = b();
        stopMotors();
        v.sfx.play(Sfx.ERROR, 0.8f);
        if (prob.startsWith("Grinding")) {
            b.motorDead[pos] = true;
            Game.Item it = v.game.item(b.motor[pos]);
            if (it != null) {
                it.damaged = true;
                it.note = "Windings scratched by a too-long screw";
            }
            v.sfx.play(Sfx.SPARK, 0.6f);
        } else if (prob.startsWith("Solder bridge")) {
            b.escDead = true;
            Game.Item it = v.game.item(b.esc);
            if (it != null) {
                it.damaged = true;
                it.note = "Burnt: shorted motor phases";
            }
            v.sfx.play(Sfx.SPARK, 0.8f);
        }
        v.info("MOTOR " + Build.POS_NAME[pos], prob + ".");
    }

    private void accident(int pos) {
        stopMotors();
        v.sfx.play(Sfx.SPARK, 0.5f);
        v.vibrate(400);
        v.game.money -= 60;
        b().propType[pos] = -1;
        v.info("OUCH! PROPS WERE ON", "The drone jumped off the bench and a prop clipped your hand. First aid kit, a broken prop and a bad scare: -$60.\n\nNEVER spin motors with props installed!");
    }

    // ---------------------------------------------------------------- flashing
    private void startFlash() {
        if (!v.usbOn || b().fc < 0 || b().fcDead) {
            v.info("NO BOARD", "Connect the flight controller with the USB cable first (on the build bench).");
            return;
        }
        if (b().bricked && !v.dfu) {
            v.info("NO DFU DEVICE", "The board has broken firmware and does not enter the bootloader by itself.\n\nOn the build bench: unplug USB, press BOOT BTN (hold), then plug USB in again.");
            return;
        }
        connected = false;
        flashT = 0;
        v.sfx.play(Sfx.USB_OUT, 0.5f);
    }

    private void finishFlash() {
        flashT = -1;
        Build b = b();
        Parts.Part fc = fc();
        String tg = Elec.TARGETS[target];
        if (fc == null) return;
        b.fwTarget = tg;
        b.flashed = version == 0;
        b.bricked = !tg.equals(fc.target);
        v.dfu = false;
        if (fullErase || b.bricked) {
            b.serialRxUart = 0;
            b.saUart = 0;
            b.rxProvider = 0;
            b.escProto = 2;
            b.reversed = false;
            b.armAux = 0;
            b.boardYaw = 0;
            b.accelCal = false;
            b.craftName = "";
            for (int i = 0; i < 4; i++) b.remap[i] = i;
            b.motorTest = false;
            b.rxTest = false;
        }
        if (b.bricked) {
            v.sfx.play(Sfx.ERROR, 0.8f);
            v.info("FLASH FINISHED - BOARD NOT RESPONDING", "You flashed " + tg + " but the board printed on the FC is " + fc.target + ". It no longer boots.\n\n"
                    + "Recover it: on the build bench hold the BOOT button while plugging in USB (DFU mode), then flash the correct target.");
        } else {
            v.sfx.play(Sfx.FLASHED, 0.8f);
            v.toast("FIRMWARE FLASHED: " + tg + (version == 0 ? " 4.5.1" : " 4.4.3"), G.GREEN);
        }
    }

    // ---------------------------------------------------------------- drawing
    void draw(Canvas c, PcScreen.Win w, float l, float t, float r, float b, boolean in) {
        Build bd = b();
        g.p.setShader(null);
        g.p.setColor(0xFF111418);
        c.drawRect(l, t, r, b, g.p);
        // header
        g.p.setColor(0xFF1A1E24);
        c.drawRect(l, t, r, t + 64, g.p);
        g.text(c, "FC", l + 24, t + 32, 30, G.YELLOW, g.bold, Paint.Align.LEFT);
        g.text(c, "CONFIGURATOR", l + 64, t + 32, 26, G.TEXT, g.bold, Paint.Align.LEFT);
        Parts.Part fc = fc();
        String status;
        if (flashT >= 0) status = "Flashing...";
        else if (canTalk()) status = "Connected: " + bd.fwName(fc) + " " + (bd.flashed ? "4.5.1" : "4.3.2 (outdated)");
        else if (v.usbOn && bd.fc >= 0 && bd.bricked) status = "USB device not responding (no firmware)";
        else if (v.usbOn && bd.fc >= 0) status = "Flight controller found on COM3";
        else status = "No USB device - plug in the drone on the bench";
        g.text(c, status, l + 270, t + 32, 18, canTalk() ? G.GREEN : G.DIM, g.mono, Paint.Align.LEFT);
        if (v.batteryOn && canTalk()) {
            Parts.Part bat = v.benchBatteryPart();
            g.text(c, String.format(Locale.US, "%.2f V", bat == null ? 0 : bat.cells * 4.15f), r - 270, t + 32, 20, G.YELLOW, g.mono, Paint.Align.RIGHT);
        }
        g.button(c, id(1), r - 230, t + 12, r - 20, t + 52, connected ? "DISCONNECT" : "CONNECT", connected ? G.B_DANGER : G.B_GOOD);
        // tabs
        for (int i = 0; i < TABS.length; i++) {
            float y = t + 80 + i * 50;
            boolean sel = i == tab;
            g.p.setColor(sel ? 0xFF2A2F37 : 0x00000000);
            if (sel) c.drawRect(l, y, l + 220, y + 46, g.p);
            if (sel) {
                g.p.setColor(G.YELLOW);
                c.drawRect(l, y, l + 4, y + 46, g.p);
            }
            g.text(c, TABS[i], l + 22, y + 23, 20, sel ? G.TEXT : G.DIM, g.bold, Paint.Align.LEFT);
            if (in) g.hit(id(10 + i), l, y, l + 220, y + 46);
        }
        float cl = l + 240, ct = t + 80, cr = r - 20, cb = b - 20;
        if (tab != T_FLASH && !canTalk()) {
            g.text(c, flashT >= 0 ? "Flashing in progress..." : "Connect to the flight controller to use this tab.", (cl + cr) / 2, (ct + cb) / 2, 24, G.DIM2, g.med, Paint.Align.CENTER);
            if (tab == T_FLASH || flashT >= 0) drawFlash(c, cl, ct, cr, cb, in);
            return;
        }
        switch (tab) {
            case T_SETUP: drawSetup(c, cl, ct, cr, cb, in); break;
            case T_PORTS: drawPorts(c, cl, ct, cr, cb, in); break;
            case T_CONF: drawConf(c, cl, ct, cr, cb, in); break;
            case T_RX: drawRx(c, cl, ct, cr, cb, in); break;
            case T_MODES: drawModes(c, cl, ct, cr, cb, in); break;
            case T_MOTORS: drawMotors(c, cl, ct, cr, cb, in); break;
            case T_VTX: drawVtx(c, cl, ct, cr, cb, in); break;
            case T_FLASH: drawFlash(c, cl, ct, cr, cb, in); break;
        }
        if (tab != T_FLASH && tab != T_MOTORS) {
            g.button(c, id(2), cr - 220, cb - 54, cr, cb, savedT >= 0 ? "SAVED ✓" : "SAVE & REBOOT", G.B_GOOD);
        }
    }

    private void title(Canvas c, String s, float x, float y) {
        g.text(c, s, x, y, 24, G.YELLOW, g.bold, Paint.Align.LEFT);
    }

    private void drawSetup(Canvas c, float l, float t, float r, float b, boolean in) {
        Build bd = b();
        Parts.Part fc = fc();
        title(c, "SETUP", l, t + 10);
        String[] k = {"Target", "Firmware", "Board", "Accelerometer", "Arming"};
        String arm = !bd.accelCal ? "ACC NOT CALIBRATED" : bd.armAux == 0 ? "NO ARM SWITCH" : !Elec.rxLink(v.game, v.batteryOn, v.usbOn, v.radioOn) ? "RXLOSS" : "READY";
        String[] val = {bd.fwName(fc), bd.flashed ? "4.5.1 (latest)" : "4.3.2 - outdated, please update", fc == null ? "" : fc.full(), bd.accelCal ? "calibrated" : "NOT calibrated", arm};
        for (int i = 0; i < k.length; i++) {
            g.text(c, k[i], l, t + 60 + i * 36, 19, G.DIM, g.med, Paint.Align.LEFT);
            g.text(c, val[i], l + 170, t + 60 + i * 36, 19, i == 4 && !arm.equals("READY") ? G.RED : G.TEXT, g.mono, Paint.Align.LEFT);
        }
        g.button(c, id(20), l, t + 260, l + 300, t + 306, "CALIBRATE ACCELEROMETER", G.B_DARK);
        // 3D model (top view)
        float cx = (l + r) / 2 + 250, cy = t + 220;
        int err = ((bd.fcRot - bd.boardYaw) % 4 + 4) % 4;
        c.save();
        c.rotate(err * 90, cx, cy);
        g.s.setColor(0xFF8A94A3);
        g.s.setStrokeWidth(10);
        c.drawLine(cx - 90, cy - 90, cx + 90, cy + 90, g.s);
        c.drawLine(cx + 90, cy - 90, cx - 90, cy + 90, g.s);
        for (int i = 0; i < 4; i++) {
            g.p.setColor(i == 1 || i == 3 ? G.ORANGE : 0xFF5C6673);
            c.drawCircle(cx + Build.MX[i] * 90, cy + Build.MY[i] * 90, 34, g.p);
        }
        g.p.setColor(G.YELLOW);
        g.path.reset();
        g.path.moveTo(cx, cy - 70);
        g.path.lineTo(cx - 22, cy - 30);
        g.path.lineTo(cx + 22, cy - 30);
        g.path.close();
        c.drawPath(g.path, g.p);
        c.restore();
        g.text(c, "3D model (nose = arrow)", cx, cy + 160, 17, G.DIM, g.med, Paint.Align.CENTER);
        g.text(c, err == 0 ? "Model matches the drone on the bench." : "Model is turned " + (err * 90) + "°! The FC is mounted rotated - fix it in Configuration > Board alignment.",
                cx, cy + 190, 17, err == 0 ? G.GREEN : G.RED, g.med, Paint.Align.CENTER);
    }

    private void drawPorts(Canvas c, float l, float t, float r, float b, boolean in) {
        Build bd = b();
        Parts.Part fc = fc();
        title(c, "PORTS", l, t + 10);
        g.text(c, "Identifier", l, t + 60, 18, G.DIM, g.bold, Paint.Align.LEFT);
        g.text(c, "Serial RX", l + 220, t + 60, 18, G.DIM, g.bold, Paint.Align.LEFT);
        g.text(c, "Peripherals", l + 420, t + 60, 18, G.DIM, g.bold, Paint.Align.LEFT);
        g.text(c, "USB VCP", l, t + 100, 19, G.TEXT, g.mono, Paint.Align.LEFT);
        g.text(c, "MSP (configurator)", l + 220, t + 100, 17, G.DIM2, g.med, Paint.Align.LEFT);
        int n = fc == null ? 0 : fc.uarts;
        for (int u = 1; u <= n; u++) {
            float y = t + 100 + u * 48;
            g.text(c, "UART" + u, l, y, 19, G.TEXT, g.mono, Paint.Align.LEFT);
            g.toggle(c, id(30 + u), l + 220, y, bd.serialRxUart == u);
            g.toggle(c, id(40 + u), l + 420, y, bd.saUart == u);
            g.text(c, "VTX (SmartAudio)", l + 484, y, 16, G.DIM, g.med, Paint.Align.LEFT);
        }
        g.text(c, "Serial RX must be enabled on the UART your receiver is soldered to (R" + "x/Tx pads of the same number).", l, b - 90, 17, G.DIM, g.med, Paint.Align.LEFT);
    }

    private void drawConf(Canvas c, float l, float t, float r, float b, boolean in) {
        Build bd = b();
        title(c, "CONFIGURATION", l, t + 10);
        float y = t + 70;
        row(c, l, y, "ESC / Motor protocol", Elec.PROTOS[bd.escProto], id(50));
        y += 60;
        g.text(c, "Motor direction is reversed (props out)", l, y, 19, G.TEXT, g.med, Paint.Align.LEFT);
        g.toggle(c, id(51), l + 480, y, bd.reversed);
        y += 60;
        row(c, l, y, "Board alignment - yaw", (bd.boardYaw * 90) + "°", id(52));
        y += 60;
        g.text(c, "Receiver mode", l, y, 19, G.TEXT, g.med, Paint.Align.LEFT);
        g.text(c, "Serial-based receiver", l + 480, y, 19, G.DIM, g.mono, Paint.Align.LEFT);
        y += 60;
        row(c, l, y, "Serial receiver provider", Elec.PROVIDERS[bd.rxProvider], id(53));
        y += 60;
        Game.Order o = v.game.order(bd.orderId);
        row(c, l, y, "Craft name (shown in the OSD)", bd.craftName.isEmpty() ? "-" : bd.craftName, id(54));
        if (o != null) g.text(c, "tap to use the customer's name", l + 760, y, 15, G.DIM2, g.med, Paint.Align.LEFT);
    }

    private void row(Canvas c, float l, float y, String label, String val, int bid) {
        g.text(c, label, l, y, 19, G.TEXT, g.med, Paint.Align.LEFT);
        g.button(c, bid, l + 480, y - 20, l + 740, y + 20, val, G.B_DARK);
    }

    private void drawRx(Canvas c, float l, float t, float r, float b, boolean in) {
        Build bd = b();
        title(c, "RECEIVER", l, t + 10);
        boolean link = Elec.rxLink(v.game, v.batteryOn, v.usbOn, v.radioOn);
        String[] nm = {"Roll [A]", "Pitch [E]", "Throttle [T]", "Yaw [R]", "AUX 1", "AUX 2", "AUX 3", "AUX 4"};
        for (int i = 0; i < 8; i++) {
            float y = t + 60 + i * 40;
            float val = link ? v.radio.ch[i] : (i == 2 ? 885 : 1500);
            g.text(c, nm[i], l, y, 18, G.TEXT, g.med, Paint.Align.LEFT);
            g.bar(c, l + 150, y - 10, l + 650, y + 10, (val - 885) / (2115 - 885), link ? G.YELLOW : 0xFF3A414B);
            g.text(c, String.valueOf((int) val), l + 700, y, 17, G.DIM, g.mono, Paint.Align.RIGHT);
        }
        float x = l + 760;
        g.text(c, "Status", x, t + 60, 19, G.DIM, g.bold, Paint.Align.LEFT);
        String why;
        if (link) why = "Receiving data. Move the sticks on the radio!";
        else if (bd.dev[0] < 0) why = "No receiver installed.";
        else if (!Elec.devWorks(v.game, 0, v.batteryOn, v.usbOn, v.benchBatteryPart())) why = bd.rxDead ? "Receiver is dead (wrong voltage?)." : "Receiver has no power - check 5V/GND wires.";
        else if (Elec.rxWiredUart(bd) == 0)
            why = Elec.rxNotCrossed(bd) ? "No data: TX and RX are not crossed! RX TX must go to an FC R pad." : "No data: receiver signal wires not on a matching UART.";
        else if (bd.serialRxUart != Elec.rxWiredUart(bd)) why = "Receiver is on UART" + Elec.rxWiredUart(bd) + " but Serial RX is not enabled there (Ports tab).";
        else if (bd.rxProvider != 2) why = "Receiver provider must be CRSF for ELRS (Configuration tab).";
        else if (!bd.bound) why = "Receiver not bound to the radio. Use 'Bind receiver' and press BIND on the radio.";
        else if (!v.radioOn) why = "Radio is switched off.";
        else why = "No link.";
        g.para(c, why, x, t + 100, r - x - 10, 19, link ? G.GREEN : 0xFFFFB0A0, g.med, 26);
        g.button(c, id(60), x, t + 230, x + 250, t + 276, "BIND RECEIVER", G.B_CYAN);
        g.text(c, "Channel map: AETR1234", x, t + 310, 17, G.DIM2, g.mono, Paint.Align.LEFT);
    }

    private void drawModes(Canvas c, float l, float t, float r, float b, boolean in) {
        Build bd = b();
        title(c, "MODES", l, t + 10);
        boolean link = Elec.rxLink(v.game, v.batteryOn, v.usbOn, v.radioOn);
        float y = t + 80;
        g.text(c, "ARM", l, y, 24, G.TEXT, g.bold, Paint.Align.LEFT);
        g.button(c, id(70), l + 90, y - 22, l + 230, y + 22, bd.armAux == 0 ? "AUX ?" : "AUX " + bd.armAux, G.B_DARK);
        float bl = l + 260, br = r - 140;
        g.bar(c, bl, y - 8, br, y + 8, 0, 0);
        float lo = bl + (bd.armLo - 900f) / 1200f * (br - bl), hi = bl + (bd.armHi - 900f) / 1200f * (br - bl);
        g.p.setColor(0xAA3DDC84);
        c.drawRect(lo, y - 8, hi, y + 8, g.p);
        if (link && bd.armAux > 0) {
            float val = v.radio.ch[3 + bd.armAux];
            float mx = bl + (val - 900f) / 1200f * (br - bl);
            g.p.setColor(G.YELLOW);
            c.drawRect(mx - 3, y - 18, mx + 3, y + 18, g.p);
            boolean act = val >= bd.armLo && val <= bd.armHi;
            g.chip(c, r - 120, y, act ? "ACTIVE" : "OFF", act ? G.GREEN : G.DIM, act);
        }
        g.text(c, bd.armLo + "", lo, y + 34, 15, G.DIM, g.mono, Paint.Align.CENTER);
        g.text(c, bd.armHi + "", hi, y + 34, 15, G.DIM, g.mono, Paint.Align.CENTER);
        g.button(c, id(71), l + 260, y + 50, l + 330, y + 90, "LO-", G.B_DARK);
        g.button(c, id(72), l + 340, y + 50, l + 410, y + 90, "LO+", G.B_DARK);
        g.button(c, id(73), l + 430, y + 50, l + 500, y + 90, "HI-", G.B_DARK);
        g.button(c, id(74), l + 510, y + 50, l + 580, y + 90, "HI+", G.B_DARK);
        g.para(c, "Pick the AUX channel of the ARM switch (SA on the radio = AUX 1) and drag the range over the switch's 'up' position (around 2000). Flip the switch on the radio and the yellow marker moves.",
                l, y + 140, r - l - 40, 18, G.DIM, g.med, 26);
    }

    private void drawMotors(Canvas c, float l, float t, float r, float b, boolean in) {
        Build bd = b();
        title(c, "MOTORS", l, t + 10);
        // bench cam
        float cx = l + 230, cy = t + 250;
        g.r.set(l, t + 40, l + 460, t + 460);
        g.p.setColor(0xFF0A0C0F);
        c.drawRect(g.r, g.p);
        g.text(c, "BENCH CAM", l + 12, t + 56, 14, G.RED, g.mono, Paint.Align.LEFT);
        v.buildScreen.drawDrone(c, cx, cy, 1.35f, false);
        for (int pos = 0; pos < 4; pos++) {
            float mx = cx + Build.MX[pos] * 0.707f * 112 * 1.35f, my = cy + Build.MY[pos] * 0.707f * 112 * 1.35f;
            boolean exp = Elec.expectedCW(bd, pos);
            arrowArc(c, mx, my, 44, exp, 0x66FFFFFF);
            boolean spinning = false;
            for (int m = 0; m < 4; m++) if (Elec.spinsPos(bd, m) == pos && Math.max(motorVal[m], master) > 1040 && motorsLive()) spinning = true;
            if (wizard >= 0 && motorsLive() && Elec.outputPos(wizard, bd.escRot) == pos) spinning = true;
            if (spinning) arrowArc(c, mx, my, 34, Elec.actualCW(bd, pos), Elec.actualCW(bd, pos) == exp ? G.GREEN : G.RED);
            if (wizard >= 0 && in) g.hit(id(150 + pos), mx - 50, my - 50, mx + 50, my + 50);
        }
        g.text(c, "white = expected direction, green/red = actual", l + 230, t + 445, 14, G.DIM, g.med, Paint.Align.CENTER);
        // controls
        float x = l + 500;
        g.toggle(c, id(80), x, t + 60, propsOffAck);
        g.text(c, "I understand the risks: PROPS ARE REMOVED", x + 66, t + 60, 18, propsOffAck ? G.TEXT : G.RED, g.bold, Paint.Align.LEFT);
        if (!v.batteryOn) g.text(c, "Plug in a battery to spin the motors.", x, t + 100, 18, G.YELLOW, g.med, Paint.Align.LEFT);
        sl = x + 80;
        sr = r - 110;
        String[] nm = {"Motor 1", "Motor 2", "Motor 3", "Motor 4", "Master"};
        for (int i = 0; i < 5; i++) {
            float y = t + 150 + i * 52;
            float val = i < 4 ? motorVal[i] : master;
            g.text(c, nm[i], x, y, 18, G.TEXT, g.med, Paint.Align.LEFT);
            g.bar(c, sl, y - 10, sr, y + 10, (val - 1000) / 1000f, i < 4 ? G.ORANGE : G.YELLOW);
            g.text(c, String.valueOf((int) val), r - 20, y, 16, G.DIM, g.mono, Paint.Align.RIGHT);
        }
        float by = t + 430;
        g.button(c, id(81), x, by, x + 230, by + 46, "MOTOR DIRECTION", G.B_DARK);
        g.button(c, id(82), x + 250, by, x + 480, by + 46, wizard >= 0 ? "STOP WIZARD" : "REORDER MOTORS", G.B_DARK);
        g.button(c, id(83), x + 500, by, x + 640, by + 46, "STOP", G.B_DANGER);
        if (wizard >= 0) {
            g.panel(c, x, by - 120, r, by - 14);
            g.text(c, "Motor output " + (wizard + 1) + " is spinning. Tap the motor that spins on the bench cam.", x + 20, by - 70, 18, G.CYAN, g.bold, Paint.Align.LEFT);
        }
        if (dirPanel) {
            g.panel(c, x, by - 160, r, by - 10);
            g.text(c, "Reverse direction per motor (sent to the ESC via DShot)", x + 20, by - 132, 18, G.TEXT, g.bold, Paint.Align.LEFT);
            for (int m = 0; m < 4; m++) {
                float xx = x + 20 + m * 150;
                g.text(c, "M" + (m + 1), xx, by - 80, 18, G.DIM, g.bold, Paint.Align.LEFT);
                g.toggle(c, id(90 + m), xx + 44, by - 80, bd.dirRev[bd.remap[m]]);
            }
            g.button(c, id(95), r - 120, by - 60, r - 20, by - 20, "DONE", G.B_GOOD);
        }
    }

    private void arrowArc(Canvas c, float x, float y, float rad, boolean cw, int col) {
        g.s.setColor(col);
        g.s.setStrokeWidth(4);
        g.r.set(x - rad, y - rad, x + rad, y + rad);
        float sweep = cw ? 250 : -250;
        c.drawArc(g.r, -90, sweep, false, g.s);
        double a = Math.toRadians(-90 + sweep);
        float ax = x + (float) Math.cos(a) * rad, ay = y + (float) Math.sin(a) * rad;
        float tx = (float) -Math.sin(a), ty = (float) Math.cos(a);
        if (!cw) {
            tx = -tx;
            ty = -ty;
        }
        float nx = -ty, ny = tx;
        g.path.reset();
        g.path.moveTo(ax + tx * 14, ay + ty * 14);
        g.path.lineTo(ax + nx * 9, ay + ny * 9);
        g.path.lineTo(ax - nx * 9, ay - ny * 9);
        g.path.close();
        g.p.setColor(col);
        c.drawPath(g.path, g.p);
    }

    private void drawVtx(Canvas c, float l, float t, float r, float b, boolean in) {
        Build bd = b();
        title(c, "VIDEO TRANSMITTER", l, t + 10);
        boolean saWired = bd.dev[2] >= 0 && bd.devPad[2][3] >= 0 && Build.isTx(bd.devPad[2][3]) && Build.uartOf(bd.devPad[2][3]) == bd.saUart && bd.devJoint[2][3] > 0.2f;
        boolean vtxOn = Elec.devWorks(v.game, 2, v.batteryOn, false, v.benchBatteryPart());
        if (!saWired || !vtxOn) {
            String why = !vtxOn ? "VTX not powered (plug in a battery - the VTX is not powered over USB)." : bd.devPad[2][3] < 0 ? "SmartAudio wire is not connected."
                    : "Enable 'VTX (SmartAudio)' in Ports on the UART the SmartAudio wire goes to (a Tx pad).";
            g.para(c, "VTX not detected. " + why + "\n\nWithout SmartAudio you can still change the channel with the button on the VTX (on the build bench).", l, t + 70, r - l - 40, 20, G.DIM, g.med, 28);
            return;
        }
        float y = t + 80;
        g.text(c, "Band", l, y, 20, G.TEXT, g.med, Paint.Align.LEFT);
        for (int i = 0; i < 5; i++) g.button(c, id(110 + i), l + 160 + i * 80, y - 22, l + 230 + i * 80, y + 22, Elec.BAND_NAME[i], bd.vtxBand == i ? G.B_PRIMARY : G.B_DARK);
        y += 70;
        g.text(c, "Channel", l, y, 20, G.TEXT, g.med, Paint.Align.LEFT);
        for (int i = 0; i < 8; i++) g.button(c, id(120 + i), l + 160 + i * 70, y - 22, l + 220 + i * 70, y + 22, String.valueOf(i + 1), bd.vtxChan == i + 1 ? G.B_PRIMARY : G.B_DARK);
        y += 70;
        g.text(c, "Power", l, y, 20, G.TEXT, g.med, Paint.Align.LEFT);
        String[] pw = {"25", "200", "400", "800"};
        for (int i = 0; i < 4; i++) g.button(c, id(130 + i), l + 160 + i * 100, y - 22, l + 250 + i * 100, y + 22, pw[i] + " mW", bd.vtxPower == i + 1 ? G.B_PRIMARY : G.B_DARK);
        y += 80;
        g.text(c, "Frequency: " + Elec.FREQ[bd.vtxBand][bd.vtxChan - 1] + " MHz", l, y, 22, G.CYAN, g.mono, Paint.Align.LEFT);
        g.text(c, "Tip: use 25 mW on the bench.", l, y + 40, 18, G.DIM, g.med, Paint.Align.LEFT);
    }

    private void drawFlash(Canvas c, float l, float t, float r, float b, boolean in) {
        title(c, "FIRMWARE FLASHER", l, t + 10);
        Parts.Part fc = fc();
        g.text(c, "Select your board (check the name printed on the flight controller!)", l, t + 56, 18, G.DIM, g.med, Paint.Align.LEFT);
        for (int i = 0; i < Elec.TARGETS.length; i++) {
            float x = l + (i % 4) * 230, y = t + 90 + (i / 4) * 56;
            g.button(c, id(160 + i), x, y, x + 215, y + 44, Elec.TARGETS[i], target == i ? G.B_PRIMARY : G.B_DARK);
        }
        float y = t + 230;
        g.text(c, "Version", l, y, 20, G.TEXT, g.med, Paint.Align.LEFT);
        g.button(c, id(170), l + 120, y - 22, l + 360, y + 22, "4.5.1 (latest stable)", version == 0 ? G.B_PRIMARY : G.B_DARK);
        g.button(c, id(171), l + 380, y - 22, l + 560, y + 22, "4.4.3", version == 1 ? G.B_PRIMARY : G.B_DARK);
        y += 64;
        g.toggle(c, id(172), l, y, fullErase);
        g.text(c, "Full chip erase (recommended for a new build - resets all settings)", l + 66, y, 18, G.TEXT, g.med, Paint.Align.LEFT);
        y += 64;
        if (flashT >= 0) {
            String st = flashT < 1.5f ? "Rebooting to bootloader (DFU)..." : flashT < 3 ? "Erasing..." : flashT < 5.5f ? "Flashing..." : "Verifying...";
            g.bar(c, l, y, r - 40, y + 26, Math.min(1, flashT / 6.5f), G.YELLOW);
            g.text(c, st, l, y + 56, 19, G.YELLOW, g.mono, Paint.Align.LEFT);
        } else {
            g.button(c, id(173), l, y, l + 300, y + 54, "FLASH FIRMWARE", v.usbOn && b().fc >= 0 ? G.B_PRIMARY : G.B_DISABLED);
            if (b().bricked) g.text(c, "Board has broken firmware. Enter DFU (hold BOOT + plug USB on the bench) and flash the right target.", l, y + 90, 17, G.RED, g.med, Paint.Align.LEFT);
        }
    }

    // ---------------------------------------------------------------- input
    boolean touch(int action, float x, float y, PcScreen.Win w) {
        if (tab != T_MOTORS || !canTalk()) return false;
        float[] r = pc.rect(w);
        float t = r[1] + 41 + 80;
        if (action == 0) {
            dragSlider = -1;
            for (int i = 0; i < 5; i++) {
                float sy = t + 150 + i * 52;
                if (Math.abs(y - sy) < 22 && x > sl - 10 && x < sr + 10) dragSlider = i;
            }
        }
        if (dragSlider >= 0 && action <= 1) {
            float val = 1000 + Math.max(0, Math.min(1, (x - sl) / (sr - sl))) * 1000;
            if (val < 1030) val = 1000;
            if (val > 1000 && !propsOffAck) {
                v.toast("CONFIRM THAT THE PROPS ARE REMOVED FIRST", G.RED);
                val = 1000;
            }
            if (dragSlider < 4) motorVal[dragSlider] = val;
            else master = val;
            return true;
        }
        if (action >= 2) dragSlider = -1;
        return false;
    }

    void button(int n) {
        Build bd = b();
        Game.Order o = v.game.order(bd.orderId);
        if (n == 1) {
            if (connected) {
                connected = false;
                stopMotors();
                return;
            }
            if (!v.usbOn || bd.fc < 0) {
                v.info("NO DEVICE", "No flight controller on USB. On the build bench, tap USB to plug the cable into the drone.");
                return;
            }
            if (bd.fcDead) {
                v.info("NO RESPONSE", "The flight controller does not respond. It looks dead.");
                return;
            }
            if (bd.bricked) {
                v.info("FAILED TO CONNECT", "No configuration received within 10 seconds. The firmware on the board is broken - use the Firmware Flasher.");
                tab = T_FLASH;
                return;
            }
            connected = true;
            v.sfx.play(Sfx.USB_IN, 0.5f);
            if (!bd.flashed) v.toast("FIRMWARE IS OUTDATED - UPDATE IT IN FIRMWARE FLASHER", G.YELLOW);
            return;
        }
        if (n == 2) {
            savedT = 0;
            v.sfx.play(Sfx.SUCCESS, 0.4f);
            return;
        }
        if (n >= 10 && n < 10 + TABS.length) {
            tab = n - 10;
            stopMotors();
            dirPanel = false;
            wizard = -1;
            return;
        }
        if (n == 20) {
            bd.accelCal = true;
            v.toast("ACCELEROMETER CALIBRATED", G.GREEN);
            return;
        }
        if (n > 30 && n <= 35) {
            int u = n - 30;
            bd.serialRxUart = bd.serialRxUart == u ? 0 : u;
            if (bd.saUart == u) bd.saUart = 0;
            return;
        }
        if (n > 40 && n <= 45) {
            int u = n - 40;
            bd.saUart = bd.saUart == u ? 0 : u;
            if (bd.serialRxUart == u) bd.serialRxUart = 0;
            return;
        }
        switch (n) {
            case 50: bd.escProto = (bd.escProto + 1) % 3; return;
            case 51: bd.reversed = !bd.reversed; return;
            case 52: bd.boardYaw = (bd.boardYaw + 1) % 4; return;
            case 53: bd.rxProvider = (bd.rxProvider + 1) % 4; return;
            case 54: bd.craftName = o == null ? "FORGE" : o.customer.split(" ")[0].toUpperCase(Locale.US); return;
            case 60:
                if (Elec.devWorks(v.game, 0, v.batteryOn, v.usbOn, v.benchBatteryPart()) && Elec.rxWiredUart(bd) > 0 && bd.serialRxUart == Elec.rxWiredUart(bd) && bd.rxProvider == 2) {
                    v.bindModeT = 60;
                    bd.bound = false;
                    v.toast("RECEIVER IN BIND MODE - NOW PRESS BIND ON THE RADIO", G.CYAN);
                } else v.toast("CAN'T TALK TO THE RECEIVER (CHECK WIRING, PORTS AND PROVIDER)", G.RED);
                return;
            case 70: bd.armAux = bd.armAux % 4 + 1; return;
            case 71: bd.armLo = Math.max(900, bd.armLo - 50); return;
            case 72: bd.armLo = Math.min(bd.armHi - 50, bd.armLo + 50); return;
            case 73: bd.armHi = Math.max(bd.armLo + 50, bd.armHi - 50); return;
            case 74: bd.armHi = Math.min(2100, bd.armHi + 50); return;
            case 80: propsOffAck = !propsOffAck; if (!propsOffAck) stopMotors(); return;
            case 81: dirPanel = !dirPanel; wizard = -1; return;
            case 82:
                if (wizard >= 0) {
                    wizard = -1;
                    stopMotors();
                } else if (motorsLive()) {
                    wizard = 0;
                    dirPanel = false;
                    stopMotors();
                } else v.toast("BATTERY + PROPS-OFF CONFIRMATION NEEDED", G.RED);
                return;
            case 83: stopMotors(); wizard = -1; return;
            case 95: dirPanel = false; return;
            case 170: version = 0; return;
            case 171: version = 1; return;
            case 172: fullErase = !fullErase; return;
            case 173: startFlash(); return;
        }
        if (n >= 90 && n < 94) {
            int out = bd.remap[n - 90];
            bd.dirRev[out] = !bd.dirRev[out];
            bd.motorTest = false;
            return;
        }
        if (n >= 110 && n < 115) { bd.vtxBand = n - 110; bd.vtxBandSet = true; return; }
        if (n >= 120 && n < 128) { bd.vtxChan = n - 119; return; }
        if (n >= 130 && n < 134) { bd.vtxPower = n - 129; return; }
        if (n >= 160 && n < 160 + Elec.TARGETS.length) { target = n - 160; return; }
        if (n >= 150 && n < 154 && wizard >= 0) {
            int pos = n - 150;
            // output 'wizard' physically spins at its real position; user says it is 'pos' -> logical motor pos uses this output
            newRemap[pos] = wizard;
            wizard++;
            if (wizard >= 4) {
                wizard = -1;
                System.arraycopy(newRemap, 0, bd.remap, 0, 4);
                stopMotors();
                v.toast(Elec.motorOrderOk(bd) ? "MOTOR ORDER SAVED" : "MOTOR ORDER SAVED (CHECK IT AGAIN)", Elec.motorOrderOk(bd) ? G.GREEN : G.YELLOW);
                bd.motorTest = false;
            }
        }
    }

}
