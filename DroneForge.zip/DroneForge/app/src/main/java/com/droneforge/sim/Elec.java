package com.droneforge.sim;

import java.util.ArrayList;
import java.util.Locale;

/** Electrical simulation of the build plus firmware logic and the final quality check. */
final class Elec {
    private Elec() {}

    static final int[] TEMPS = {320, 350, 380, 420};
    static final String[] BAND_NAME = {"A", "B", "E", "F", "R"};
    static final int[][] FREQ = {
            {5865, 5845, 5825, 5805, 5785, 5765, 5745, 5725},
            {5733, 5752, 5771, 5790, 5809, 5828, 5847, 5866},
            {5705, 5685, 5665, 5645, 5885, 5905, 5925, 5945},
            {5740, 5760, 5780, 5800, 5820, 5840, 5860, 5880},
            {5658, 5695, 5732, 5769, 5806, 5843, 5880, 5917}};
    static final String[] PROVIDERS = {"NONE", "SBUS", "CRSF", "IBUS"};
    static final String[] PROTOS = {"PWM", "DSHOT300", "DSHOT600"};
    static final String[] TARGETS = {"SKYRAYF405", "SKYRAYF405AIO", "SKYRAYF722", "SKYRAYF722HD", "HEXONF411", "HEXONF405", "VOLTIXF7"};

    static Parts.Part p(Game g, int uid) {
        return g.partOf(uid);
    }

    // ---------------------------------------------------------------- rails
    static float batteryV(Game g, Parts.Part bat) {
        return bat == null ? 0 : bat.cells * 4.2f;
    }

    /** Does battery power reach the ESC (pigtail soldered the right way round, no hard short)? */
    static boolean powerPath(Build b) {
        return b.pigtail >= 0 && b.pigJoint[0] >= 0.15f && b.pigJoint[1] >= 0.15f && b.pigPad[0] == 0 && b.pigPad[1] == 1 && !b.escDead;
    }

    /** Reason string if connecting a battery causes a short circuit, else null. */
    static String hardShort(Game g) {
        Build b = g.build;
        if (b.pigtail >= 0 && b.pigJoint[0] >= 0 && b.pigJoint[1] >= 0) {
            if (b.pigPad[0] == b.pigPad[1]) return "Both XT60 wires are soldered to the same pad - dead short!";
            if (b.pigPad[0] == 1 && b.pigPad[1] == 0) return "The XT60 pigtail is soldered with reversed polarity!";
            if (b.pigFlag[0] == 2 || b.pigFlag[1] == 2) return "A solder bridge on the battery pads shorts + to -!";
        }
        if (b.cap >= 0 && b.capJoint[0] >= 0 && b.capJoint[1] >= 0) {
            if (b.capPad[0] == 1 && b.capPad[1] == 0) return "The capacitor is installed backwards (stripe = minus)!";
        }
        // bridges between a power rail and ground on the FC
        if (b.fc >= 0 && b.harness) {
            for (int d = 0; d < 3; d++) {
                for (int w = 0; w < b.devFlag[d].length; w++) {
                    if (b.devFlag[d][w] != 2 || b.devPad[d][w] < 0) continue;
                    int pad = b.devPad[d][w];
                    int nb = neighbourPad(pad);
                    if (nb >= 0 && (isRail(pad) && isGnd(nb) || isRail(nb) && isGnd(pad)))
                        return "Solder bridge between " + Build.FC_PAD[pad] + " and " + Build.FC_PAD[nb] + " shorts a power rail!";
                }
                if (b.dev[d] >= 0 && b.devPad[d][0] >= 0 && b.devPad[d][1] >= 0 && b.devJoint[d][0] >= 0 && b.devJoint[d][1] >= 0) {
                    // V+ and GND wire of one device both on rails of different potential is a short through nothing; skip
                }
            }
        }
        return null;
    }

    static boolean isRail(int pad) {
        return pad == Build.P_5V || pad == Build.P_9V || pad == Build.P_VBAT;
    }

    static boolean isGnd(int pad) {
        return pad == Build.P_GND1 || pad == Build.P_GND2;
    }

    /** Physically adjacent pad on the same FC edge (for solder bridges). */
    static int neighbourPad(int pad) {
        int[][] edges = {{0, 1, 2, 3, 4, 5}, {6, 7, 8, 9, 10, 11}, {12, 13, 14, 15}, {16, 17, 18, 19}};
        for (int[] e : edges) {
            for (int i = 0; i < e.length; i++) {
                if (e[i] == pad) return i + 1 < e.length ? e[i + 1] : e[i - 1];
            }
        }
        return -1;
    }

    /** Voltage on an FC pad. usb: powered over USB only. */
    static float padV(Game g, int pad, boolean battery, boolean usb, Parts.Part bat) {
        Build b = g.build;
        if (b.fc < 0 || b.fcDead) return 0;
        boolean fcOnBattery = battery && powerPath(b) && b.harness;
        switch (pad) {
            case Build.P_5V: return (fcOnBattery || usb) ? 5f : 0f;
            case Build.P_9V: return fcOnBattery ? 9f : 0f;
            case Build.P_VBAT: return fcOnBattery ? batteryV(g, bat) : 0f;
            default: return 0f;
        }
    }

    /** Voltage reaching a device (V+ minus GND wire), considering joint quality. */
    static float devV(Game g, int d, boolean battery, boolean usb, Parts.Part bat) {
        Build b = g.build;
        if (b.dev[d] < 0) return 0;
        int vp = b.devPad[d][0], gp = b.devPad[d][1];
        if (vp < 0 || gp < 0 || b.devJoint[d][0] < 0 || b.devJoint[d][1] < 0) return 0;
        if (b.devFlag[d][0] == 3 || b.devFlag[d][1] == 3) return 0;
        float v = padV(g, vp, battery, usb, bat);
        float gv = padV(g, gp, battery, usb, bat);
        if (isGnd(vp) && isRail(gp)) return -padV(g, gp, battery, usb, bat);
        if (!isGnd(gp)) return 0;
        return v - gv;
    }

    static float maxV(Parts.Part dev) {
        if (dev == null) return 0;
        if (dev.cat == Parts.RX) return 5.5f;
        if (dev.cat == Parts.CAM) return dev.wideInput ? 40 : 5.5f;
        if (dev.cat == Parts.VTX) return dev.wideInput ? 36 : 5.5f;
        return 5.5f;
    }

    static float minV(Parts.Part dev) {
        if (dev != null && dev.cat == Parts.VTX && dev.wideInput) return 6.5f;
        return 4.5f;
    }

    static boolean devDead(Build b, int d) {
        return d == 0 ? b.rxDead : d == 1 ? b.camDead : b.vtxDead;
    }

    static void kill(Build b, int d) {
        if (d == 0) b.rxDead = true;
        else if (d == 1) b.camDead = true;
        else b.vtxDead = true;
    }

    /** Applies overvoltage / reverse polarity damage when power appears. Returns messages. */
    static ArrayList<String> applyPower(Game g, boolean battery, boolean usb, Parts.Part bat) {
        ArrayList<String> msgs = new ArrayList<>();
        Build b = g.build;
        for (int d = 0; d < 3; d++) {
            if (b.dev[d] < 0 || devDead(b, d)) continue;
            Parts.Part dp = p(g, b.dev[d]);
            float v = devV(g, d, battery, usb, bat);
            if (v < -0.5f) {
                kill(b, d);
                msgs.add(dp.name + " was powered with reversed polarity and died.");
            } else if (v > maxV(dp)) {
                kill(b, d);
                msgs.add(dp.name + " got " + (int) v + " V but only takes " + (dp.wideInput ? "up to " + (int) maxV(dp) : "5") + " V. It is fried!");
                Game.Item it = g.item(b.dev[d]);
                if (it != null) {
                    it.damaged = true;
                    it.note = "Burnt by overvoltage";
                }
            }
        }
        return msgs;
    }

    static boolean devWorks(Game g, int d, boolean battery, boolean usb, Parts.Part bat) {
        Build b = g.build;
        if (b.dev[d] < 0 || devDead(b, d)) return false;
        float v = devV(g, d, battery, usb, bat);
        Parts.Part dp = p(g, b.dev[d]);
        return v >= minV(dp) && v <= maxV(dp);
    }

    static float jointQ(Build b, int d, int w) {
        float q = b.devJoint[d][w];
        if (b.devFlag[d][w] == 2) return 0;
        return q;
    }

    // ---------------------------------------------------------------- receiver / FC link
    static boolean fcPowered(Game g, boolean battery, boolean usb) {
        Build b = g.build;
        if (b.fc < 0 || b.fcDead) return false;
        return usb || (battery && powerPath(b) && b.harness);
    }

    /** UART number the receiver is correctly wired to (TX->Rn, RX->Tn), 0 if miswired. */
    static int rxWiredUart(Build b) {
        if (b.dev[0] < 0) return 0;
        int tx = b.devPad[0][2], rx = b.devPad[0][3];
        if (tx < 0 || rx < 0 || b.devJoint[0][2] < 0 || b.devJoint[0][3] < 0) return 0;
        if (jointQ(b, 0, 2) < 0.2f || jointQ(b, 0, 3) < 0.2f) return 0;
        if (!Build.isRxPad(tx) || !Build.isTx(rx)) return 0;
        if (Build.uartOf(tx) != Build.uartOf(rx)) return 0;
        return Build.uartOf(tx);
    }

    static boolean rxNotCrossed(Build b) {
        int tx = b.devPad[0][2], rx = b.devPad[0][3];
        return tx >= 0 && rx >= 0 && Build.isTx(tx) && Build.isRxPad(rx);
    }

    static boolean fwOk(Game g) {
        Build b = g.build;
        Parts.Part fc = p(g, b.fc);
        return fc != null && b.flashed && !b.bricked && b.fwTarget.equals(fc.target);
    }

    /** Receiver delivers stick data to the flight controller. */
    static boolean rxLink(Game g, boolean battery, boolean usb, boolean radioOn) {
        Build b = g.build;
        if (!fcPowered(g, battery, usb) || b.bricked) return false;
        if (!devWorks(g, 0, battery, usb, null)) return false;
        int u = rxWiredUart(b);
        return u > 0 && b.serialRxUart == u && b.rxProvider == 2 && b.bound && radioOn;
    }

    // ---------------------------------------------------------------- motors
    /** Physical position driven by ESC output k given the ESC rotation. */
    static int outputPos(int k, int rot) {
        float x = Build.rx(Build.MX[k], Build.MY[k], rot), y = Build.ry(Build.MX[k], Build.MY[k], rot);
        for (int pp = 0; pp < 4; pp++) if (Math.abs(Build.MX[pp] - x) < 0.1f && Math.abs(Build.MY[pp] - y) < 0.1f) return pp;
        return k;
    }

    /** Physical position that spins when the configurator drives logical motor m. */
    static int spinsPos(Build b, int m) {
        return outputPos(b.remap[m], b.escRot);
    }

    static int outputAtPos(Build b, int pos) {
        for (int k = 0; k < 4; k++) if (outputPos(k, b.escRot) == pos) return k;
        return pos;
    }

    static boolean actualCW(Build b, int pos) {
        return b.motorParity[pos] ^ b.dirRev[outputAtPos(b, pos)];
    }

    static boolean expectedCW(Build b, int pos) {
        return Build.CW_DEFAULT[pos] ^ b.reversed;
    }

    static boolean motorOrderOk(Build b) {
        for (int m = 0; m < 4; m++) if (spinsPos(b, m) != m) return false;
        return true;
    }

    static boolean directionsOk(Build b) {
        for (int pos = 0; pos < 4; pos++) if (actualCW(b, pos) != expectedCW(b, pos)) return false;
        return true;
    }

    /** Problem with a motor at a position when it spins (null = fine). */
    static String motorProblem(Game g, int pos) {
        Build b = g.build;
        if (b.motor[pos] < 0) return "No motor";
        if (b.motorDead[pos]) return "Motor is burnt";
        Parts.Part fr = p(g, b.frame);
        for (int j = 0; j < 4; j++) {
            int hw = b.screw[pos][j];
            if (hw >= 0 && fr != null && Parts.HW_LEN[hw] - fr.arm > 4.5f) return "Grinding! A motor screw is too long and touches the windings";
        }
        int out = outputAtPos(b, pos);
        for (int w = 0; w < 3; w++) {
            if (b.mJoint[out][w] < 0) return "Not soldered";
            if (b.mFlag[out][w] == 2) return "Solder bridge between phases - motor desyncs";
            if (b.mFlag[out][w] == 3) return "Burnt pad - phase open";
            if (b.mJoint[out][w] < 0.3f) return "Cold joint - motor stutters";
        }
        for (int j = 0; j < 4; j++) if (b.torque[pos][j] < 0.6f) return "Loose motor - vibrates";
        return null;
    }

    // ---------------------------------------------------------------- video
    static final int V_NONE = 0, V_STATIC = 1, V_BLACK = 2, V_OK = 3;

    /** What the goggles show on a given band/channel. */
    static int video(Game g, boolean battery, Parts.Part bat, int gBand, int gChan) {
        Build b = g.build;
        if (!battery || !devWorks(g, 2, true, false, bat)) return V_STATIC;
        int vtxF = FREQ[b.vtxBand][b.vtxChan - 1];
        int gF = FREQ[gBand][gChan - 1];
        if (Math.abs(vtxF - gF) > 8) return V_STATIC;
        // VTX transmits. Camera image?
        boolean camOk = devWorks(g, 1, true, false, bat) && b.devPad[1][2] == Build.P_CAM && jointQ(b, 1, 2) >= 0.2f;
        boolean vtxVid = b.devPad[2][2] == Build.P_VTX && jointQ(b, 2, 2) >= 0.2f;
        if (!vtxVid) return V_BLACK;
        return camOk ? V_OK : V_BLACK;
    }

    static boolean vtxTransmitting(Game g, boolean battery, Parts.Part bat) {
        return battery && devWorks(g, 2, true, false, bat);
    }

    // ---------------------------------------------------------------- final inspection
    static final class Report {
        final ArrayList<String> lines = new ArrayList<>();
        final ArrayList<Boolean> ok = new ArrayList<>();
        float score, max;

        void add(boolean pass, float w, String s) {
            lines.add(s);
            ok.add(pass);
            max += w;
            if (pass) score += w;
        }

        float stars() {
            return max <= 0 ? 0 : Math.round(score / max * 50) / 10f;
        }
    }

    static Report inspect(Game g, Game.Order o, Game.Item battery, boolean propsIncluded) {
        Report r = new Report();
        Build b = g.build;
        Parts.Part fr = p(g, b.frame);
        Parts.Part mo = b.motor[0] >= 0 ? p(g, b.motor[0]) : null;
        Parts.Part esc = p(g, b.esc), fc = p(g, b.fc);
        int size = o == null ? 5 : o.size, cells = o == null ? 6 : o.cells;
        r.add(fr != null && fr.size == size, 2, "Frame: " + (fr == null ? "missing" : fr.size + "\" (" + size + "\" requested)"));
        boolean sameMotors = true;
        for (int i = 0; i < 4; i++) if (b.motor[i] < 0 || !p(g, b.motor[i]).id.equals(mo == null ? "" : mo.id)) sameMotors = false;
        r.add(sameMotors && mo != null && mo.size == size, 2, "Motors match the frame size" + (mo == null ? "" : " (" + mo.name + ")"));
        r.add(mo != null && mo.cellsMin == cells, 2, "Motor KV suits " + cells + "S" + (mo == null ? "" : " (" + mo.kv + " KV is a " + mo.cellsMin + "S motor)"));
        boolean screwsOk = true, tightOk = true;
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 4; j++) {
                int hw = b.screw[i][j];
                if (hw < 0 || fr == null) { screwsOk = false; continue; }
                float eng = Parts.HW_LEN[hw] - fr.arm;
                if (eng < 2 || eng > 4.5f || Parts.HW_M2[hw] != fr.m2) screwsOk = false;
                if (b.torque[i][j] < 0.6f || b.torque[i][j] > 1f) tightOk = false;
            }
        }
        r.add(screwsOk, 2, "Correct motor screw length");
        r.add(tightOk, 1, "Motor screws torqued properly");
        r.add(esc != null && fc != null && fr != null && esc.mount == fr.mount && fc.mount == fr.mount, 1, "Stack fits the frame");
        r.add(esc != null && esc.cellsMax >= cells && !b.escDead, 2, "ESC rated for " + cells + "S and healthy");
        float qs = 0;
        int qn = 0;
        boolean bad = false;
        for (int m = 0; m < 4; m++) for (int w = 0; w < 3; w++) {
            if (b.mJoint[m][w] >= 0) { qs += b.mJoint[m][w]; qn++; }
            if (b.mFlag[m][w] != 0) bad = true;
        }
        for (int d = 0; d < 3; d++) for (int w = 0; w < b.devJoint[d].length; w++) if (b.devJoint[d][w] >= 0) {
            qs += b.devJoint[d][w];
            qn++;
            if (b.devFlag[d][w] != 0) bad = true;
        }
        float avg = qn == 0 ? 0 : qs / qn;
        r.add(!bad && avg > 0.55f, 3, String.format(Locale.US, "Solder joints clean (avg quality %d%%)", Math.round(avg * 100)));
        r.add(b.pigtail >= 0 && b.pigPad[0] == 0 && b.pigPad[1] == 1 && b.pigJoint[0] > 0.4f && b.pigJoint[1] > 0.4f, 2, "Battery lead soldered, correct polarity");
        Parts.Part cap = p(g, b.cap);
        r.add(cap != null && b.capPad[0] == 0 && b.capPad[1] == 1 && b.capJoint[0] > 0.3f && cap.capV >= cells * 4.2f * 1.4f, 1,
                "Capacitor installed" + (cap == null ? " - MISSING (noisy video, ESC spikes)" : cap.capV < cells * 4.2f * 1.4f ? " but voltage rating too low" : ""));
        r.add(!b.rxDead && rxWiredUart(b) > 0, 2, "Receiver wired TX->RX / RX->TX");
        r.add(!b.camDead && b.devWired(1) && b.devPad[1][2] == Build.P_CAM, 1, "Camera wired to CAM pad");
        r.add(!b.vtxDead && b.devWired(2) && b.devPad[2][2] == Build.P_VTX, 1, "VTX wired to VTX pad");
        r.add(b.antenna >= 0, 2, "VTX antenna attached");
        r.add(b.topDone(), 1, "Top plate secured");
        r.add(fwOk(g), 2, "Latest firmware for " + (fc == null ? "?" : fc.target));
        r.add(b.accelCal && fc != null && b.boardYaw == b.fcRot, 1, "Board alignment + accelerometer calibrated");
        r.add(b.serialRxUart == rxWiredUart(b) && b.serialRxUart > 0 && b.rxProvider == 2, 2, "Receiver configured (UART + CRSF)");
        r.add(b.bound, 1, "Receiver bound");
        r.add(b.armAux > 0, 1, "ARM switch set up");
        r.add(motorOrderOk(b), 2, "Motor order correct");
        r.add(o == null || b.reversed == o.propsOut, 1, "Motor direction setting (props " + (o != null && o.propsOut ? "out" : "in") + ")");
        r.add(directionsOk(b), 2, "All motors spin the right way");
        r.add(o == null || (b.vtxBand == o.band && b.vtxChan == o.chan), 1, "VTX on " + (o == null ? "" : o.bandName()));
        boolean propsOk = b.propsDone();
        for (int pos = 0; pos < 4 && propsOk; pos++) if ((b.propType[pos] == 0) != actualCW(b, pos)) propsOk = false;
        r.add(propsOk, 2, "Props on the right motors and tight");
        r.add(battery != null && battery.p().cells == cells && !battery.damaged, 1, "Battery included (" + cells + "S)");
        r.add(b.smokeTest, 1, "Smoke-stopper test done");
        r.add(b.motorTest, 1, "Motor test done");
        r.add(b.videoTest, 1, "Video checked in goggles");
        r.add(b.rxTest, 1, "Receiver checked in configurator");
        return r;
    }
}
