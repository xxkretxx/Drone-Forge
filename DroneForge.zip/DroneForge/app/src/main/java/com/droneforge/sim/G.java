package com.droneforge.sim;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;

import java.util.ArrayList;

/** Industrial-style UI drawing helpers + simple hit-test registry. All coordinates are design units. */
final class G {
    // palette
    static final int BG = 0xFF0C0F13, PANEL = 0xEE141920, PANEL2 = 0xFF1B222B, LINE = 0xFF2C3541, LINE2 = 0xFF3C4756,
            TEXT = 0xFFE9EDF2, DIM = 0xFF8C98A8, DIM2 = 0xFF5B6676, ORANGE = 0xFFFF7A1A, ORANGE2 = 0xFFFFA45C, CYAN = 0xFF33D1FF,
            GREEN = 0xFF3DDC84, RED = 0xFFFF4D4D, YELLOW = 0xFFFFC93C, PURPLE = 0xFFA77BFF, WHITE = 0xFFFFFFFF;

    final Typeface bold, med, mono;
    final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint s = new Paint(Paint.ANTI_ALIAS_FLAG);
    final Paint tp = new Paint(Paint.ANTI_ALIAS_FLAG);
    final RectF r = new RectF();
    final RectF r2 = new RectF();
    final Path path = new Path();

    // hit registry
    static final class Hit {
        int id;
        float l, t, rr, b;
    }

    final ArrayList<Hit> hits = new ArrayList<>();
    private int hitCount;
    int pressedId = -1;
    float pressedT;

    G(Typeface bold, Typeface med, Typeface mono) {
        this.bold = bold;
        this.med = med;
        this.mono = mono;
        s.setStyle(Paint.Style.STROKE);
        s.setStrokeCap(Paint.Cap.ROUND);
        s.setStrokeJoin(Paint.Join.ROUND);
        tp.setTypeface(med);
    }

    void clearHits() {
        hitCount = 0;
    }

    void hit(int id, float l, float t, float rr, float b) {
        Hit h;
        if (hitCount < hits.size()) h = hits.get(hitCount);
        else {
            h = new Hit();
            hits.add(h);
        }
        h.id = id;
        h.l = l;
        h.t = t;
        h.rr = rr;
        h.b = b;
        hitCount++;
    }

    /** Last registered (top-most) hit wins. */
    int find(float x, float y) {
        for (int i = hitCount - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (x >= h.l && x <= h.rr && y >= h.t && y <= h.b) return h.id;
        }
        return 0;
    }

    boolean pressed(int id) {
        return pressedId == id && pressedT > 0;
    }

    // ---------------------------------------------------------------- text

    float text(Canvas c, String str, float x, float y, float size, int color, Typeface tf, Paint.Align al) {
        tp.setTypeface(tf);
        tp.setTextSize(size);
        tp.setTextAlign(al);
        tp.setColor(color);
        tp.setShader(null);
        c.drawText(str, x, y + size * 0.35f, tp);
        return tp.measureText(str);
    }

    float text(Canvas c, String str, float x, float y, float size, int color) {
        return text(c, str, x, y, size, color, med, Paint.Align.LEFT);
    }

    float textB(Canvas c, String str, float x, float y, float size, int color) {
        return text(c, str, x, y, size, color, bold, Paint.Align.LEFT);
    }

    void textC(Canvas c, String str, float x, float y, float size, int color, Typeface tf) {
        text(c, str, x, y, size, color, tf, Paint.Align.CENTER);
    }

    float width(String str, float size, Typeface tf) {
        tp.setTypeface(tf);
        tp.setTextSize(size);
        return tp.measureText(str);
    }

    /** Word-wraps a paragraph; returns the y after the last line. */
    float para(Canvas c, String str, float x, float y, float maxW, float size, int color, Typeface tf, float lineH) {
        for (String raw : str.split("\n")) {
            String line = "";
            for (String w : raw.split(" ")) {
                String t = line.isEmpty() ? w : line + " " + w;
                if (width(t, size, tf) > maxW && !line.isEmpty()) {
                    text(c, line, x, y, size, color, tf, Paint.Align.LEFT);
                    y += lineH;
                    line = w;
                } else line = t;
            }
            text(c, line, x, y, size, color, tf, Paint.Align.LEFT);
            y += lineH;
        }
        return y;
    }

    // ---------------------------------------------------------------- panels & buttons

    void panel(Canvas c, float l, float t, float rr, float b) {
        r.set(l, t, rr, b);
        p.setShader(null);
        p.setColor(PANEL);
        c.drawRoundRect(r, 10, 10, p);
        s.setStrokeWidth(1.5f);
        s.setColor(LINE);
        c.drawRoundRect(r, 10, 10, s);
        // industrial corner ticks
        s.setColor(ORANGE);
        s.setStrokeWidth(3);
        c.drawLine(l + 4, t + 16, l + 4, t + 4, s);
        c.drawLine(l + 4, t + 4, l + 16, t + 4, s);
        c.drawLine(rr - 4, b - 16, rr - 4, b - 4, s);
        c.drawLine(rr - 4, b - 4, rr - 16, b - 4, s);
    }

    void panelTitle(Canvas c, float l, float t, float rr, float b, String title) {
        panel(c, l, t, rr, b);
        p.setColor(ORANGE);
        c.drawRect(l + 18, t + 18, l + 22, t + 40, p);
        text(c, title.toUpperCase(), l + 32, t + 29, 24, TEXT, bold, Paint.Align.LEFT);
        s.setColor(LINE);
        s.setStrokeWidth(1.2f);
        c.drawLine(l + 14, t + 52, rr - 14, t + 52, s);
    }

    static final int B_PRIMARY = 0, B_DARK = 1, B_DANGER = 2, B_GOOD = 3, B_CYAN = 4, B_DISABLED = 5;

    void button(Canvas c, int id, float l, float t, float rr, float b, String label, int style) {
        r.set(l, t, rr, b);
        boolean pr = pressed(id);
        int fill, edge, txt;
        switch (style) {
            case B_PRIMARY: fill = ORANGE; edge = ORANGE2; txt = 0xFF1A0E04; break;
            case B_DANGER: fill = 0xFF7A1E1E; edge = RED; txt = TEXT; break;
            case B_GOOD: fill = 0xFF1C5E3A; edge = GREEN; txt = TEXT; break;
            case B_CYAN: fill = 0xFF0F4A5E; edge = CYAN; txt = TEXT; break;
            case B_DISABLED: fill = 0xFF1A1F26; edge = LINE; txt = DIM2; break;
            default: fill = PANEL2; edge = LINE2; txt = TEXT;
        }
        if (pr) r.offset(0, 2);
        p.setColor(0x66000000);
        r2.set(r.left, r.top + 4, r.right, r.bottom + 4);
        c.drawRoundRect(r2, 7, 7, p);
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, lighten(fill, pr ? 0f : 0.12f), fill, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, 7, 7, p);
        p.setShader(null);
        s.setStrokeWidth(1.6f);
        s.setColor(edge);
        c.drawRoundRect(r, 7, 7, s);
        float size = Math.min(26, (b - t) * 0.48f);
        text(c, label, (l + rr) / 2, (t + b) / 2 + (pr ? 2 : 0), size, txt, bold, Paint.Align.CENTER);
        if (style != B_DISABLED) hit(id, l, t, rr, b);
    }

    void iconButton(Canvas c, int id, float cx, float cy, float rad, int icon, int color) {
        boolean pr = pressed(id);
        p.setColor(pr ? 0xEE2A323D : 0xCC10141A);
        c.drawCircle(cx, cy, rad, p);
        s.setStrokeWidth(1.6f);
        s.setColor(LINE2);
        c.drawCircle(cx, cy, rad, s);
        icon(c, icon, cx, cy, rad * 0.55f, color);
        hit(id, cx - rad - 6, cy - rad - 6, cx + rad + 6, cy + rad + 6);
    }

    void bar(Canvas c, float l, float t, float rr, float b, float v, int color) {
        r.set(l, t, rr, b);
        p.setColor(0xFF0A0D11);
        c.drawRoundRect(r, (b - t) / 2, (b - t) / 2, p);
        if (v > 0) {
            r.set(l, t, l + (rr - l) * Math.min(1, v), b);
            p.setColor(color);
            c.drawRoundRect(r, (b - t) / 2, (b - t) / 2, p);
        }
        s.setStrokeWidth(1);
        s.setColor(LINE);
        r.set(l, t, rr, b);
        c.drawRoundRect(r, (b - t) / 2, (b - t) / 2, s);
    }

    void toggle(Canvas c, int id, float x, float y, boolean on) {
        r.set(x, y - 14, x + 52, y + 14);
        p.setColor(on ? 0xFF1C5E3A : 0xFF1A1F26);
        c.drawRoundRect(r, 14, 14, p);
        s.setColor(on ? GREEN : LINE2);
        s.setStrokeWidth(1.5f);
        c.drawRoundRect(r, 14, 14, s);
        p.setColor(on ? GREEN : DIM);
        c.drawCircle(on ? x + 38 : x + 14, y, 10, p);
        hit(id, x - 6, y - 20, x + 58, y + 20);
    }

    void badge(Canvas c, float x, float y, String str, int color) {
        float w = Math.max(26, width(str, 17, bold) + 14);
        r.set(x - w / 2, y - 13, x + w / 2, y + 13);
        p.setColor(color);
        c.drawRoundRect(r, 13, 13, p);
        text(c, str, x, y, 17, 0xFF0C0F13, bold, Paint.Align.CENTER);
    }

    void chip(Canvas c, float x, float y, String str, int color, boolean filled) {
        float w = width(str, 16, bold) + 18;
        r.set(x, y - 13, x + w, y + 13);
        p.setColor(filled ? color : 0x00000000);
        if (filled) c.drawRoundRect(r, 6, 6, p);
        s.setColor(color);
        s.setStrokeWidth(1.4f);
        c.drawRoundRect(r, 6, 6, s);
        text(c, str, x + w / 2, y, 16, filled ? 0xFF0C0F13 : color, bold, Paint.Align.CENTER);
    }

    static int lighten(int c, float k) {
        int a = c >>> 24, rr = (c >> 16) & 255, g = (c >> 8) & 255, b = c & 255;
        rr = Math.min(255, (int) (rr + (255 - rr) * k));
        g = Math.min(255, (int) (g + (255 - g) * k));
        b = Math.min(255, (int) (b + (255 - b) * k));
        return (a << 24) | (rr << 16) | (g << 8) | b;
    }

    static int alpha(int c, int a) {
        return (Math.max(0, Math.min(255, a)) << 24) | (c & 0xFFFFFF);
    }

    static int mix(int a, int b, float t) {
        t = Math.max(0, Math.min(1, t));
        int ra = (a >> 16) & 255, ga = (a >> 8) & 255, ba = a & 255, aa = a >>> 24;
        int rb = (b >> 16) & 255, gb = (b >> 8) & 255, bb = b & 255, ab = b >>> 24;
        return ((int) (aa + (ab - aa) * t) << 24) | ((int) (ra + (rb - ra) * t) << 16) | ((int) (ga + (gb - ga) * t) << 8) | (int) (ba + (bb - ba) * t);
    }

    // ---------------------------------------------------------------- icons
    static final int I_LEFT = 1, I_RIGHT = 2, I_UP = 3, I_DOWN = 4, I_CLOSE = 5, I_MAIL = 6, I_CART = 7, I_GEAR = 8, I_BOX = 9,
            I_CHECK = 10, I_WARN = 11, I_PLAY = 12, I_BOLT = 13, I_SOUND = 14, I_MUTE = 15, I_MINUS = 16, I_PLUS = 17, I_TRUCK = 18,
            I_CHIP = 19, I_BOOK = 20, I_LIST = 21, I_ROTATE = 22, I_FLIP = 23, I_EYE = 24, I_TRASH = 25, I_HAND = 26, I_USB = 27, I_MIN = 28;

    void icon(Canvas c, int k, float x, float y, float sz, int color) {
        s.setColor(color);
        p.setColor(color);
        p.setShader(null);
        s.setStrokeWidth(Math.max(2f, sz * 0.18f));
        path.reset();
        switch (k) {
            case I_LEFT: case I_RIGHT: case I_UP: case I_DOWN: {
                float d = sz * 0.55f;
                c.save();
                c.rotate(k == I_LEFT ? 180 : k == I_UP ? -90 : k == I_DOWN ? 90 : 0, x, y);
                path.moveTo(x - d * 0.5f, y - d);
                path.lineTo(x + d * 0.5f, y);
                path.lineTo(x - d * 0.5f, y + d);
                c.drawPath(path, s);
                c.restore();
                break;
            }
            case I_CLOSE:
                c.drawLine(x - sz * 0.5f, y - sz * 0.5f, x + sz * 0.5f, y + sz * 0.5f, s);
                c.drawLine(x + sz * 0.5f, y - sz * 0.5f, x - sz * 0.5f, y + sz * 0.5f, s);
                break;
            case I_MINUS: c.drawLine(x - sz * 0.5f, y, x + sz * 0.5f, y, s); break;
            case I_PLUS:
                c.drawLine(x - sz * 0.5f, y, x + sz * 0.5f, y, s);
                c.drawLine(x, y - sz * 0.5f, x, y + sz * 0.5f, s);
                break;
            case I_MIN: c.drawLine(x - sz * 0.5f, y + sz * 0.35f, x + sz * 0.5f, y + sz * 0.35f, s); break;
            case I_MAIL:
                r.set(x - sz * 0.75f, y - sz * 0.5f, x + sz * 0.75f, y + sz * 0.5f);
                c.drawRoundRect(r, sz * 0.1f, sz * 0.1f, s);
                path.moveTo(x - sz * 0.7f, y - sz * 0.42f);
                path.lineTo(x, y + sz * 0.1f);
                path.lineTo(x + sz * 0.7f, y - sz * 0.42f);
                c.drawPath(path, s);
                break;
            case I_CART:
                path.moveTo(x - sz * 0.85f, y - sz * 0.6f);
                path.lineTo(x - sz * 0.55f, y - sz * 0.6f);
                path.lineTo(x - sz * 0.35f, y + sz * 0.3f);
                path.lineTo(x + sz * 0.6f, y + sz * 0.3f);
                path.lineTo(x + sz * 0.8f, y - sz * 0.35f);
                path.lineTo(x - sz * 0.48f, y - sz * 0.35f);
                c.drawPath(path, s);
                c.drawCircle(x - sz * 0.25f, y + sz * 0.62f, sz * 0.12f, p);
                c.drawCircle(x + sz * 0.5f, y + sz * 0.62f, sz * 0.12f, p);
                break;
            case I_GEAR:
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4;
                    c.drawLine(x + (float) Math.cos(a) * sz * 0.5f, y + (float) Math.sin(a) * sz * 0.5f, x + (float) Math.cos(a) * sz * 0.85f, y + (float) Math.sin(a) * sz * 0.85f, s);
                }
                c.drawCircle(x, y, sz * 0.5f, s);
                break;
            case I_BOX:
                path.moveTo(x, y - sz * 0.8f);
                path.lineTo(x + sz * 0.8f, y - sz * 0.4f);
                path.lineTo(x + sz * 0.8f, y + sz * 0.45f);
                path.lineTo(x, y + sz * 0.85f);
                path.lineTo(x - sz * 0.8f, y + sz * 0.45f);
                path.lineTo(x - sz * 0.8f, y - sz * 0.4f);
                path.close();
                c.drawPath(path, s);
                c.drawLine(x - sz * 0.8f, y - sz * 0.4f, x, y, s);
                c.drawLine(x + sz * 0.8f, y - sz * 0.4f, x, y, s);
                c.drawLine(x, y, x, y + sz * 0.85f, s);
                break;
            case I_CHECK:
                path.moveTo(x - sz * 0.6f, y);
                path.lineTo(x - sz * 0.15f, y + sz * 0.45f);
                path.lineTo(x + sz * 0.65f, y - sz * 0.5f);
                c.drawPath(path, s);
                break;
            case I_WARN:
                path.moveTo(x, y - sz * 0.8f);
                path.lineTo(x + sz * 0.85f, y + sz * 0.65f);
                path.lineTo(x - sz * 0.85f, y + sz * 0.65f);
                path.close();
                c.drawPath(path, s);
                c.drawLine(x, y - sz * 0.25f, x, y + sz * 0.2f, s);
                c.drawCircle(x, y + sz * 0.45f, sz * 0.08f, p);
                break;
            case I_PLAY:
                path.moveTo(x - sz * 0.4f, y - sz * 0.6f);
                path.lineTo(x + sz * 0.6f, y);
                path.lineTo(x - sz * 0.4f, y + sz * 0.6f);
                path.close();
                c.drawPath(path, p);
                break;
            case I_BOLT:
                path.moveTo(x + sz * 0.15f, y - sz * 0.85f);
                path.lineTo(x - sz * 0.5f, y + sz * 0.1f);
                path.lineTo(x, y + sz * 0.1f);
                path.lineTo(x - sz * 0.15f, y + sz * 0.85f);
                path.lineTo(x + sz * 0.5f, y - sz * 0.1f);
                path.lineTo(x, y - sz * 0.1f);
                path.close();
                c.drawPath(path, p);
                break;
            case I_SOUND: case I_MUTE:
                path.moveTo(x - sz * 0.7f, y - sz * 0.25f);
                path.lineTo(x - sz * 0.35f, y - sz * 0.25f);
                path.lineTo(x + sz * 0.05f, y - sz * 0.6f);
                path.lineTo(x + sz * 0.05f, y + sz * 0.6f);
                path.lineTo(x - sz * 0.35f, y + sz * 0.25f);
                path.lineTo(x - sz * 0.7f, y + sz * 0.25f);
                path.close();
                c.drawPath(path, p);
                if (k == I_SOUND) {
                    r.set(x - sz * 0.3f, y - sz * 0.5f, x + sz * 0.6f, y + sz * 0.5f);
                    c.drawArc(r, -50, 100, false, s);
                } else {
                    c.drawLine(x + sz * 0.3f, y - sz * 0.3f, x + sz * 0.8f, y + sz * 0.3f, s);
                    c.drawLine(x + sz * 0.8f, y - sz * 0.3f, x + sz * 0.3f, y + sz * 0.3f, s);
                }
                break;
            case I_TRUCK:
                r.set(x - sz * 0.85f, y - sz * 0.45f, x + sz * 0.25f, y + sz * 0.35f);
                c.drawRect(r, s);
                path.moveTo(x + sz * 0.25f, y - sz * 0.15f);
                path.lineTo(x + sz * 0.65f, y - sz * 0.15f);
                path.lineTo(x + sz * 0.85f, y + sz * 0.1f);
                path.lineTo(x + sz * 0.85f, y + sz * 0.35f);
                path.lineTo(x + sz * 0.25f, y + sz * 0.35f);
                c.drawPath(path, s);
                c.drawCircle(x - sz * 0.5f, y + sz * 0.5f, sz * 0.15f, p);
                c.drawCircle(x + sz * 0.5f, y + sz * 0.5f, sz * 0.15f, p);
                break;
            case I_CHIP:
                r.set(x - sz * 0.5f, y - sz * 0.5f, x + sz * 0.5f, y + sz * 0.5f);
                c.drawRect(r, s);
                for (int i = -1; i <= 1; i++) {
                    c.drawLine(x + i * sz * 0.3f, y - sz * 0.5f, x + i * sz * 0.3f, y - sz * 0.8f, s);
                    c.drawLine(x + i * sz * 0.3f, y + sz * 0.5f, x + i * sz * 0.3f, y + sz * 0.8f, s);
                    c.drawLine(x - sz * 0.5f, y + i * sz * 0.3f, x - sz * 0.8f, y + i * sz * 0.3f, s);
                    c.drawLine(x + sz * 0.5f, y + i * sz * 0.3f, x + sz * 0.8f, y + i * sz * 0.3f, s);
                }
                break;
            case I_BOOK:
                r.set(x - sz * 0.7f, y - sz * 0.7f, x + sz * 0.7f, y + sz * 0.7f);
                c.drawRoundRect(r, sz * 0.1f, sz * 0.1f, s);
                c.drawLine(x - sz * 0.35f, y - sz * 0.25f, x + sz * 0.4f, y - sz * 0.25f, s);
                c.drawLine(x - sz * 0.35f, y + sz * 0.1f, x + sz * 0.4f, y + sz * 0.1f, s);
                break;
            case I_LIST:
                for (int i = -1; i <= 1; i++) {
                    c.drawCircle(x - sz * 0.6f, y + i * sz * 0.5f, sz * 0.09f, p);
                    c.drawLine(x - sz * 0.3f, y + i * sz * 0.5f, x + sz * 0.75f, y + i * sz * 0.5f, s);
                }
                break;
            case I_ROTATE:
                r.set(x - sz * 0.6f, y - sz * 0.6f, x + sz * 0.6f, y + sz * 0.6f);
                c.drawArc(r, -60, 280, false, s);
                path.moveTo(x + sz * 0.3f, y - sz * 0.85f);
                path.lineTo(x + sz * 0.55f, y - sz * 0.5f);
                path.lineTo(x + sz * 0.1f, y - sz * 0.4f);
                c.drawPath(path, s);
                break;
            case I_FLIP:
                c.drawLine(x, y - sz * 0.8f, x, y + sz * 0.8f, s);
                path.moveTo(x - sz * 0.2f, y - sz * 0.5f);
                path.lineTo(x - sz * 0.8f, y + sz * 0.5f);
                path.lineTo(x - sz * 0.2f, y + sz * 0.5f);
                path.close();
                c.drawPath(path, s);
                path.reset();
                path.moveTo(x + sz * 0.2f, y - sz * 0.5f);
                path.lineTo(x + sz * 0.8f, y + sz * 0.5f);
                path.lineTo(x + sz * 0.2f, y + sz * 0.5f);
                path.close();
                c.drawPath(path, p);
                break;
            case I_EYE:
                path.moveTo(x - sz * 0.85f, y);
                path.quadTo(x, y - sz * 0.75f, x + sz * 0.85f, y);
                path.quadTo(x, y + sz * 0.75f, x - sz * 0.85f, y);
                c.drawPath(path, s);
                c.drawCircle(x, y, sz * 0.25f, p);
                break;
            case I_TRASH:
                r.set(x - sz * 0.5f, y - sz * 0.45f, x + sz * 0.5f, y + sz * 0.8f);
                c.drawRect(r, s);
                c.drawLine(x - sz * 0.7f, y - sz * 0.55f, x + sz * 0.7f, y - sz * 0.55f, s);
                c.drawLine(x - sz * 0.2f, y - sz * 0.75f, x + sz * 0.2f, y - sz * 0.75f, s);
                break;
            case I_HAND:
                r.set(x - sz * 0.45f, y - sz * 0.2f, x + sz * 0.5f, y + sz * 0.8f);
                c.drawRoundRect(r, sz * 0.3f, sz * 0.3f, s);
                for (int i = 0; i < 4; i++) c.drawLine(x - sz * 0.32f + i * sz * 0.26f, y - sz * 0.15f, x - sz * 0.32f + i * sz * 0.26f, y - sz * 0.75f, s);
                break;
            case I_USB:
                c.drawLine(x, y + sz * 0.8f, x, y - sz * 0.6f, s);
                path.moveTo(x - sz * 0.25f, y - sz * 0.45f);
                path.lineTo(x, y - sz * 0.85f);
                path.lineTo(x + sz * 0.25f, y - sz * 0.45f);
                c.drawPath(path, s);
                c.drawLine(x, y + sz * 0.2f, x - sz * 0.5f, y - sz * 0.1f, s);
                c.drawLine(x, y + sz * 0.4f, x + sz * 0.5f, y + sz * 0.1f, s);
                c.drawCircle(x - sz * 0.5f, y - sz * 0.2f, sz * 0.12f, p);
                c.drawRect(x + sz * 0.38f, y - sz * 0.05f, x + sz * 0.62f, y + sz * 0.15f, p);
                break;
        }
    }
}
