package com.droneforge.sim;

import android.content.SharedPreferences;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.Random;

/** Persistent career state: money, clock, inventory, mail, orders, deliveries and the current build. */
final class Game {
    interface Listener {
        void toast(String s, int color);

        void sound(int id);
    }

    // ---------------------------------------------------------------- items
    static final int L_SHELF = 0, L_BENCH = 1, L_BUILD = 2, L_SHIPPED = 3, L_TRASH = 4;

    static final class Item {
        int uid;
        String part;
        int loc;
        boolean damaged;
        String note = "";

        Parts.Part p() {
            return Parts.get(part);
        }
    }

    static final class Delivery {
        int id;
        String from = "PartHub";
        final ArrayList<String> parts = new ArrayList<>();
        float arriveAt;
        int state; // 0 transit, 1 on pallet, 2 opened
        boolean express;

        int boxSize() {
            int n = parts.size();
            for (String s : parts) {
                Parts.Part p = Parts.get(s);
                if (p != null && p.cat == Parts.FRAME) n += 4;
            }
            return n <= 3 ? 0 : (n <= 9 ? 1 : 2);
        }
    }

    static final class Mail {
        int id;
        String from, addr, subject, body;
        float time;
        boolean read;
        int orderId = -1;
        int kind; // 0 info, 1 order offer, 2 shop, 3 payment
    }

    static final int O_OFFER = 0, O_ACCEPTED = 1, O_DECLINED = 2, O_SHIPPED = 3, O_PAID = 4, O_PACKED = 5;

    static final class Order {
        int id;
        String customer = "", company = "";
        int size = 5, cells = 6;
        int band = 4, chan = 1; // band index (A B E F R), channel 1..8
        boolean propsOut = true;
        int budget = 400;
        boolean kit;            // parts supplied by the customer (tutorial)
        boolean latestFw = true;
        int status;
        float shipAt, payAt;
        int paid;
        float stars;
        String report = "";

        String bandName() {
            return Elec.BAND_NAME[band] + chan;
        }

        String title() {
            String t = size == 3 ? "3\" toothpick" : size == 7 ? "7\" long range" : "5\" freestyle";
            return t + " " + cells + "S";
        }
    }

    // ---------------------------------------------------------------- state
    float money = 650;
    float time = 8 * 60;          // game minutes (1 real second = 1 game minute)
    float rep = 3.0f;
    int jobsDone;
    int nextUid = 1, nextId = 1;
    final ArrayList<Item> items = new ArrayList<>();
    final ArrayList<Delivery> deliveries = new ArrayList<>();
    final ArrayList<Mail> mails = new ArrayList<>();
    final ArrayList<Order> orders = new ArrayList<>();
    final ArrayList<String> tools = new ArrayList<>();
    Build build = new Build();
    int ironTemp = 1;             // index into Elec.TEMPS
    boolean smokeOn = true;       // smoke stopper in-line
    int hand = -1;                // hardware in hand (Parts.HW_*)
    int storyStep;                // scripted campaign progress
    float nextOfferAt = -1;
    int packedOrder = -1;         // order whose box sits on the outgoing pallet
    float courierAt = -1;
    boolean courierHere;
    final ArrayList<String> cart = new ArrayList<>();

    transient Listener ls;
    private final Random rnd = new Random();

    // ---------------------------------------------------------------- helpers
    Item item(int uid) {
        for (Item i : items) if (i.uid == uid) return i;
        return null;
    }

    Parts.Part partOf(int uid) {
        Item i = item(uid);
        return i == null ? null : i.p();
    }

    Item addItem(String part, int loc) {
        Item i = new Item();
        i.uid = nextUid++;
        i.part = part;
        i.loc = loc;
        items.add(i);
        return i;
    }

    int count(int cat, int loc) {
        int n = 0;
        for (Item i : items) if (i.loc == loc && i.p() != null && i.p().cat == cat) n++;
        return n;
    }

    ArrayList<Item> itemsAt(int loc, int cat) {
        ArrayList<Item> l = new ArrayList<>();
        for (Item i : items) if (i.loc == loc && (cat < 0 || (i.p() != null && i.p().cat == cat))) l.add(i);
        return l;
    }

    boolean hasTool(String id) {
        return tools.contains(id);
    }

    int unread() {
        int n = 0;
        for (Mail m : mails) if (!m.read) n++;
        return n;
    }

    int palletCount() {
        int n = 0;
        for (Delivery d : deliveries) if (d.state == 1) n++;
        return n;
    }

    Order order(int id) {
        for (Order o : orders) if (o.id == id) return o;
        return null;
    }

    Order activeOrder() {
        for (Order o : orders) if (o.status == O_ACCEPTED) return o;
        return null;
    }

    int day() {
        return (int) (time / 1440) + 1;
    }

    String clock() {
        int m = (int) time % 1440;
        return String.format(Locale.US, "%02d:%02d", m / 60, m % 60);
    }

    static String money(float v) {
        return String.format(Locale.US, "$%,.2f", v);
    }

    Mail mail(String from, String addr, String subject, String body, int kind, int orderId) {
        Mail m = new Mail();
        m.id = nextId++;
        m.from = from;
        m.addr = addr;
        m.subject = subject;
        m.body = body;
        m.time = time;
        m.kind = kind;
        m.orderId = orderId;
        mails.add(0, m);
        if (ls != null) {
            ls.sound(Sfx.MAIL);
            ls.toast("NEW EMAIL: " + subject.toUpperCase(Locale.US), G.CYAN);
        }
        return m;
    }

    Delivery ship(ArrayList<String> parts, float minutes, String from, boolean express) {
        Delivery d = new Delivery();
        d.id = nextId++;
        d.parts.addAll(parts);
        d.arriveAt = time + minutes;
        d.from = from;
        d.express = express;
        deliveries.add(d);
        return d;
    }

    // ---------------------------------------------------------------- story & orders
    void startNew() {
        tools.add("tl_smoke");
        storyStep = 0;
        mail("Max Keller", "max@droneforge.shop", "Welcome to the Forge!",
                "Hey partner!\n\nThe workshop is yours now. I sent you a complete 5-inch kit so you can do your first build - "
                        + "it should arrive at the roller door behind you in a few minutes.\n\n"
                        + "HOW THE SHOP WORKS\n"
                        + "- Behind you: deliveries arrive on the pallet. Open the boxes and store the parts.\n"
                        + "- Left: the parts shelves. Take what you need to the bench.\n"
                        + "- Front: the build bench. Look down for screws and hardware.\n"
                        + "- Right: this PC (mail, PartHub shop, FC Configurator), goggles and radio.\n\n"
                        + "Open the BUILD GUIDE app on the desktop - it walks you through every step the way pros do it.\n\nGood luck!\nMax",
                0, -1);
        Order o = new Order();
        o.id = nextId++;
        o.customer = "Max Keller";
        o.company = "Drone Forge";
        o.size = 5;
        o.cells = 6;
        o.band = 4;
        o.chan = 1;
        o.propsOut = true;
        o.budget = 180;
        o.kit = true;
        o.status = O_ACCEPTED;
        orders.add(o);
        build.orderId = o.id;
        mail("Max Keller", "max@droneforge.shop", "Job #1: build my 5\" kit",
                "Your first job is my own quad. Requirements:\n\n"
                        + "- 5\" freestyle, 6S\n- Latest firmware (flash it in FC Configurator)\n- ELRS receiver bound to the radio on your desk\n"
                        + "- VTX on band/channel R1 (check it in the goggles)\n- Props OUT (set 'motor direction is reversed')\n"
                        + "- Always do a smoke-stopper test before the first full power-up!\n\n"
                        + "Pack it on the table at the roller door when it's done. I'll pay $180 for the work.\n- Max",
                1, o.id);
        ArrayList<String> kit = new ArrayList<>();
        kit.add("fr_krait5");
        for (int i = 0; i < 4; i++) kit.add("mo_2207_1950");
        kit.add("esc_v45");
        kit.add("fc_f405");
        kit.add("vtx_spectra");
        kit.add("cam_owl");
        kit.add("rx_link");
        kit.add("ant_mmcx");
        kit.add("pr_5");
        kit.add("ba_6s1100");
        kit.add("pt_xt60");
        kit.add("cap_50");
        ship(kit, 6, "Max Keller", false);
    }

    private static final String[][] CUSTOMERS = {{"Jake Morrison", ""}, {"Lena Ortiz", "Ortiz Films"}, {"Kevin Tran", ""},
            {"Sam Reyes", "Tidal Racing"}, {"Mia Novak", ""}, {"Oliver Price", "Price Real Estate"}, {"Noah Fischer", ""},
            {"Emma Lindqvist", "Nordic Aerial"}, {"Lucas Moreau", ""}, {"Ava Kowalski", "SkyLens Media"}, {"Ethan Brooks", ""},
            {"Zoe Martin", "Peak Riders"}};

    void offerNext() {
        Order o = new Order();
        o.id = nextId++;
        int k = jobsDone;
        String[] cu = CUSTOMERS[(k + rnd.nextInt(3)) % CUSTOMERS.length];
        o.customer = cu[0];
        o.company = cu[1];
        int t = k <= 4 ? k : rnd.nextInt(4);
        switch (t) {
            case 1: o.size = 5; o.cells = 6; o.band = 4; o.chan = 4; o.propsOut = true; o.budget = 430; break;
            case 2: o.size = 7; o.cells = 6; o.band = 3; o.chan = 1; o.propsOut = true; o.budget = 640; break;
            case 3: o.size = 3; o.cells = 4; o.band = 4; o.chan = 7; o.propsOut = false; o.budget = 320; break;
            default: o.size = 5; o.cells = 4; o.band = 4; o.chan = 2; o.propsOut = false; o.budget = 390; break;
        }
        if (k > 4) {
            o.band = rnd.nextInt(5);
            o.chan = 1 + rnd.nextInt(8);
            o.propsOut = rnd.nextBoolean();
            o.budget = (int) (o.budget * (1 + 0.04f * Math.min(10, k - 4)) * (0.9f + rnd.nextFloat() * 0.25f) / 10) * 10;
        }
        o.status = O_OFFER;
        orders.add(o);
        String use = o.size == 7 ? "long-range cinematic flights" : o.size == 3 ? "tight indoor and park flying" : o.cells == 4 ? "racing" : "freestyle";
        mail(o.customer, o.customer.toLowerCase(Locale.US).replace(' ', '.') + "@mail.com", "Build request: " + o.title(),
                "Hi Drone Forge,\n\nI'd like a custom quad for " + use + ". Here is what I need:\n\n"
                        + "- " + o.size + "\" frame, " + o.cells + "S battery setup\n"
                        + "- Analog video, VTX set to " + o.bandName() + "\n"
                        + "- ExpressLRS receiver\n"
                        + "- Props " + (o.propsOut ? "OUT (reversed motor direction)" : "IN (default direction)") + "\n"
                        + "- Latest firmware, fully tested\n"
                        + "- Include one " + o.cells + "S battery and a set of props\n\n"
                        + "My budget is " + money(o.budget) + " including all parts. Can you do it?\n\n" + o.customer
                        + (o.company.isEmpty() ? "" : "\n" + o.company),
                1, o.id);
    }

    void accept(Order o) {
        o.status = O_ACCEPTED;
        if (build.orderId < 0 || order(build.orderId) == null || order(build.orderId).status != O_ACCEPTED) build.orderId = o.id;
        if (ls != null) ls.toast("ORDER ACCEPTED - BUY THE PARTS IN PARTHUB", G.GREEN);
    }

    void decline(Order o) {
        o.status = O_DECLINED;
        nextOfferAt = time + 20;
    }

    // ---------------------------------------------------------------- simulation tick (dt in real seconds)
    void tick(float dt) {
        time += dt;
        for (Delivery d : deliveries) {
            if (d.state == 0 && time >= d.arriveAt) {
                d.state = 1;
                if (ls != null) {
                    ls.sound(Sfx.TRUCK);
                    ls.toast("DELIVERY ARRIVED AT THE ROLLER DOOR", G.ORANGE);
                }
            }
        }
        if (nextOfferAt >= 0 && time >= nextOfferAt) {
            nextOfferAt = -1;
            offerNext();
        }
        if (courierAt >= 0 && time >= courierAt) {
            courierAt = -1;
            Order o = order(packedOrder);
            packedOrder = -1;
            if (o != null) {
                o.status = O_SHIPPED;
                o.payAt = time + 45;
                if (ls != null) {
                    ls.sound(Sfx.TRUCK);
                    ls.toast("COURIER PICKED UP THE PARCEL", G.CYAN);
                }
            }
        }
        for (Order o : orders) {
            if (o.status == O_SHIPPED && time >= o.payAt) {
                o.status = O_PAID;
                money += o.paid;
                rep = (rep * (jobsDone + 2) + o.stars) / (jobsDone + 3);
                jobsDone++;
                if (ls != null) ls.sound(Sfx.CASH);
                mail(o.customer, "", (o.stars >= 4 ? "Love it! " : o.stars >= 2.5f ? "Received the quad" : "Problems with my quad") + " (" + money(o.paid) + " paid)",
                        o.report + "\n\nPayment of " + money(o.paid) + " has been sent to your account.\n\nRating: "
                                + String.format(Locale.US, "%.1f", o.stars) + " / 5\n\n" + o.customer, 3, o.id);
                nextOfferAt = time + 8 + rnd.nextInt(10);
            }
        }
    }

    // ---------------------------------------------------------------- save / load
    String serialize() {
        try {
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            DataOutputStream o = new DataOutputStream(bo);
            o.writeInt(3);
            o.writeFloat(money);
            o.writeFloat(time);
            o.writeFloat(rep);
            o.writeInt(jobsDone);
            o.writeInt(nextUid);
            o.writeInt(nextId);
            o.writeInt(ironTemp);
            o.writeBoolean(smokeOn);
            o.writeInt(hand);
            o.writeInt(storyStep);
            o.writeFloat(nextOfferAt);
            o.writeInt(packedOrder);
            o.writeFloat(courierAt);
            o.writeInt(items.size());
            for (Item i : items) {
                o.writeInt(i.uid);
                o.writeUTF(i.part);
                o.writeInt(i.loc);
                o.writeBoolean(i.damaged);
                o.writeUTF(i.note);
            }
            o.writeInt(deliveries.size());
            for (Delivery d : deliveries) {
                o.writeInt(d.id);
                o.writeUTF(d.from);
                o.writeFloat(d.arriveAt);
                o.writeInt(d.state);
                o.writeBoolean(d.express);
                o.writeInt(d.parts.size());
                for (String s : d.parts) o.writeUTF(s);
            }
            o.writeInt(mails.size());
            for (Mail m : mails) {
                o.writeInt(m.id);
                o.writeUTF(m.from);
                o.writeUTF(m.addr);
                o.writeUTF(m.subject);
                o.writeUTF(m.body);
                o.writeFloat(m.time);
                o.writeBoolean(m.read);
                o.writeInt(m.orderId);
                o.writeInt(m.kind);
            }
            o.writeInt(orders.size());
            for (Order r : orders) {
                o.writeInt(r.id);
                o.writeUTF(r.customer);
                o.writeUTF(r.company);
                o.writeInt(r.size);
                o.writeInt(r.cells);
                o.writeInt(r.band);
                o.writeInt(r.chan);
                o.writeBoolean(r.propsOut);
                o.writeInt(r.budget);
                o.writeBoolean(r.kit);
                o.writeBoolean(r.latestFw);
                o.writeInt(r.status);
                o.writeFloat(r.shipAt);
                o.writeFloat(r.payAt);
                o.writeInt(r.paid);
                o.writeFloat(r.stars);
                o.writeUTF(r.report);
            }
            o.writeInt(tools.size());
            for (String s : tools) o.writeUTF(s);
            o.writeInt(cart.size());
            for (String s : cart) o.writeUTF(s);
            build.write(o);
            o.flush();
            byte[] b = bo.toByteArray();
            StringBuilder sb = new StringBuilder(b.length * 2);
            for (byte x : b) {
                sb.append(Character.forDigit((x >> 4) & 15, 16));
                sb.append(Character.forDigit(x & 15, 16));
            }
            return sb.toString();
        } catch (IOException e) {
            return null;
        }
    }

    boolean deserialize(String s) {
        if (s == null || s.length() < 8) return false;
        try {
            byte[] b = new byte[s.length() / 2];
            for (int i = 0; i < b.length; i++) b[i] = (byte) Integer.parseInt(s.substring(i * 2, i * 2 + 2), 16);
            DataInputStream in = new DataInputStream(new ByteArrayInputStream(b));
            if (in.readInt() != 3) return false;
            money = in.readFloat();
            time = in.readFloat();
            rep = in.readFloat();
            jobsDone = in.readInt();
            nextUid = in.readInt();
            nextId = in.readInt();
            ironTemp = in.readInt();
            smokeOn = in.readBoolean();
            hand = in.readInt();
            storyStep = in.readInt();
            nextOfferAt = in.readFloat();
            packedOrder = in.readInt();
            courierAt = in.readFloat();
            int n = in.readInt();
            for (int k = 0; k < n; k++) {
                Item i = new Item();
                i.uid = in.readInt();
                i.part = in.readUTF();
                i.loc = in.readInt();
                i.damaged = in.readBoolean();
                i.note = in.readUTF();
                items.add(i);
            }
            n = in.readInt();
            for (int k = 0; k < n; k++) {
                Delivery d = new Delivery();
                d.id = in.readInt();
                d.from = in.readUTF();
                d.arriveAt = in.readFloat();
                d.state = in.readInt();
                d.express = in.readBoolean();
                int m = in.readInt();
                for (int j = 0; j < m; j++) d.parts.add(in.readUTF());
                deliveries.add(d);
            }
            n = in.readInt();
            for (int k = 0; k < n; k++) {
                Mail m = new Mail();
                m.id = in.readInt();
                m.from = in.readUTF();
                m.addr = in.readUTF();
                m.subject = in.readUTF();
                m.body = in.readUTF();
                m.time = in.readFloat();
                m.read = in.readBoolean();
                m.orderId = in.readInt();
                m.kind = in.readInt();
                mails.add(m);
            }
            n = in.readInt();
            for (int k = 0; k < n; k++) {
                Order r = new Order();
                r.id = in.readInt();
                r.customer = in.readUTF();
                r.company = in.readUTF();
                r.size = in.readInt();
                r.cells = in.readInt();
                r.band = in.readInt();
                r.chan = in.readInt();
                r.propsOut = in.readBoolean();
                r.budget = in.readInt();
                r.kit = in.readBoolean();
                r.latestFw = in.readBoolean();
                r.status = in.readInt();
                r.shipAt = in.readFloat();
                r.payAt = in.readFloat();
                r.paid = in.readInt();
                r.stars = in.readFloat();
                r.report = in.readUTF();
                orders.add(r);
            }
            n = in.readInt();
            for (int k = 0; k < n; k++) tools.add(in.readUTF());
            n = in.readInt();
            for (int k = 0; k < n; k++) cart.add(in.readUTF());
            build.read(in);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    void save(SharedPreferences sp) {
        String s = serialize();
        if (s != null) sp.edit().putString("save", s).apply();
    }

    static Game load(SharedPreferences sp) {
        Game g = new Game();
        String s = sp.getString("save", null);
        if (s != null && g.deserialize(s)) return g;
        g = new Game();
        g.startNew();
        return g;
    }
}
