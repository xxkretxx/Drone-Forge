package com.droneforge.sim;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Typeface;

import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Locale;

/** Root view: owns the game loop, the shared resources and switches between screens. */
public class GameView extends View implements Game.Listener {
    // HUD / dialog ids
    static final int H_SOUND = 9001, H_ORDER = 9002, H_HAND = 9003, H_MAIL = 9004, D_BTN = 9500;

    final G g;
    final Res res;
    final Sfx sfx;
    final SharedPreferences prefs;
    private final Vibrator vib;
    Game game;

    // screens
    final RoomScreen room;
    final BuildScreen buildScreen;
    final PcScreen pc;
    final GogglesScreen goggles;
    final RadioScreen radio;
    final PackScreen pack;
    final UnboxScreen unbox;
    final TitleScreen title;
    Screen screen;

    // bench power state (session only)
    int benchBattery = -1;      // battery item placed on the bench for tests
    boolean batteryOn, usbOn, radioOn = true, dfu;
    float powerOnT;             // seconds since power was applied
    int powerCycles;            // quick battery plug cycles (ELRS bind mode)
    float lastPlugT = -10, bindModeT;
    float smokeRedT;            // smoke stopper tripped indicator
    int motorStream;

    // transform
    int W, H;
    float k = 1, ox, oy, L, R, T, Bm;
    float time, dtLast;
    private long lastNs;
    private boolean running = true;

    // input
    private int downId;
    private float downX, downY;
    boolean moved, consumed;

    // toasts
    private final ArrayList<String> toasts = new ArrayList<>();
    private final ArrayList<Integer> toastCol = new ArrayList<>();
    private float toastT;

    // modal dialog
    String dlgTitle, dlgBody;
    String[] dlgButtons;
    int[] dlgStyles;
    DialogCb dlgCb;
    float dlgT;

    interface DialogCb {
        void on(int index);
    }

    public GameView(Context ctx) {
        super(ctx);
        Typeface bold, med, mono;
        try {
            bold = Typeface.createFromAsset(ctx.getAssets(), "fonts/BarlowCond-Bold.ttf");
            med = Typeface.createFromAsset(ctx.getAssets(), "fonts/BarlowCond-Medium.ttf");
            mono = Typeface.createFromAsset(ctx.getAssets(), "fonts/JetBrainsMono.ttf");
        } catch (Exception e) {
            bold = Typeface.create("sans-serif-condensed", Typeface.BOLD);
            med = Typeface.create("sans-serif-condensed", Typeface.NORMAL);
            mono = Typeface.MONOSPACE;
        }
        g = new G(bold, med, mono);
        res = new Res(ctx.getAssets());
        sfx = new Sfx(ctx);
        prefs = ctx.getSharedPreferences("droneforge", Context.MODE_PRIVATE);
        sfx.muted = prefs.getBoolean("muted", false);
        vib = (Vibrator) ctx.getSystemService(Context.VIBRATOR_SERVICE);
        game = Game.load(prefs);
        game.ls = this;
        room = new RoomScreen(this);
        buildScreen = new BuildScreen(this);
        pc = new PcScreen(this);
        goggles = new GogglesScreen(this);
        radio = new RadioScreen(this);
        pack = new PackScreen(this);
        unbox = new UnboxScreen(this);
        title = new TitleScreen(this);
        screen = title;
        setFocusable(true);
    }

    void newGame() {
        game = new Game();
        game.ls = this;
        game.startNew();
        benchBattery = -1;
        batteryOn = usbOn = false;
        save();
    }

    void save() {
        game.save(prefs);
    }

    void go(Screen s) {
        screen = s;
        s.enter();
    }

    // ---------------------------------------------------------------- lifecycle
    void onPauseGame() {
        running = false;
        save();
        sfx.stop(motorStream);
        motorStream = 0;
    }

    void onResumeGame() {
        running = true;
        lastNs = 0;
        postInvalidateOnAnimation();
    }

    void release() {
        sfx.release();
    }

    boolean onBack() {
        if (dlgTitle != null) {
            closeDialog(-1);
            return true;
        }
        return screen.back();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        W = w;
        H = h;
        k = Math.min(W / 1600f, H / 720f);
        ox = (W - 1600 * k) / 2f;
        oy = (H - 720 * k) / 2f;
        L = -ox / k;
        R = 1600 + ox / k;
        T = -oy / k;
        Bm = 720 + oy / k;
    }

    // ---------------------------------------------------------------- Game.Listener
    @Override
    public void toast(String s, int color) {
        toasts.add(s);
        toastCol.add(color);
        if (toasts.size() == 1) toastT = 0;
    }

    @Override
    public void sound(int id) {
        sfx.play(id, 0.8f);
    }

    void vibrate(int ms) {
        if (vib == null) return;
        try {
            if (android.os.Build.VERSION.SDK_INT >= 26) vib.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE));
            else vib.vibrate(ms);
        } catch (Exception ignored) {
        }
    }

    void dialog(String title, String body, String[] buttons, int[] styles, DialogCb cb) {
        dlgTitle = title;
        dlgBody = body;
        dlgButtons = buttons;
        dlgStyles = styles;
        dlgCb = cb;
        dlgT = 0;
    }

    void info(String title, String body) {
        dialog(title, body, new String[]{"OK"}, new int[]{G.B_PRIMARY}, null);
    }

    private void closeDialog(int i) {
        DialogCb cb = dlgCb;
        dlgTitle = null;
        dlgCb = null;
        if (cb != null) cb.on(i);
    }

    // ---------------------------------------------------------------- loop
    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 1 / 60f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        time += dt;
        dtLast = dt;
        if (W > 0) {
            update(dt);
            render(c);
        }
        if (running) postInvalidateOnAnimation();
    }

    private float saveT;

    void update(float dt) {
        if (g.pressedT > 0) g.pressedT -= dt;
        if (screen != title) {
            game.tick(dt);
            updatePower(dt);
            saveT += dt;
            if (saveT > 20) {
                saveT = 0;
                save();
            }
        }
        if (toasts.size() > 0) {
            toastT += dt;
            if (toastT > 2.8f) {
                toasts.remove(0);
                toastCol.remove(0);
                toastT = 0;
            }
        }
        if (dlgTitle != null) dlgT += dt;
        if (screen != title) {
            pc.config.update(dt);
            if (screen != radio) radio.update(dt);
        }
        screen.update(dt);
    }

    Parts.Part benchBatteryPart() {
        return benchBattery >= 0 ? game.partOf(benchBattery) : null;
    }

    /** Plug / unplug the bench battery into the drone (through the smoke stopper if enabled). */
    void setBattery(boolean on) {
        if (on == batteryOn) return;
        Build b = game.build;
        if (on) {
            if (benchBattery < 0 || !b.hasFrame()) return;
            if (game.time - lastPlugT < 4f) powerCycles++;
            else powerCycles = 1;
            lastPlugT = game.time;
            sfx.play(Sfx.SNAP, 0.9f);
            String sh = Elec.hardShort(game);
            if (sh != null) {
                if (game.smokeOn && game.hasTool("tl_smoke")) {
                    smokeRedT = 3f;
                    sfx.play(Sfx.ERROR, 0.9f);
                    info("SMOKE STOPPER TRIPPED", sh + "\n\nThe smoke stopper limited the current and saved your parts. Fix the problem before powering up again.");
                    b.smokeTest = false;
                } else {
                    sfx.play(Sfx.SPARK, 1f);
                    vibrate(300);
                    b.escDead = true;
                    Game.Item it = game.item(b.esc);
                    if (it != null) {
                        it.damaged = true;
                        it.note = "Burnt: short circuit on power-up";
                    }
                    info("MAGIC SMOKE!", sh + "\n\nWithout a smoke stopper the full battery current went straight through. The ESC is burnt and has to be replaced.");
                }
                return;
            }
            batteryOn = true;
            powerOnT = 0;
            if (game.smokeOn && game.hasTool("tl_smoke")) b.smokeTest = true;
            for (String m : Elec.applyPower(game, true, usbOn, benchBatteryPart())) {
                sfx.play(Sfx.SPARK, 0.8f);
                info("COMPONENT DAMAGED", m);
            }
            if (Elec.powerPath(b) && b.esc >= 0) sfx.play(Sfx.ESC, 0.8f);
            if (powerCycles >= 3 && b.dev[0] >= 0 && !b.bound) {
                bindModeT = 60;
                toast("RECEIVER IN BIND MODE - PRESS BIND ON THE RADIO", G.CYAN);
            }
        } else {
            batteryOn = false;
            sfx.play(Sfx.SNAP, 0.6f);
            sfx.stop(motorStream);
            motorStream = 0;
        }
    }

    void setUsb(boolean on) {
        if (on == usbOn) return;
        usbOn = on;
        sfx.play(on ? Sfx.USB_IN : Sfx.USB_OUT, 0.8f);
        if (on) for (String m : Elec.applyPower(game, batteryOn, true, benchBatteryPart())) info("COMPONENT DAMAGED", m);
    }

    private void updatePower(float dt) {
        Build b = game.build;
        if (smokeRedT > 0) smokeRedT -= dt;
        if (bindModeT > 0) bindModeT -= dt;
        if (batteryOn) {
            powerOnT += dt;
            if (b.dev[2] >= 0 && b.antenna < 0 && Elec.devWorks(game, 2, true, usbOn, benchBatteryPart()) && !b.vtxDead) {
                b.vtxHotT += dt;
                if (b.vtxHotT > 12 && b.vtxHotT - dt <= 12) toast("WARNING: VTX IS GETTING HOT - NO ANTENNA!", G.RED);
                if (b.vtxHotT > 22) {
                    b.vtxDead = true;
                    Game.Item it = game.item(b.dev[2]);
                    if (it != null) {
                        it.damaged = true;
                        it.note = "Overheated: powered without an antenna";
                    }
                    sfx.play(Sfx.SPARK, 0.7f);
                    info("VTX BURNT OUT", "You powered the video transmitter without an antenna. The RF energy had nowhere to go and the VTX overheated.\n\nAlways screw the antenna on before plugging in a battery!");
                }
            }
        } else if (b.vtxHotT > 0) b.vtxHotT = Math.max(0, b.vtxHotT - dt * 0.5f);
    }

    // ---------------------------------------------------------------- render
    void render(Canvas c) {
        g.clearHits();
        c.drawColor(0xFF000000);
        c.save();
        c.translate(ox, oy);
        c.scale(k, k);
        screen.draw(c);
        if (screen != title) drawToasts(c);
        if (dlgTitle != null) drawDialog(c);
        c.restore();
    }

    private void drawToasts(Canvas c) {
        if (toasts.isEmpty()) return;
        String s = toasts.get(0);
        int col = toastCol.get(0);
        float a = Math.min(1, Math.min(toastT * 5, (2.8f - toastT) * 4));
        float w = g.width(s, 24, g.bold) + 60;
        float y = T + 96 - (1 - Math.min(1, toastT * 6)) * 20;
        g.r.set(800 - w / 2, y - 24, 800 + w / 2, y + 24);
        g.p.setShader(null);
        g.p.setColor(G.alpha(0xFF0C0F13, (int) (235 * a)));
        c.drawRoundRect(g.r, 8, 8, g.p);
        g.p.setColor(G.alpha(col, (int) (255 * a)));
        c.drawRect(800 - w / 2, y - 24, 800 - w / 2 + 6, y + 24, g.p);
        g.text(c, s, 800 + 3, y, 24, G.alpha(G.TEXT, (int) (255 * a)), g.bold, Paint.Align.CENTER);
    }

    private void drawDialog(Canvas c) {
        g.clearHits();
        g.p.setShader(null);
        g.p.setColor(G.alpha(0xFF000000, (int) (170 * Math.min(1, dlgT * 6))));
        c.drawRect(L, T, R, Bm, g.p);
        float w = 760;
        float lines = estimateLines(dlgBody, w - 80, 24);
        float h = Math.min(600, 150 + lines * 32 + 70);
        float t = 360 - h / 2;
        float s = 0.9f + 0.1f * Math.min(1, dlgT * 8);
        c.save();
        c.scale(s, s, 800, 360);
        g.panelTitle(c, 800 - w / 2, t, 800 + w / 2, t + h, dlgTitle);
        g.para(c, dlgBody, 800 - w / 2 + 40, t + 90, w - 80, 24, G.TEXT, g.med, 32);
        int n = dlgButtons.length;
        float gap = 16, bw = Math.min(210, (w - 60 - (n - 1) * gap) / n), x0 = 800 + w / 2 - 30 - n * bw - (n - 1) * gap;
        for (int i = 0; i < n; i++) {
            float x = x0 + i * (bw + gap);
            g.button(c, D_BTN + i, x, t + h - 76, x + bw, t + h - 24, dlgButtons[i], dlgStyles[i]);
        }
        c.restore();
    }

    private float estimateLines(String s, float maxW, float size) {
        int n = 0;
        for (String raw : s.split("\n")) {
            float w = g.width(raw, size, g.med);
            n += Math.max(1, (int) Math.ceil(w / maxW));
        }
        return n;
    }

    // ---------------------------------------------------------------- HUD shared by room screens
    void drawHud(Canvas c, boolean full) {
        Game gm = game;
        // money + time pill (top-left)
        g.r.set(L + 18, T + 14, L + 330, T + 62);
        g.p.setShader(null);
        g.p.setColor(0xD90C0F13);
        c.drawRoundRect(g.r, 8, 8, g.p);
        g.s.setColor(G.LINE);
        g.s.setStrokeWidth(1.4f);
        c.drawRoundRect(g.r, 8, 8, g.s);
        g.text(c, Game.money(gm.money), L + 34, T + 38, 28, G.GREEN, g.bold, Paint.Align.LEFT);
        g.text(c, "DAY " + gm.day() + "  " + gm.clock(), L + 316, T + 38, 22, G.DIM, g.mono, Paint.Align.RIGHT);
        if (!full) return;
        // rep stars + mail (top-right)
        float x = R - 18;
        g.r.set(x - 300, T + 14, x, T + 62);
        g.p.setColor(0xD90C0F13);
        c.drawRoundRect(g.r, 8, 8, g.p);
        c.drawRoundRect(g.r, 8, 8, g.s);
        g.text(c, String.format(Locale.US, "REP %.1f", gm.rep), x - 286, T + 38, 22, G.YELLOW, g.bold, Paint.Align.LEFT);
        for (int i = 0; i < 5; i++) star(c, x - 196 + i * 22, T + 38, 8, gm.rep - i);
        g.icon(c, G.I_MAIL, x - 60, T + 38, 16, gm.unread() > 0 ? G.CYAN : G.DIM);
        if (gm.unread() > 0) g.badge(c, x - 34, T + 30, String.valueOf(gm.unread()), G.CYAN);
        g.hit(H_MAIL, x - 90, T + 14, x, T + 62);
        g.iconButton(c, H_SOUND, x - 330, T + 38, 22, sfx.muted ? G.I_MUTE : G.I_SOUND, G.DIM);
        // active order chip (bottom-right)
        Game.Order o = gm.activeOrder();
        if (o != null) {
            String s = "JOB: " + o.title().toUpperCase(Locale.US) + "  •  " + o.bandName() + "  •  PROPS " + (o.propsOut ? "OUT" : "IN");
            float w = g.width(s, 20, g.bold) + 40;
            g.r.set(R - 18 - w, Bm - 58, R - 18, Bm - 16);
            g.p.setColor(0xD90C0F13);
            c.drawRoundRect(g.r, 8, 8, g.p);
            g.s.setColor(G.ORANGE);
            c.drawRoundRect(g.r, 8, 8, g.s);
            g.text(c, s, R - 18 - w / 2, Bm - 37, 20, G.TEXT, g.bold, Paint.Align.CENTER);
            g.hit(H_ORDER, R - 18 - w, Bm - 58, R - 18, Bm - 16);
        }
        // hardware in hand (bottom-left)
        if (gm.hand >= 0) {
            String s = "IN HAND: " + Parts.HW_NAME[gm.hand].toUpperCase(Locale.US);
            float w = g.width(s, 20, g.bold) + 70;
            g.r.set(L + 18, Bm - 58, L + 18 + w, Bm - 16);
            g.p.setColor(0xD90C0F13);
            c.drawRoundRect(g.r, 8, 8, g.p);
            g.s.setColor(G.CYAN);
            c.drawRoundRect(g.r, 8, 8, g.s);
            g.icon(c, G.I_HAND, L + 42, Bm - 37, 13, G.CYAN);
            g.text(c, s, L + 60, Bm - 37, 20, G.TEXT, g.bold, Paint.Align.LEFT);
            g.hit(H_HAND, L + 18, Bm - 58, L + 18 + w, Bm - 16);
        }
    }

    void star(Canvas c, float x, float y, float r, float fill) {
        g.path.reset();
        for (int i = 0; i < 10; i++) {
            double a = -Math.PI / 2 + i * Math.PI / 5;
            float rr = i % 2 == 0 ? r : r * 0.45f;
            float px = x + (float) Math.cos(a) * rr, py = y + (float) Math.sin(a) * rr;
            if (i == 0) g.path.moveTo(px, py);
            else g.path.lineTo(px, py);
        }
        g.path.close();
        g.p.setColor(fill >= 0.5f ? G.YELLOW : 0xFF3A4350);
        c.drawPath(g.path, g.p);
    }

    boolean hudButton(int id) {
        switch (id) {
            case H_SOUND:
                sfx.muted = !sfx.muted;
                prefs.edit().putBoolean("muted", sfx.muted).apply();
                return true;
            case H_MAIL:
                pc.openApp(PcScreen.APP_MAIL);
                go(pc);
                return true;
            case H_ORDER: {
                Game.Order o = game.activeOrder();
                if (o != null) info("CURRENT JOB - " + o.customer.toUpperCase(Locale.US), jobText(o));
                return true;
            }
            case H_HAND:
                game.hand = -1;
                toast("PUT THE HARDWARE BACK", G.DIM);
                return true;
        }
        return false;
    }

    String jobText(Game.Order o) {
        return o.title() + (o.kit ? " (parts supplied)" : "  •  budget " + Game.money(o.budget)) + "\n"
                + "VTX: " + o.bandName() + " (" + Elec.FREQ[o.band][o.chan - 1] + " MHz)\n"
                + "Props: " + (o.propsOut ? "OUT - enable 'motor direction is reversed'" : "IN - default direction") + "\n"
                + "Battery: include one " + o.cells + "S pack\n"
                + "Latest firmware, ELRS bound, ARM switch, all tests done.";
    }

    // ---------------------------------------------------------------- input
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int a = e.getActionMasked();
        if (e.getActionIndex() != 0 && (a == MotionEvent.ACTION_POINTER_DOWN || a == MotionEvent.ACTION_POINTER_UP)) return true;
        float x = (e.getX() - ox) / k, y = (e.getY() - oy) / k;
        switch (a) {
            case MotionEvent.ACTION_DOWN: {
                downId = g.find(x, y);
                downX = x;
                downY = y;
                moved = false;
                consumed = false;
                if (downId > 0) {
                    g.pressedId = downId;
                    g.pressedT = 0.15f;
                }
                if (dlgTitle == null) screen.touch(0, x, y, downId);
                return true;
            }
            case MotionEvent.ACTION_MOVE: {
                if (Math.abs(x - downX) + Math.abs(y - downY) > 16) moved = true;
                if (dlgTitle == null) screen.touch(1, x, y, downId);
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                boolean cancel = a == MotionEvent.ACTION_CANCEL;
                if (dlgTitle == null) screen.touch(cancel ? 3 : 2, x, y, downId);
                if (!cancel && !moved && !consumed && downId > 0 && g.find(x, y) == downId) click(downId);
                g.pressedT = Math.min(g.pressedT, 0.08f);
                return true;
            }
        }
        return true;
    }

    private void click(int id) {
        sfx.play(Sfx.CLICK, 0.6f);
        if (dlgTitle != null) {
            if (id >= D_BTN && id < D_BTN + 10) closeDialog(id - D_BTN);
            return;
        }
        if (hudButton(id)) return;
        screen.button(id);
    }
}
