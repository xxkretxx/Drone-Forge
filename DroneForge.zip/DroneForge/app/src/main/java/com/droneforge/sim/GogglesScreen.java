package com.droneforge.sim;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;

import java.util.Locale;
import java.util.Random;

/** Analog FPV goggles: pick band/channel and look at the drone's camera feed with OSD. */
final class GogglesScreen extends Screen {
    private static final int B_BAND_M = 1, B_BAND_P = 2, B_CH_M = 3, B_CH_P = 4, B_SCAN = 5, B_EXIT = 6;
    int band = 0, chan = 1;
    private float okT, scanT = -1;
    private int staticStream;
    private final Random rnd = new Random();

    GogglesScreen(GameView v) {
        super(v);
    }

    @Override
    void enter() {
        okT = 0;
    }

    private int state() {
        return Elec.video(v.game, v.batteryOn, v.benchBatteryPart(), band, chan);
    }

    @Override
    void update(float dt) {
        if (scanT >= 0) {
            scanT += dt;
            if (((int) (scanT * 8)) != ((int) ((scanT - dt) * 8))) {
                chan++;
                if (chan > 8) {
                    chan = 1;
                    band = (band + 1) % 5;
                }
                v.sfx.play(Sfx.TAP, 0.3f);
                if (state() != Elec.V_STATIC) scanT = -1;
            }
            if (scanT > 6) scanT = -1;
        }
        int st = state();
        if (st == Elec.V_OK) {
            okT += dt;
            if (okT > 1.5f && !v.game.build.videoTest) {
                v.game.build.videoTest = true;
                v.sfx.play(Sfx.SUCCESS, 0.6f);
                v.toast("VIDEO CHECK PASSED - CLEAR IMAGE ON " + Elec.BAND_NAME[band] + chan, G.GREEN);
            }
        } else okT = 0;
        boolean wantStatic = st == Elec.V_STATIC;
        if (wantStatic && staticStream == 0) staticStream = v.sfx.play(Sfx.STATIC, 0.25f, 1f, true);
        if (!wantStatic && staticStream != 0) {
            v.sfx.stop(staticStream);
            staticStream = 0;
        }
    }

    @Override
    void draw(Canvas c) {
        g.p.setShader(null);
        g.p.setColor(0xFF050506);
        c.drawRect(v.L, v.T, v.R, v.Bm, g.p);
        float l = 230, t = 40, r = 1370, b = 610;
        c.save();
        g.path.reset();
        g.r.set(l, t, r, b);
        g.path.addRoundRect(g.r, 60, 60, android.graphics.Path.Direction.CW);
        c.clipPath(g.path);
        int st = state();
        Build bd = v.game.build;
        if (st == Elec.V_STATIC) {
            g.p.setColor(0xFF2A2A2A);
            c.drawRect(l, t, r, b, g.p);
            for (int i = 0; i < 900; i++) {
                float x = l + rnd.nextFloat() * (r - l), y = t + rnd.nextFloat() * (b - t);
                int gr = 80 + rnd.nextInt(175);
                g.p.setColor(0xFF000000 | (gr << 16) | (gr << 8) | gr);
                c.drawRect(x, y, x + 3 + rnd.nextInt(10), y + 2, g.p);
            }
            float roll = (v.time * 220) % (b - t);
            g.p.setColor(0x33FFFFFF);
            c.drawRect(l, t + roll, r, t + roll + 40, g.p);
        } else {
            if (st == Elec.V_OK) {
                float jitter = bd.cap < 0 ? (rnd.nextFloat() - 0.5f) * 3 : 0;
                v.res.draw(c, "bg_fpv", l + jitter, t, r + jitter, b, 255);
                // analog look: colour noise + scanlines
                for (int y = (int) t; y < b; y += 4) {
                    g.p.setColor(0x14000000);
                    c.drawRect(l, y, r, y + 2, g.p);
                }
                if (bd.cap < 0) {
                    for (int i = 0; i < 6; i++) {
                        float y = t + rnd.nextFloat() * (b - t);
                        g.p.setColor(0x40FFFFFF);
                        c.drawRect(l, y, r, y + 2, g.p);
                    }
                }
                if (bd.antenna < 0) {
                    for (int i = 0; i < 300; i++) {
                        float x = l + rnd.nextFloat() * (r - l), y = t + rnd.nextFloat() * (b - t);
                        g.p.setColor(0x55FFFFFF);
                        c.drawRect(x, y, x + 6, y + 2, g.p);
                    }
                }
            } else {
                g.p.setColor(0xFF000000);
                c.drawRect(l, t, r, b, g.p);
            }
            if (Elec.fcPowered(v.game, v.batteryOn, false) && !bd.bricked) drawOsd(c, l, t, r, b, st == Elec.V_BLACK);
        }
        c.restore();
        // lens vignette
        g.p.setShader(new RadialGradient(800, 325, 760, new int[]{0x00000000, 0x00000000, 0xCC000000}, new float[]{0, 0.72f, 1}, Shader.TileMode.CLAMP));
        c.drawRect(l, t, r, b, g.p);
        g.p.setShader(null);
        g.s.setColor(0xFF1C1F24);
        g.s.setStrokeWidth(10);
        g.r.set(l, t, r, b);
        c.drawRoundRect(g.r, 60, 60, g.s);
        // controls
        float y = 668;
        g.p.setShader(new LinearGradient(0, 630, 0, 720, 0xFF15181D, 0xFF0B0D10, Shader.TileMode.CLAMP));
        c.drawRect(v.L, 630, v.R, v.Bm, g.p);
        g.p.setShader(null);
        g.text(c, "BAND", 330, y, 20, G.DIM, g.bold, Paint.Align.CENTER);
        g.button(c, B_BAND_M, 380, y - 24, 430, y + 24, "<", G.B_DARK);
        g.text(c, Elec.BAND_NAME[band], 470, y, 34, G.TEXT, g.bold, Paint.Align.CENTER);
        g.button(c, B_BAND_P, 510, y - 24, 560, y + 24, ">", G.B_DARK);
        g.text(c, "CH", 610, y, 20, G.DIM, g.bold, Paint.Align.CENTER);
        g.button(c, B_CH_M, 640, y - 24, 690, y + 24, "<", G.B_DARK);
        g.text(c, String.valueOf(chan), 730, y, 34, G.TEXT, g.bold, Paint.Align.CENTER);
        g.button(c, B_CH_P, 770, y - 24, 820, y + 24, ">", G.B_DARK);
        g.text(c, Elec.FREQ[band][chan - 1] + " MHz", 900, y, 26, G.CYAN, g.mono, Paint.Align.CENTER);
        g.button(c, B_SCAN, 1010, y - 26, 1150, y + 26, scanT >= 0 ? "SCANNING" : "AUTO SCAN", G.B_CYAN);
        g.button(c, B_EXIT, 1180, y - 26, 1320, y + 26, "TAKE OFF", G.B_DARK);
        String hint = !v.batteryOn ? "No signal: plug a battery into the drone on the bench." : st == Elec.V_STATIC ? "Static: goggles and VTX are on different channels (or the VTX gets no power)."
                : st == Elec.V_BLACK ? "Signal but no picture: check the camera wiring (VIDEO -> CAM pad) and VTX video wire." : "Clear picture!";
        g.text(c, hint, 800, 20, 18, st == Elec.V_OK ? G.GREEN : G.DIM, g.med, Paint.Align.CENTER);
    }

    private void drawOsd(Canvas c, float l, float t, float r, float b, boolean black) {
        Build bd = v.game.build;
        Parts.Part bat = v.benchBatteryPart();
        float vb = bat == null ? 0 : bat.cells * 4.15f - (float) Math.sin(v.time) * 0.05f;
        osd(c, String.format(Locale.US, "%.1fV", vb), l + 90, t + 70, Paint.Align.LEFT);
        osd(c, bd.craftName.isEmpty() ? "DRONEFORGE" : bd.craftName.toUpperCase(Locale.US), (l + r) / 2, t + 70, Paint.Align.CENTER);
        boolean link = Elec.rxLink(v.game, v.batteryOn, v.usbOn, v.radioOn);
        osd(c, link ? "RSSI 99" : "RSSI 0", r - 90, t + 70, Paint.Align.RIGHT);
        float aux = v.radio.ch[4];
        boolean armed = link && bd.armAux == 1 && aux >= bd.armLo && aux <= bd.armHi;
        osd(c, armed ? "ARMED" : (link ? "DISARMED" : "RXLOSS"), (l + r) / 2, b - 70, Paint.Align.CENTER);
        osd(c, "VTX " + Elec.BAND_NAME[bd.vtxBand] + bd.vtxChan + " 25MW", l + 90, b - 70, Paint.Align.LEFT);
        osd(c, String.format(Locale.US, "%02d:%02d", (int) v.powerOnT / 60, (int) v.powerOnT % 60), r - 90, b - 70, Paint.Align.RIGHT);
        g.s.setColor(0xFFFFFFFF);
        g.s.setStrokeWidth(3);
        float cx = (l + r) / 2, cy = (t + b) / 2;
        c.drawLine(cx - 30, cy, cx - 10, cy, g.s);
        c.drawLine(cx + 10, cy, cx + 30, cy, g.s);
        c.drawLine(cx, cy - 10, cx, cy - 22, g.s);
        if (black) osd(c, "NO CAMERA SIGNAL", cx, cy + 60, Paint.Align.CENTER);
    }

    private void osd(Canvas c, String s, float x, float y, Paint.Align al) {
        g.tp.setTypeface(g.mono);
        g.tp.setTextSize(30);
        g.tp.setTextAlign(al);
        g.tp.setStyle(Paint.Style.STROKE);
        g.tp.setStrokeWidth(5);
        g.tp.setColor(0xFF000000);
        c.drawText(s, x, y + 10, g.tp);
        g.tp.setStyle(Paint.Style.FILL);
        g.tp.setColor(0xFFF2F2F2);
        c.drawText(s, x, y + 10, g.tp);
    }

    @Override
    void button(int id) {
        switch (id) {
            case B_BAND_M: band = (band + 4) % 5; break;
            case B_BAND_P: band = (band + 1) % 5; break;
            case B_CH_M: chan = chan == 1 ? 8 : chan - 1; break;
            case B_CH_P: chan = chan == 8 ? 1 : chan + 1; break;
            case B_SCAN: scanT = scanT >= 0 ? -1 : 0; break;
            case B_EXIT: back(); break;
        }
    }

    @Override
    boolean back() {
        v.sfx.stop(staticStream);
        staticStream = 0;
        scanT = -1;
        v.room.view = RoomScreen.V_RIGHT;
        v.go(v.room);
        return true;
    }
}
