package com.droneforge.sim;

/** Generated from the Blender scene: clickable areas in background-image pixels (1600x720). */
final class HotData {
    private HotData() {}

    static float[] r(String view, String name) {
        switch (view + "/" + name) {
            case "front/mat": return new float[]{332f, 440f, 1268f, 606f};
            case "front/iron": return new float[]{-33f, 418f, 226f, 535f};
            case "front/smoke": return new float[]{1378f, 526f, 1504f, 592f};
            case "front/psu": return new float[]{1313f, 338f, 1603f, 487f};
            case "front/multimeter": return new float[]{1550f, 529f, 1766f, 644f};
            case "front/pegboard": return new float[]{-21f, -338f, 1621f, 328f};
            case "down/org_0": return new float[]{330f, 374f, 482f, 511f};
            case "down/org_1": return new float[]{477f, 374f, 624f, 511f};
            case "down/org_2": return new float[]{625f, 374f, 766f, 511f};
            case "down/org_3": return new float[]{773f, 374f, 912f, 511f};
            case "down/org_4": return new float[]{916f, 374f, 1059f, 511f};
            case "down/org_5": return new float[]{345f, 238f, 491f, 368f};
            case "down/org_6": return new float[]{488f, 238f, 629f, 368f};
            case "down/org_7": return new float[]{631f, 238f, 767f, 368f};
            case "down/org_8": return new float[]{773f, 238f, 908f, 368f};
            case "down/org_9": return new float[]{912f, 238f, 1051f, 368f};
            case "down/tray": return new float[]{1322f, 232f, 1622f, 475f};
            case "down/mat": return new float[]{-262f, -546f, 1669f, 206f};
            case "left/bin_0": return new float[]{153f, 52f, 464f, 123f};
            case "left/bin_1": return new float[]{482f, 52f, 789f, 123f};
            case "left/bin_2": return new float[]{811f, 52f, 1118f, 123f};
            case "left/bin_3": return new float[]{1136f, 52f, 1447f, 123f};
            case "left/bin_4": return new float[]{172f, 315f, 474f, 382f};
            case "left/bin_5": return new float[]{492f, 315f, 789f, 382f};
            case "left/bin_6": return new float[]{811f, 315f, 1108f, 382f};
            case "left/bin_7": return new float[]{1126f, 315f, 1428f, 382f};
            case "left/bin_8": return new float[]{190f, 561f, 484f, 626f};
            case "left/bin_9": return new float[]{501f, 561f, 789f, 626f};
            case "left/bin_10": return new float[]{811f, 561f, 1099f, 626f};
            case "left/bin_11": return new float[]{1116f, 561f, 1410f, 626f};
            case "right/screen": return new float[]{489f, 179f, 1111f, 440f};
            case "right/goggles": return new float[]{356f, 547f, 560f, 645f};
            case "right/radio": return new float[]{1078f, 546f, 1291f, 652f};
            case "right/desk": return new float[]{-299f, 502f, 1899f, 835f};
            case "back/door": return new float[]{271f, -251f, 941f, 530f};
            case "back/pallet": return new float[]{186f, 524f, 753f, 750f};
            case "back/packtable": return new float[]{1016f, 294f, 1600f, 365f};
            default: return null;
        }
    }

    static float[] pts(String key) {
        switch (key) {
            case "front_mat_corners": return new float[]{332.4f, 605.9f, 1267.6f, 605.9f, 1110.1f, 442.8f, 489.9f, 442.8f};
            case "screen_corners": return new float[]{489.0f, 178.9f, 1111.0f, 178.9f, 1097.0f, 439.5f, 503.0f, 439.5f};
            case "pallet_top": return new float[]{373.8f, 523.6f, 752.6f, 523.6f, 731.9f, 687.6f, 187.0f, 687.6f};
            default: return null;
        }
    }
}
