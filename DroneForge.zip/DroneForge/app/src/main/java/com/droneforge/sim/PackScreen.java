package com.droneforge.sim;

import android.graphics.Canvas;
import android.graphics.Paint;

import java.util.ArrayList;
import java.util.Locale;

/** Packing table: final inspection, box the drone with a battery, tape it up and print the label. */
final class PackScreen extends Screen {
    private static final int B_DRONE = 1, B_BATT = 2, B_PROPS = 3, B_LABEL = 4, B_BACK = 5, B_SCROLL_UP = 6, B_SCROLL_DN = 7;
    private int step;           // 0 empty box, 1 drone in, 2 battery in, 3 taped, 4 labelled
    private int battItem = -1;
    private boolean spareProps;
    private final boolean[] tape = new boolean[30];
    private float scroll;

    PackScreen(GameView v) {
        super(v);
    }

    @Override
    void enter() {
        if (v.game.packedOrder < 0) {
            step = 0;
            battItem = -1;
            spareProps = false;
            for (int i = 0; i < tape.length; i++) tape[i] = false;
        }
        scroll = 0;
    }

    private Game.Item findBattery(Game.Order o) {
        Game.Item best = null;
        for (Game.Item it : v.game.items) {
            if ((it.loc != Game.L_SHELF && it.loc != Game.L_BENCH) || it.p().cat != Parts.BATT || it.damaged) continue;
            if (it.uid == v.benchBattery && v.batteryOn) continue;
            if (o != null && it.p().cells == o.cells) return it;
            if (best == null) best = it;
        }
        return best;
    }

    @Override
    void draw(Canvas c) {
        float s = Math.max((v.R - v.L) / 1600f, (v.Bm - v.T) / 720f);
        v.res.draw(c, "bg_pack", 800 - 800 * s, 360 - 360 * s, 800 + 800 * s, 360 + 360 * s, 255);
        Game gm = v.game;
        float cx = 520, cy = 380, k = 1.45f;
        if (gm.packedOrder >= 0) {
            v.res.sprite(c, "closedbox", cx, cy, k, 0, 255, false);
            label(c, cx, cy, k);
            g.panel(c, 980, 200, 1520, 420);
            g.text(c, "PARCEL READY", 1250, 250, 30, G.GREEN, g.bold, Paint.Align.CENTER);
            g.text(c, gm.courierAt >= 0 ? "Courier pick-up in " + Math.max(1, (int) (gm.courierAt - gm.time)) + " min" : "Waiting for the courier", 1250, 300, 22, G.TEXT, g.med, Paint.Align.CENTER);
            g.text(c, "Payment arrives by email after delivery.", 1250, 340, 20, G.DIM, g.med, Paint.Align.CENTER);
        } else {
            v.res.sprite(c, step >= 3 ? "closedbox" : "openbox", cx, cy, k, 0, 255, false);
            if (step >= 1 && step < 3) {
                c.save();
                v.buildScreen.drawDrone(c, cx, cy - 20, 0.62f * k, true);
                c.restore();
                if (battItem >= 0) v.res.sprite(c, v.game.partOf(battItem).sprite, cx + 120, cy + 110, 0.9f * k, 90, 255, false);
            }
            if (step == 2) {
                float l = cx - 120 * k, r = cx + 120 * k;
                for (int i = 0; i < tape.length; i++) {
                    if (!tape[i]) continue;
                    float x0 = l + (r - l) * i / tape.length;
                    g.p.setShader(null);
                    g.p.setColor(0xCCB8894A);
                    c.drawRect(x0, cy - 18, x0 + (r - l) / tape.length + 1, cy + 18, g.p);
                }
                g.s.setColor(G.alpha(G.ORANGE, 150 + (int) (90 * Math.sin(v.time * 5))));
                g.s.setStrokeWidth(2);
                c.drawLine(l, cy - 26, r, cy - 26, g.s);
                c.drawLine(l, cy + 26, r, cy + 26, g.s);
                g.text(c, "DRAG ACROSS TO CLOSE AND TAPE THE BOX", cx, cy + 60, 20, G.ORANGE, g.bold, Paint.Align.CENTER);
            }
            if (step >= 4) label(c, cx, cy, k);
            drawChecklist(c);
        }
        g.iconButton(c, B_BACK, v.L + 50, v.T + 110, 30, G.I_LEFT, G.TEXT);
        v.drawHud(c, false);
    }

    private void label(Canvas c, float cx, float cy, float k) {
        g.r.set(cx + 10, cy - 90, cx + 140, cy - 10);
        g.p.setShader(null);
        g.p.setColor(0xFFF4F2EC);
        c.drawRect(g.r, g.p);
        g.p.setColor(0xFF111111);
        for (int i = 0; i < 26; i++) c.drawRect(cx + 18 + i * 4, cy - 36, cx + 19 + i * 4 + (i % 3 == 0 ? 2 : 0), cy - 16, g.p);
        g.text(c, "DRONE FORGE", cx + 18, cy - 76, 13, 0xFF111111, g.bold, Paint.Align.LEFT);
        g.text(c, "EXPRESS 24H", cx + 18, cy - 56, 13, 0xFF111111, g.mono, Paint.Align.LEFT);
    }

    private void drawChecklist(Canvas c) {
        Game gm = v.game;
        Game.Order o = gm.order(gm.build.orderId);
        float l = 930, t = 70, r = 1560, b = 640;
        g.panelTitle(c, l, t, r, b, "FINAL INSPECTION" + (o != null ? "  •  " + o.customer.toUpperCase(Locale.US) : ""));
        Elec.Report rep = Elec.inspect(gm, o, battItem >= 0 ? gm.item(battItem) : findBattery(o), true);
        c.save();
        c.clipRect(l + 10, t + 60, r - 10, t + 400);
        float y = t + 80 - scroll;
        for (int i = 0; i < rep.lines.size(); i++) {
            boolean ok = rep.ok.get(i);
            g.icon(c, ok ? G.I_CHECK : G.I_CLOSE, l + 34, y, 9, ok ? G.GREEN : G.RED);
            g.text(c, rep.lines.get(i), l + 54, y, 18, ok ? G.TEXT : 0xFFFF9A9A, g.med, Paint.Align.LEFT);
            y += 27;
        }
        c.restore();
        g.iconButton(c, B_SCROLL_UP, r - 36, t + 90, 18, G.I_UP, G.DIM);
        g.iconButton(c, B_SCROLL_DN, r - 36, t + 380, 18, G.I_DOWN, G.DIM);
        float st = rep.stars();
        g.text(c, String.format(Locale.US, "EXPECTED RATING  %.1f / 5", st), l + 30, t + 428, 22, st >= 4 ? G.GREEN : st >= 2.5f ? G.YELLOW : G.RED, g.bold, Paint.Align.LEFT);
        for (int i = 0; i < 5; i++) v.star(c, l + 330 + i * 26, t + 428, 10, st - i);
        float by = t + 470;
        Build bd = gm.build;
        boolean droneOk = bd.hasFrame();
        g.button(c, B_DRONE, l + 20, by, l + 200, by + 50, step >= 1 ? "1. DRONE ✓" : "1. PLACE DRONE", step == 0 && droneOk ? G.B_PRIMARY : G.B_DARK);
        g.button(c, B_BATT, l + 215, by, l + 405, by + 50, step >= 2 ? "2. BATTERY ✓" : "2. ADD BATTERY", step == 1 ? G.B_PRIMARY : G.B_DARK);
        g.button(c, B_PROPS, l + 420, by, r - 20, by + 50, spareProps ? "SPARE PROPS ✓" : "+ SPARE PROPS", G.B_DARK);
        g.button(c, B_LABEL, l + 20, by + 64, r - 20, by + 114, step >= 4 ? "LABEL PRINTED" : step == 3 ? "3. PRINT LABEL & SHIP" : "TAPE THE BOX, THEN PRINT THE LABEL",
                step == 3 ? G.B_GOOD : G.B_DISABLED);
    }

    @Override
    void touch(int action, float x, float y, int id) {
        if (step != 2 || id > 0) return;
        float cx = 520, cy = 380, k = 1.45f;
        float l = cx - 120 * k, r = cx + 120 * k;
        if ((action == 0 || action == 1) && Math.abs(y - cy) < 40 && x >= l && x <= r) {
            int i = (int) ((x - l) / (r - l) * tape.length);
            if (i >= 0 && i < tape.length && !tape[i]) {
                tape[i] = true;
                if (i % 5 == 0) v.sfx.play(Sfx.TAPE, 0.4f);
            }
            int n = 0;
            for (boolean b : tape) if (b) n++;
            if (n >= tape.length * 0.9f) {
                step = 3;
                v.sfx.play(Sfx.TAPE, 0.8f);
            }
            v.consumed = true;
        }
    }

    @Override
    void button(int id) {
        Game gm = v.game;
        Build bd = gm.build;
        Game.Order o = gm.order(bd.orderId);
        switch (id) {
            case B_BACK: back(); return;
            case B_SCROLL_UP: scroll = Math.max(0, scroll - 120); return;
            case B_SCROLL_DN: scroll = Math.min(560, scroll + 120); return;
            case B_DRONE:
                if (step != 0) return;
                if (!bd.hasFrame()) {
                    v.info("NOTHING TO PACK", "There is no drone on the build bench yet.");
                    return;
                }
                if (v.batteryOn || v.usbOn) {
                    v.info("UNPLUG FIRST", "Disconnect the battery and the USB cable before packing the drone.");
                    return;
                }
                step = 1;
                v.sfx.play(Sfx.PLACE, 0.8f);
                return;
            case B_BATT:
                if (step != 1) return;
                Game.Item bi = findBattery(o);
                if (bi == null) {
                    v.info("NO BATTERY", "You need a battery for the customer. Order one in PartHub.");
                    return;
                }
                battItem = bi.uid;
                step = 2;
                v.sfx.play(Sfx.PLACE, 0.8f);
                if (o != null && bi.p().cells != o.cells) v.toast("WARNING: THIS IS A " + bi.p().cells + "S BATTERY, CUSTOMER WANTS " + o.cells + "S", G.RED);
                return;
            case B_PROPS:
                for (Game.Item it : gm.items) {
                    if ((it.loc == Game.L_SHELF || it.loc == Game.L_BENCH) && it.p().cat == Parts.PROPS && !spareProps) {
                        it.loc = Game.L_SHIPPED;
                        spareProps = true;
                        v.sfx.play(Sfx.PLACE, 0.6f);
                        return;
                    }
                }
                if (!spareProps) v.toast("NO SPARE PROPS IN STOCK", G.DIM);
                return;
            case B_LABEL:
                if (step != 3) return;
                ship(o);
        }
    }

    private void ship(Game.Order o) {
        Game gm = v.game;
        Build bd = gm.build;
        Elec.Report rep = Elec.inspect(gm, o, gm.item(battItem), spareProps);
        float stars = rep.stars();
        StringBuilder sb = new StringBuilder();
        ArrayList<String> bad = new ArrayList<>();
        for (int i = 0; i < rep.lines.size(); i++) if (!rep.ok.get(i)) bad.add(rep.lines.get(i));
        if (bad.isEmpty()) sb.append("Everything works perfectly - it flies like a dream. Thank you!");
        else {
            sb.append(stars >= 3.5f ? "Mostly great, but a few things were off:\n" : "I found some problems:\n");
            for (int i = 0; i < Math.min(6, bad.size()); i++) sb.append("- ").append(bad.get(i)).append("\n");
        }
        if (spareProps) sb.append("\nThanks for the spare props!");
        if (o != null) {
            if (spareProps) stars = Math.min(5, stars + 0.2f);
            o.stars = stars;
            o.report = sb.toString();
            if (o.kit) o.paid = Math.round(o.budget * (0.4f + 0.6f * stars / 5f));
            else o.paid = Math.round(o.budget * (stars >= 4 ? 1f : stars >= 3 ? 0.9f : 0.55f + 0.1f * stars));
            o.shipAt = gm.time;
        }
        // move everything into the parcel
        for (Game.Item it : gm.items) if (it.loc == Game.L_BUILD) it.loc = Game.L_SHIPPED;
        Game.Item bi = gm.item(battItem);
        if (bi != null) bi.loc = Game.L_SHIPPED;
        if (v.benchBattery == battItem) v.benchBattery = -1;
        gm.packedOrder = o == null ? -1 : o.id;
        gm.courierAt = gm.time + 15;
        gm.build = new Build();
        Game.Order next = null;
        for (Game.Order oo : gm.orders) if (oo.status == Game.O_ACCEPTED && oo != o) next = oo;
        if (next != null) gm.build.orderId = next.id;
        if (o != null) o.status = Game.O_PACKED; // becomes SHIPPED when the courier collects it
        step = 4;
        v.sfx.play(Sfx.PRINT, 0.8f);
        v.toast("LABEL PRINTED - PARCEL READY FOR PICK-UP", G.GREEN);
        v.usbOn = false;
        v.batteryOn = false;
        v.save();
    }

    @Override
    boolean back() {
        v.room.view = RoomScreen.V_BACK;
        v.go(v.room);
        return true;
    }
}
