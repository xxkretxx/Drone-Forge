package com.droneforge.sim;

import java.util.ArrayList;

/** Catalogue of every part, tool and piece of hardware in the game. Brands are fictional. */
final class Parts {
    private Parts() {}

    static final int FRAME = 0, MOTOR = 1, ESC = 2, FC = 3, VTX = 4, CAM = 5, RX = 6, ANT = 7, PROPS = 8, BATT = 9, PIGTAIL = 10, CAP = 11, TOOL = 12;
    static final String[] CAT_NAME = {"Frames", "Motors", "ESCs", "Flight Controllers", "Video TX", "Cameras", "Receivers", "Antennas",
            "Props", "Batteries", "Pigtails", "Capacitors", "Tools"};
    static final String[] CAT_SHORT = {"FRAMES", "MOTORS", "ESC", "FLIGHT CTRL", "VTX", "CAMERAS", "RECEIVERS", "ANTENNAS", "PROPS",
            "BATTERIES", "PIGTAILS", "CAPACITORS", "TOOLS"};

    static final class Part {
        final String id, name, brand, desc;
        final int cat;
        final float price;
        // generic spec fields (meaning depends on category)
        int size;          // frame/props: inches
        float arm;         // frame: arm thickness mm
        float mount;       // frame/esc/fc/vtx: stack mount (mm); motor/frame: motor pattern
        boolean m2;        // frame/motor: M2 hardware (else M3)
        int kv, cellsMin, cellsMax; // motor kv, recommended cells / esc max cells / device voltage window
        int amps;          // esc rating
        String target;     // fc firmware target
        int uarts;         // fc uarts
        int mw;            // vtx power
        boolean wideInput; // vtx / cam: accepts battery voltage (else 5 V only)
        String conn;       // vtx/antenna connector, battery plug
        int mah, cells;    // battery
        float capV;        // capacitor voltage
        String sprite, icon;
        int color;         // motor colour index / tint

        Part(String id, int cat, String name, String brand, float price, String desc) {
            this.id = id;
            this.cat = cat;
            this.name = name;
            this.brand = brand;
            this.price = price;
            this.desc = desc;
        }

        String full() {
            return name.startsWith(brand) ? name : brand + " " + name;
        }

        /** Short spec line shown in the shop and inventory. */
        String spec() {
            switch (cat) {
                case FRAME: return size + "\" frame  •  " + (int) arm + " mm arms  •  " + fmtMount(mount) + " stack  •  " + (m2 ? "M2" : "M3") + " motors";
                case MOTOR: return kv + " KV  •  " + cellsMin + "S  •  " + (m2 ? "M2 9x9" : "M3 16x16") + "  •  " + size + "\" props";
                case ESC: return amps + " A 4-in-1  •  up to " + cellsMax + "S  •  " + fmtMount(mount);
                case FC: return target + "  •  " + uarts + " UARTs  •  " + fmtMount(mount) + "  •  OSD";
                case VTX: return "5.8 GHz analog  •  " + mw + " mW  •  " + (wideInput ? "7-36 V" : "5 V only") + "  •  " + conn;
                case CAM: return "Analog  •  " + (size == 19 ? "micro 19 mm" : "nano 14 mm") + "  •  " + (wideInput ? "5-40 V" : "5 V only");
                case RX: return "ELRS 2.4 GHz  •  5 V  •  CRSF";
                case ANT: return "RHCP 5.8 GHz  •  " + conn;
                case PROPS: return size + "\" tri-blade  •  2x CW + 2x CCW";
                case BATT: return cells + "S " + mah + " mAh  •  " + conn;
                case PIGTAIL: return conn + "  •  " + (conn.equals("XT60") ? "12 AWG" : "16 AWG");
                case CAP: return "Low ESR  •  " + (int) capV + " V";
                default: return desc;
            }
        }
    }

    static String fmtMount(float m) {
        return m == 30.5f ? "30.5x30.5" : ((int) m + "x" + (int) m);
    }

    static final ArrayList<Part> ALL = new ArrayList<>();

    private static Part add(Part p) {
        ALL.add(p);
        return p;
    }

    static Part get(String id) {
        for (Part p : ALL) if (p.id.equals(id)) return p;
        return null;
    }

    static {
        Part p;
        // ------------------------------------------------ frames
        p = add(new Part("fr_talon3", FRAME, "Talon 3\" Toothpick", "Talon", 29, "Light 3-inch frame for small 4S builds."));
        p.size = 3; p.arm = 3; p.mount = 20; p.m2 = true; p.sprite = "frame3"; p.icon = "icon_frame3";
        p = add(new Part("fr_krait5", FRAME, "Krait 5\" Freestyle", "Krait", 55, "Tough 5-inch freestyle frame with 5 mm arms."));
        p.size = 5; p.arm = 5; p.mount = 30.5f; p.sprite = "frame5"; p.icon = "icon_frame5";
        p = add(new Part("fr_nimbus5", FRAME, "Nimbus 5\" Race", "Nimbus", 45, "Lean race frame, 4 mm arms."));
        p.size = 5; p.arm = 4; p.mount = 30.5f; p.sprite = "frame5"; p.icon = "icon_frame5";
        p = add(new Part("fr_voyager7", FRAME, "Voyager 7\" Long Range", "Voyager", 79, "Long-range 7-inch frame, 6 mm arms."));
        p.size = 7; p.arm = 6; p.mount = 30.5f; p.sprite = "frame7"; p.icon = "icon_frame7";
        // ------------------------------------------------ motors
        p = add(new Part("mo_1404", MOTOR, "1404 3800KV", "Voltix", 13, "Small motor for 3-inch props on 4S."));
        p.kv = 3800; p.cellsMin = 4; p.size = 3; p.m2 = true; p.sprite = "motor_1404_black"; p.icon = "icon_motor_1404_black";
        p = add(new Part("mo_2207_1950", MOTOR, "2207 1950KV", "Hexon", 19, "Do-it-all 5-inch motor for 6S."));
        p.kv = 1950; p.cellsMin = 6; p.size = 5; p.sprite = "motor_2207_red"; p.icon = "icon_motor_2207_red";
        p = add(new Part("mo_2207_2650", MOTOR, "2207 2650KV", "Hexon", 18, "Punchy 5-inch motor for 4S."));
        p.kv = 2650; p.cellsMin = 4; p.size = 5; p.sprite = "motor_2207_blue"; p.icon = "icon_motor_2207_blue";
        p = add(new Part("mo_2207_1750", MOTOR, "2207 1750KV Silk", "AeroForge", 25, "Ultra smooth premium 6S motor."));
        p.kv = 1750; p.cellsMin = 6; p.size = 5; p.sprite = "motor_2207_purple"; p.icon = "icon_motor_2207_purple";
        p = add(new Part("mo_2806", MOTOR, "2806.5 1300KV", "Orbit", 27, "Efficient long-range motor for 7-inch props on 6S."));
        p.kv = 1300; p.cellsMin = 6; p.size = 7; p.sprite = "motor_2806_gold"; p.icon = "icon_motor_2806_gold";
        // ------------------------------------------------ ESCs
        p = add(new Part("esc_v45", ESC, "Volt45 4-in-1", "Voltix", 45, "45 A BLHeli-style 4-in-1 ESC, 3-6S."));
        p.amps = 45; p.cellsMax = 6; p.mount = 30.5f; p.icon = "icon_esc";
        p = add(new Part("esc_t60", ESC, "Talon 60A 4-in-1", "Talon", 65, "60 A heavy-duty ESC, 3-6S."));
        p.amps = 60; p.cellsMax = 6; p.mount = 30.5f; p.icon = "icon_esc";
        p = add(new Part("esc_v25", ESC, "Volt25 Mini 4-in-1", "Voltix", 32, "25 A ESC for 20x20 stacks, 2-4S."));
        p.amps = 25; p.cellsMax = 4; p.mount = 20; p.icon = "icon_esc";
        // ------------------------------------------------ flight controllers
        p = add(new Part("fc_f405", FC, "SkyRay F405", "SkyRay", 39, "Reliable F4 flight controller with OSD."));
        p.target = "SKYRAYF405"; p.uarts = 4; p.mount = 30.5f; p.icon = "icon_fc";
        p = add(new Part("fc_f722", FC, "SkyRay F722 Pro", "SkyRay", 55, "Fast F7 flight controller, 5 UARTs."));
        p.target = "SKYRAYF722"; p.uarts = 5; p.mount = 30.5f; p.icon = "icon_fc";
        p = add(new Part("fc_f411", FC, "Hexon Nano F411", "Hexon", 27, "Tiny 20x20 F4 board, 2 UARTs."));
        p.target = "HEXONF411"; p.uarts = 2; p.mount = 20; p.icon = "icon_fc";
        // ------------------------------------------------ VTX
        p = add(new Part("vtx_spectra", VTX, "Spectra 1W", "Spectra", 32, "Analog VTX up to 1 W, wide input, SmartAudio."));
        p.mw = 1000; p.wideInput = true; p.conn = "MMCX"; p.sprite = "vtx"; p.icon = "icon_vtx";
        p = add(new Part("vtx_nano", VTX, "Spectra Nano 400", "Spectra", 19, "Tiny 400 mW VTX. 5 V input only!"));
        p.mw = 400; p.wideInput = false; p.conn = "UFL"; p.sprite = "vtx"; p.icon = "icon_vtx";
        // ------------------------------------------------ cameras
        p = add(new Part("cam_owl", CAM, "Owl Micro 1200TVL", "Owl", 24, "Crisp micro camera, 5-40 V input."));
        p.size = 19; p.wideInput = true; p.sprite = "cam"; p.icon = "icon_cam";
        p = add(new Part("cam_owlnano", CAM, "Owl Nano", "Owl", 18, "Nano camera, 5 V only."));
        p.size = 14; p.wideInput = false; p.sprite = "cam"; p.icon = "icon_cam";
        // ------------------------------------------------ receivers
        p = add(new Part("rx_link", RX, "LinkRS Nano ELRS", "LinkRS", 14, "ExpressLRS 2.4 GHz nano receiver."));
        p.sprite = "rx"; p.icon = "icon_rx";
        p = add(new Part("rx_linkd", RX, "LinkRS Diversity ELRS", "LinkRS", 26, "Dual-antenna ExpressLRS receiver."));
        p.sprite = "rx"; p.icon = "icon_rx";
        // ------------------------------------------------ antennas
        p = add(new Part("ant_mmcx", ANT, "Lollipop RHCP MMCX", "Orbit", 8, "Classic lollipop antenna, MMCX plug."));
        p.conn = "MMCX"; p.sprite = "antenna"; p.icon = "icon_antenna";
        p = add(new Part("ant_ufl", ANT, "Lollipop RHCP U.FL", "Orbit", 7, "Light lollipop antenna, U.FL plug."));
        p.conn = "UFL"; p.sprite = "antenna"; p.icon = "icon_antenna";
        // ------------------------------------------------ props
        p = add(new Part("pr_3", PROPS, "Gale 3018 (4 pcs)", "Gale", 3, ""));
        p.size = 3; p.sprite = "prop3"; p.icon = "icon_prop3";
        p = add(new Part("pr_5", PROPS, "Gale 5130 (4 pcs)", "Gale", 4, ""));
        p.size = 5; p.sprite = "prop5"; p.icon = "icon_prop5";
        p = add(new Part("pr_7", PROPS, "Gale 7040 (4 pcs)", "Gale", 6, ""));
        p.size = 7; p.sprite = "prop7"; p.icon = "icon_prop7";
        // ------------------------------------------------ batteries
        p = add(new Part("ba_4s650", BATT, "Pulse 4S 650", "Pulse", 17, ""));
        p.cells = 4; p.mah = 650; p.conn = "XT30"; p.sprite = "bat4_1300"; p.icon = "icon_bat4_1300";
        p = add(new Part("ba_4s1300", BATT, "Pulse 4S 1300", "Pulse", 28, ""));
        p.cells = 4; p.mah = 1300; p.conn = "XT60"; p.sprite = "bat4_1300"; p.icon = "icon_bat4_1300";
        p = add(new Part("ba_6s1100", BATT, "Pulse 6S 1100", "Pulse", 34, ""));
        p.cells = 6; p.mah = 1100; p.conn = "XT60"; p.sprite = "bat6_1100"; p.icon = "icon_bat6_1100";
        p = add(new Part("ba_6s4000", BATT, "Pulse 6S 4000 Li-ion", "Pulse", 55, ""));
        p.cells = 6; p.mah = 4000; p.conn = "XT60"; p.sprite = "bat6_4000"; p.icon = "icon_bat6_4000";
        // ------------------------------------------------ pigtails & caps
        p = add(new Part("pt_xt60", PIGTAIL, "XT60 Pigtail", "Orbit", 3, ""));
        p.conn = "XT60"; p.sprite = "xt60"; p.icon = "icon_xt60";
        p = add(new Part("pt_xt30", PIGTAIL, "XT30 Pigtail", "Orbit", 2.5f, ""));
        p.conn = "XT30"; p.sprite = "xt60"; p.icon = "icon_xt60";
        p = add(new Part("cap_35", CAP, "1000 uF 35 V", "Orbit", 1.5f, ""));
        p.capV = 35; p.sprite = "cap"; p.icon = "icon_cap";
        p = add(new Part("cap_50", CAP, "470 uF 50 V", "Orbit", 1.8f, ""));
        p.capV = 50; p.sprite = "cap"; p.icon = "icon_cap";
        // ------------------------------------------------ tools (owned, not stored on shelves)
        p = add(new Part("tl_t12", TOOL, "T12 Pro Iron", "Forge", 85, "Heats 3x faster and holds temperature on big pads. Wider perfect-joint window."));
        p.icon = "icon_iron";
        p = add(new Part("tl_flux", TOOL, "Flux Pen", "Forge", 9, "Liquid flux. Solder flows easier: perfect window grows and fewer cold joints."));
        p.icon = "icon_flux";
        p = add(new Part("tl_smoke", TOOL, "Smoke Stopper", "Forge", 14, "Current-limiting lamp/fuse for the very first power-up. Saves parts from shorts."));
        p.icon = "icon_smoke";
    }

    // ------------------------------------------------------------ screws & hardware in the organizer (down view)
    static final String[] HW_NAME = {"M2x4", "M2x6", "M3x6", "M3x8", "M3x10", "M3x12", "M3 nyloc nut", "M3 nylon nut", "Rubber grommet", "M3 standoff"};
    static final float[] HW_LEN = {4, 6, 6, 8, 10, 12, 0, 0, 0, 0};
    static final boolean[] HW_M2 = {true, true, false, false, false, false, false, false, false, false};
    static final int HW_NONE = -1, HW_GROMMET = 8, HW_STANDOFF = 9, HW_NYLON = 7, HW_NYLOC = 6;
}
