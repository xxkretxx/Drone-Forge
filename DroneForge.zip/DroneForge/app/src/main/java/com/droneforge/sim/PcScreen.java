package com.droneforge.sim;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;

import java.util.ArrayList;
import java.util.Locale;

/** "Forge OS" desktop computer: windows you can open, move, minimise and close. */
final class PcScreen extends Screen {
    static final int APP_MAIL = 0, APP_SHOP = 1, APP_CONFIG = 2, APP_TRACK = 3, APP_GUIDE = 4, N_APPS = 5;
    static final String[] APP_NAME = {"Mail", "PartHub", "FC Configurator", "Tracking", "Build Guide"};
    static final int[] APP_ICON = {G.I_MAIL, G.I_CART, G.I_CHIP, G.I_TRUCK, G.I_BOOK};
    static final int[] APP_COL = {0xFF2F80ED, 0xFFFF7A1A, 0xFFF2C94C, 0xFF27AE60, 0xFF9B51E0};

    // ids: 1..99 desktop, 100+app*1000+n app content
    private static final int B_ICON = 10, B_TASK = 30, B_WCLOSE = 50, B_WMIN = 60, B_WMAX = 70, B_EXIT = 80, B_START = 81;

    static final class Win {
        int app;
        float x, y, w, h;
        boolean min, max;
        float scroll, scroll2;
    }

    final ArrayList<Win> wins = new ArrayList<>(); // last = top
    private Win dragWin;
    private float dragDX, dragDY;
    private Win scrollWin;
    private float scrollY0, scrollV0;
    private boolean scrollRight;
    final ConfigApp config;
    private boolean booted;
    private float bootT;

    // mail state
    private int mailSel = -1;
    // shop state
    private int shopCat = Parts.FRAME;
    private boolean express;

    PcScreen(GameView v) {
        super(v);
        config = new ConfigApp(v, this);
    }

    @Override
    void enter() {
        if (!booted) {
            booted = true;
            bootT = 0;
            v.sfx.play(Sfx.BOOT, 0.5f);
        }
    }

    @Override
    void update(float dt) {
        bootT += dt;
    }

    Win find(int app) {
        for (Win w : wins) if (w.app == app) return w;
        return null;
    }

    void openApp(int app) {
        Win w = find(app);
        if (w == null) {
            w = new Win();
            w.app = app;
            int n = wins.size();
            w.x = 150 + n * 30;
            w.y = 30 + n * 20;
            w.w = app == APP_CONFIG ? 1380 : 1280;
            w.h = 600;
            w.max = true;
            wins.add(w);
            if (app == APP_MAIL && mailSel < 0 && !v.game.mails.isEmpty()) mailSel = 0;
        }
        w.min = false;
        wins.remove(w);
        wins.add(w);
    }

    float[] rect(Win w) {
        if (w.max) return new float[]{0, 0, 1600, 674};
        return new float[]{w.x, w.y, w.x + w.w, w.y + w.h};
    }

    // ---------------------------------------------------------------- drawing
    @Override
    void draw(Canvas c) {
        g.p.setShader(null);
        g.p.setColor(0xFF07080A);
        c.drawRect(v.L, v.T, v.R, v.Bm, g.p);
        drawDesktop(c, true);
        g.iconButton(c, B_EXIT, v.R - 34, v.T + 30, 22, G.I_CLOSE, G.TEXT);
    }

    /** Draws the whole desktop into 0..1600 x 0..720. interactive = register hit areas. */
    void drawDesktop(Canvas c, boolean in) {
        c.save();
        c.clipRect(0, 0, 1600, 720);
        g.p.setShader(new LinearGradient(0, 0, 1600, 720, 0xFF0B1C2B, 0xFF1A0E08, Shader.TileMode.CLAMP));
        c.drawRect(0, 0, 1600, 720, g.p);
        g.p.setShader(null);
        // wallpaper logo
        g.s.setColor(0x18FF7A1A);
        g.s.setStrokeWidth(3);
        for (int i = 0; i < 6; i++) c.drawCircle(1100, 330, 80 + i * 55, g.s);
        g.text(c, "FORGE OS", 1100, 330, 64, 0x30FFFFFF, g.bold, Paint.Align.CENTER);
        // icons
        for (int a = 0; a < N_APPS; a++) {
            float x = 70, y = 70 + a * 120;
            g.r.set(x - 36, y - 36, x + 36, y + 36);
            g.p.setColor(APP_COL[a]);
            c.drawRoundRect(g.r, 16, 16, g.p);
            g.icon(c, APP_ICON[a], x, y, 22, 0xFFFFFFFF);
            g.text(c, APP_NAME[a], x, y + 54, 17, G.TEXT, g.bold, Paint.Align.CENTER);
            if (a == APP_MAIL && v.game.unread() > 0) g.badge(c, x + 34, y - 34, String.valueOf(v.game.unread()), G.RED);
            if (in) g.hit(B_ICON + a, x - 50, y - 44, x + 50, y + 66);
        }
        // windows
        for (Win w : wins) if (!w.min) drawWin(c, w, in);
        // taskbar
        g.p.setColor(0xF2101418);
        c.drawRect(0, 674, 1600, 720, g.p);
        g.p.setColor(G.ORANGE);
        g.r.set(8, 680, 108, 714);
        c.drawRoundRect(g.r, 6, 6, g.p);
        g.text(c, "FORGE", 58, 697, 20, 0xFF1A0E04, g.bold, Paint.Align.CENTER);
        float tx = 130;
        for (Win w : wins) {
            boolean top = w == topWin();
            g.r.set(tx, 680, tx + 190, 714);
            g.p.setColor(top && !w.min ? 0xFF2A3440 : 0xFF181E25);
            c.drawRoundRect(g.r, 6, 6, g.p);
            g.p.setColor(APP_COL[w.app]);
            c.drawRect(tx + 8, 710, tx + 182, 713, g.p);
            g.icon(c, APP_ICON[w.app], tx + 22, 697, 10, 0xFFFFFFFF);
            g.text(c, APP_NAME[w.app], tx + 40, 697, 18, G.TEXT, g.med, Paint.Align.LEFT);
            if (in) g.hit(B_TASK + w.app, tx, 680, tx + 190, 714);
            tx += 200;
        }
        g.text(c, v.game.clock(), 1580, 690, 18, G.TEXT, g.mono, Paint.Align.RIGHT);
        g.text(c, "DAY " + v.game.day(), 1580, 708, 14, G.DIM, g.mono, Paint.Align.RIGHT);
        if (v.usbOn && v.game.build.fc >= 0) {
            g.icon(c, G.I_USB, 1470, 697, 12, G.CYAN);
            g.text(c, "FC", 1490, 697, 16, G.CYAN, g.bold, Paint.Align.LEFT);
        }
        if (in && bootT < 1.2f) {
            g.p.setColor(G.alpha(0xFF000000, (int) (255 * Math.max(0, 1 - bootT / 1.2f))));
            c.drawRect(0, 0, 1600, 720, g.p);
        }
        c.restore();
    }

    Win topWin() {
        for (int i = wins.size() - 1; i >= 0; i--) if (!wins.get(i).min) return wins.get(i);
        return null;
    }

    private void drawWin(Canvas c, Win w, boolean in) {
        float[] r = rect(w);
        float l = r[0], t = r[1], rr = r[2], b = r[3];
        g.p.setColor(0x66000000);
        g.r.set(l + 6, t + 10, rr + 6, b + 10);
        c.drawRoundRect(g.r, 10, 10, g.p);
        g.r.set(l, t, rr, b);
        g.p.setColor(0xFF161B21);
        c.drawRoundRect(g.r, 10, 10, g.p);
        g.s.setColor(w == topWin() ? APP_COL[w.app] : G.LINE);
        g.s.setStrokeWidth(1.5f);
        c.drawRoundRect(g.r, 10, 10, g.s);
        // title bar
        g.p.setColor(0xFF1F262E);
        c.drawRect(l + 1, t + 1, rr - 1, t + 40, g.p);
        g.icon(c, APP_ICON[w.app], l + 24, t + 21, 10, APP_COL[w.app]);
        g.text(c, APP_NAME[w.app], l + 44, t + 21, 20, G.TEXT, g.bold, Paint.Align.LEFT);
        int[] ic = {G.I_MIN, G.I_PLUS, G.I_CLOSE};
        int[] ids = {B_WMIN + w.app, B_WMAX + w.app, B_WCLOSE + w.app};
        for (int i = 0; i < 3; i++) {
            float bx = rr - 30 - (2 - i) * 46;
            if (i == 2) {
                g.p.setColor(g.pressed(ids[i]) ? 0xFFB33A3A : 0xFF2A1F22);
                c.drawRect(bx - 22, t + 1, bx + 22, t + 40, g.p);
            }
            g.icon(c, ic[i], bx, t + 21, 9, G.TEXT);
            if (in) g.hit(ids[i], bx - 22, t, bx + 22, t + 40);
        }
        // client
        c.save();
        c.clipRect(l + 1, t + 41, rr - 1, b - 1);
        switch (w.app) {
            case APP_MAIL: drawMail(c, w, l, t + 41, rr, b, in); break;
            case APP_SHOP: drawShop(c, w, l, t + 41, rr, b, in); break;
            case APP_CONFIG: config.draw(c, w, l, t + 41, rr, b, in); break;
            case APP_TRACK: drawTrack(c, w, l, t + 41, rr, b, in); break;
            case APP_GUIDE: drawGuide(c, w, l, t + 41, rr, b, in); break;
        }
        c.restore();
    }

    int aid(int app, int n) {
        return 100 + app * 1000 + n;
    }

    // ---------------------------------------------------------------- mail
    private void drawMail(Canvas c, Win w, float l, float t, float r, float b, boolean in) {
        ArrayList<Game.Mail> ms = v.game.mails;
        float lw = 420;
        g.p.setColor(0xFF12171C);
        c.drawRect(l, t, l + lw, b, g.p);
        c.save();
        c.clipRect(l, t, l + lw, b);
        float y = t - w.scroll;
        for (int i = 0; i < ms.size(); i++) {
            Game.Mail m = ms.get(i);
            float rt = y + i * 78;
            if (rt > b || rt + 78 < t) continue;
            boolean sel = i == mailSel;
            g.p.setColor(sel ? 0xFF233140 : 0x00000000);
            if (sel) c.drawRect(l, rt, l + lw, rt + 78, g.p);
            if (!m.read) {
                g.p.setColor(G.CYAN);
                c.drawCircle(l + 18, rt + 26, 5, g.p);
            }
            g.text(c, m.from, l + 32, rt + 24, 19, m.read ? G.DIM : G.TEXT, g.bold, Paint.Align.LEFT);
            g.text(c, clip(m.subject, 40), l + 32, rt + 52, 17, m.read ? G.DIM2 : G.DIM, g.med, Paint.Align.LEFT);
            g.text(c, timeStr(m.time), l + lw - 14, rt + 24, 14, G.DIM2, g.mono, Paint.Align.RIGHT);
            g.s.setColor(0xFF1F262E);
            g.s.setStrokeWidth(1);
            c.drawLine(l + 10, rt + 77, l + lw - 10, rt + 77, g.s);
            if (in) g.hit(aid(APP_MAIL, i), l, rt, l + lw, rt + 78);
        }
        c.restore();
        if (mailSel >= 0 && mailSel < ms.size()) {
            Game.Mail m = ms.get(mailSel);
            m.read = true;
            float x = l + lw + 40;
            c.save();
            c.clipRect(l + lw, t, r, b);
            float yy = t + 40 - w.scroll2;
            g.text(c, m.subject, x, yy, 28, G.TEXT, g.bold, Paint.Align.LEFT);
            g.text(c, "From: " + m.from + (m.addr.isEmpty() ? "" : "  <" + m.addr + ">") + "   •   " + timeStr(m.time), x, yy + 36, 17, G.DIM, g.med, Paint.Align.LEFT);
            float endY = g.para(c, m.body, x, yy + 86, r - x - 40, 21, 0xFFD5DBE2, g.med, 29);
            Game.Order o = v.game.order(m.orderId);
            if (m.kind == 1 && o != null) {
                float by = endY + 16;
                if (o.status == Game.O_OFFER) {
                    g.button(c, aid(APP_MAIL, 900), x, by, x + 220, by + 52, "ACCEPT JOB", G.B_GOOD);
                    g.button(c, aid(APP_MAIL, 901), x + 240, by, x + 420, by + 52, "DECLINE", G.B_DARK);
                    g.text(c, "Tip: check part prices in PartHub before you accept.", x + 440, by + 26, 17, G.DIM, g.med, Paint.Align.LEFT);
                } else {
                    String st = o.status == Game.O_DECLINED ? "DECLINED" : o.status == Game.O_ACCEPTED ? "ACCEPTED - IN PROGRESS" : o.status == Game.O_PAID ? "COMPLETED & PAID" : "SHIPPED";
                    g.chip(c, x, by + 20, st, o.status == Game.O_DECLINED ? G.DIM : G.GREEN, false);
                }
            }
            c.restore();
        } else g.text(c, "Select a message", (l + lw + r) / 2, (t + b) / 2, 24, G.DIM2, g.med, Paint.Align.CENTER);
    }

    static String clip(String s, int n) {
        return s.length() > n ? s.substring(0, n - 1) + "…" : s;
    }

    String timeStr(float t) {
        int m = (int) t % 1440;
        return String.format(Locale.US, "D%d %02d:%02d", (int) (t / 1440) + 1, m / 60, m % 60);
    }

    // ---------------------------------------------------------------- shop
    private void drawShop(Canvas c, Win w, float l, float t, float r, float b, boolean in) {
        Game gm = v.game;
        // header
        g.p.setColor(0xFF1B1209);
        c.drawRect(l, t, r, t + 56, g.p);
        g.text(c, "PART", l + 24, t + 28, 30, G.TEXT, g.bold, Paint.Align.LEFT);
        g.text(c, "HUB", l + 24 + g.width("PART", 30, g.bold), t + 28, 30, G.ORANGE, g.bold, Paint.Align.LEFT);
        g.text(c, "FPV parts, shipped fast", l + 150, t + 30, 17, G.DIM, g.med, Paint.Align.LEFT);
        g.text(c, "Balance: " + Game.money(gm.money), r - 380, t + 28, 20, G.GREEN, g.bold, Paint.Align.RIGHT);
        // categories
        float cy = t + 70;
        for (int i = 0; i <= Parts.TOOL; i++) {
            float x = l + 14, y = cy + i * 38;
            boolean sel = i == shopCat;
            g.r.set(x, y, x + 200, y + 34);
            g.p.setColor(sel ? G.ORANGE : 0xFF1A2027);
            c.drawRoundRect(g.r, 6, 6, g.p);
            g.text(c, Parts.CAT_NAME[i], x + 14, y + 17, 18, sel ? 0xFF1A0E04 : G.TEXT, g.bold, Paint.Align.LEFT);
            if (in) g.hit(aid(APP_SHOP, 800 + i), x, y, x + 200, y + 34);
        }
        // products
        float px0 = l + 230, pw = r - 360 - px0 - 10;
        Game.Order o = gm.activeOrder();
        ArrayList<Parts.Part> list = new ArrayList<>();
        for (Parts.Part p : Parts.ALL) if (p.cat == shopCat) list.add(p);
        c.save();
        c.clipRect(px0, t + 60, px0 + pw, b);
        float y = t + 70 - w.scroll;
        for (int i = 0; i < list.size(); i++) {
            Parts.Part p = list.get(i);
            float rt = y + i * 112;
            if (rt > b || rt + 104 < t + 60) continue;
            g.r.set(px0, rt, px0 + pw, rt + 104);
            g.p.setColor(0xFF1A2027);
            c.drawRoundRect(g.r, 8, 8, g.p);
            g.r.set(px0 + 8, rt + 8, px0 + 120, rt + 96);
            g.p.setColor(0xFF2A323C);
            c.drawRoundRect(g.r, 6, 6, g.p);
            v.res.fit(c, p.icon, px0 + 64, rt + 52, 104, 84, 255);
            g.text(c, p.full(), px0 + 136, rt + 26, 22, G.TEXT, g.bold, Paint.Align.LEFT);
            g.text(c, p.spec(), px0 + 136, rt + 54, 17, G.DIM, g.med, Paint.Align.LEFT);
            String note = match(p, o);
            if (note != null) g.chip(c, px0 + 136, rt + 84, note, note.startsWith("FITS") ? G.GREEN : G.RED, false);
            boolean owned = p.cat == Parts.TOOL && gm.hasTool(p.id);
            int stock = gm.count(p.cat, Game.L_SHELF) + gm.count(p.cat, Game.L_BENCH);
            int have = 0;
            for (Game.Item it : gm.items) if ((it.loc == Game.L_SHELF || it.loc == Game.L_BENCH) && it.part.equals(p.id)) have++;
            int inCart = 0;
            for (String s : gm.cart) if (s.equals(p.id)) inCart++;
            g.text(c, Game.money(p.price), px0 + pw - 170, rt + 30, 24, G.GREEN, g.bold, Paint.Align.RIGHT);
            if (p.cat != Parts.TOOL) g.text(c, "in stock: " + have, px0 + pw - 170, rt + 60, 15, G.DIM2, g.med, Paint.Align.RIGHT);
            if (owned) g.chip(c, px0 + pw - 140, rt + 52, "OWNED", G.GREEN, false);
            else g.button(c, aid(APP_SHOP, i), px0 + pw - 150, rt + 28, px0 + pw - 14, rt + 76, inCart > 0 ? "ADD (" + inCart + ")" : "ADD", G.B_PRIMARY);
        }
        c.restore();
        // cart
        float cl = r - 350;
        g.p.setColor(0xFF12171C);
        c.drawRect(cl, t + 56, r, b, g.p);
        g.text(c, "CART", cl + 20, t + 84, 22, G.ORANGE, g.bold, Paint.Align.LEFT);
        float sum = 0;
        ArrayList<String> uniq = new ArrayList<>();
        for (String s : gm.cart) if (!uniq.contains(s)) uniq.add(s);
        float yy = t + 114;
        for (int i = 0; i < uniq.size() && i < 9; i++) {
            Parts.Part p = Parts.get(uniq.get(i));
            int n = 0;
            for (String s : gm.cart) if (s.equals(p.id)) n++;
            sum += n * p.price;
            g.text(c, n + "x " + clip(p.name, 22), cl + 20, yy, 17, G.TEXT, g.med, Paint.Align.LEFT);
            g.text(c, Game.money(n * p.price), r - 56, yy, 16, G.DIM, g.mono, Paint.Align.RIGHT);
            g.icon(c, G.I_MINUS, r - 26, yy, 7, G.RED);
            if (in) g.hit(aid(APP_SHOP, 600 + i), r - 44, yy - 14, r - 8, yy + 14);
            yy += 34;
        }
        if (uniq.isEmpty()) g.text(c, "Your cart is empty", cl + 20, yy, 17, G.DIM2, g.med, Paint.Align.LEFT);
        float ship = express ? 12 : 0;
        float by = b - 190;
        g.s.setColor(G.LINE);
        c.drawLine(cl + 16, by - 12, r - 16, by - 12, g.s);
        g.text(c, "Shipping", cl + 20, by + 10, 17, G.DIM, g.med, Paint.Align.LEFT);
        g.button(c, aid(APP_SHOP, 700), cl + 20, by + 26, cl + 160, by + 62, "STANDARD 60m", express ? G.B_DARK : G.B_CYAN);
        g.button(c, aid(APP_SHOP, 701), cl + 170, by + 26, r - 20, by + 62, "EXPRESS 20m +$12", express ? G.B_CYAN : G.B_DARK);
        g.text(c, "Total", cl + 20, by + 92, 20, G.TEXT, g.bold, Paint.Align.LEFT);
        g.text(c, Game.money(sum + (gm.cart.isEmpty() ? 0 : ship)), r - 20, by + 92, 24, G.GREEN, g.bold, Paint.Align.RIGHT);
        g.button(c, aid(APP_SHOP, 702), cl + 20, by + 118, r - 20, by + 170, "CHECKOUT", gm.cart.isEmpty() ? G.B_DISABLED : G.B_PRIMARY);
    }

    /** Compatibility hint against the current job. */
    private String match(Parts.Part p, Game.Order o) {
        if (o == null) return null;
        switch (p.cat) {
            case Parts.FRAME: return p.size == o.size ? "FITS JOB" : "WRONG SIZE FOR JOB";
            case Parts.MOTOR: return p.size == o.size && p.cellsMin == o.cells ? "FITS JOB (" + o.size + "\" " + o.cells + "S)" : "NOT FOR " + o.size + "\" " + o.cells + "S";
            case Parts.PROPS: return p.size == o.size ? "FITS JOB" : "WRONG SIZE";
            case Parts.BATT: return p.cells == o.cells ? "FITS JOB" : "WRONG CELL COUNT";
            case Parts.ESC: return p.cellsMax >= o.cells && (o.size == 3) == (p.mount == 20) ? "FITS JOB" : "NOT FOR THIS JOB";
            case Parts.FC: return (o.size == 3) == (p.mount == 20) ? "FITS JOB" : "WRONG STACK SIZE";
            default: return null;
        }
    }

    private void checkout() {
        Game gm = v.game;
        if (gm.cart.isEmpty()) return;
        float sum = express ? 12 : 0;
        ArrayList<String> tools = new ArrayList<>(), parts = new ArrayList<>();
        for (String s : gm.cart) {
            Parts.Part p = Parts.get(s);
            sum += p.price;
            if (p.cat == Parts.TOOL) tools.add(s);
            else parts.add(s);
        }
        if (sum > gm.money) {
            v.info("PAYMENT DECLINED", "Not enough money. Total " + Game.money(sum) + ", balance " + Game.money(gm.money) + ".");
            v.sfx.play(Sfx.ERROR, 0.7f);
            return;
        }
        gm.money -= sum;
        for (String s : tools) if (!gm.hasTool(s)) gm.tools.add(s);
        if (!parts.isEmpty()) gm.ship(parts, express ? 20 : 60, "PartHub", express);
        StringBuilder sb = new StringBuilder("Thanks for your order!\n\n");
        for (String s : gm.cart) sb.append("- ").append(Parts.get(s).full()).append("  ").append(Game.money(Parts.get(s).price)).append("\n");
        sb.append("\nShipping: ").append(express ? "Express (20 min) $12.00" : "Standard (60 min) free").append("\nTotal charged: ").append(Game.money(sum));
        if (!tools.isEmpty()) sb.append("\n\nTools are delivered digitally to your bench right away.");
        gm.cart.clear();
        v.sfx.play(Sfx.CASH, 0.6f);
        gm.mail("PartHub", "orders@parthub.shop", "Order confirmed (" + Game.money(sum) + ")", sb.toString(), 2, -1);
        v.save();
    }

    // ---------------------------------------------------------------- tracking
    private void drawTrack(Canvas c, Win w, float l, float t, float r, float b, boolean in) {
        Game gm = v.game;
        float x = l + 40, y = t + 40 - w.scroll;
        g.text(c, "INCOMING PARCELS", x, y, 22, G.ORANGE, g.bold, Paint.Align.LEFT);
        y += 40;
        boolean any = false;
        for (Game.Delivery d : gm.deliveries) {
            if (d.state == 2) continue;
            any = true;
            g.text(c, d.from + "  •  " + d.parts.size() + " items" + (d.express ? "  •  EXPRESS" : ""), x, y, 20, G.TEXT, g.bold, Paint.Align.LEFT);
            float total = d.express ? 20 : 60;
            float prog = d.state >= 1 ? 1 : 1 - Math.max(0, d.arriveAt - gm.time) / total;
            g.bar(c, x + 520, y - 8, x + 900, y + 8, Math.max(0.03f, prog), d.state >= 1 ? G.GREEN : G.CYAN);
            g.text(c, d.state >= 1 ? "DELIVERED - on the pallet" : "arrives in " + Math.max(1, (int) (d.arriveAt - gm.time)) + " min", x + 920, y, 18, G.DIM, g.med, Paint.Align.LEFT);
            y += 44;
        }
        if (!any) {
            g.text(c, "No parcels on the way.", x, y, 19, G.DIM2, g.med, Paint.Align.LEFT);
            y += 44;
        }
        y += 20;
        g.text(c, "JOBS", x, y, 22, G.ORANGE, g.bold, Paint.Align.LEFT);
        y += 40;
        for (Game.Order o : gm.orders) {
            if (o.status == Game.O_DECLINED || o.status == Game.O_OFFER) continue;
            String st = o.status == Game.O_ACCEPTED ? "IN PROGRESS" : o.status == Game.O_PACKED ? "WAITING FOR COURIER" : o.status == Game.O_SHIPPED ? "IN TRANSIT TO CUSTOMER"
                    : "PAID " + Game.money(o.paid) + "  •  " + String.format(Locale.US, "%.1f", o.stars) + " stars";
            g.text(c, o.customer + "  •  " + o.title(), x, y, 20, G.TEXT, g.bold, Paint.Align.LEFT);
            g.text(c, st, x + 520, y, 18, o.status == Game.O_PAID ? G.GREEN : G.CYAN, g.med, Paint.Align.LEFT);
            y += 40;
        }
    }

    // ---------------------------------------------------------------- guide
    static final String[][] GUIDE = {
            {"1. PLAN THE BUILD", "Match the parts to the job: frame size, motors made for the right battery (around 1700-1950 KV on 6S, 2400-2700 KV on 4S for 5\"), an ESC rated for the cell count, a stack that fits the frame (30.5x30.5 for 5\" and 7\", 20x20 for small builds), and props for the frame size."},
            {"2. MOTORS", "Place the motors on the arms, flip the frame and screw them from below. Screw length matters: about 2-4 mm of thread should go into the motor. Too short = loose motor, too long = the screw touches the windings and burns the motor. Arm thickness + 3 mm is a safe choice (5 mm arms -> M3x8). Tighten firmly, but don't strip them."},
            {"3. STACK", "Install the standoffs with rubber grommets (soft mounting keeps vibrations away from the gyro). Put the 4-in-1 ESC on the bottom with its arrow pointing forward."},
            {"4. MOTOR WIRES", "Trim each motor wire so it reaches its ESC pad without slack, then solder it. Heat the pad and wire together, feed a little solder and stop when it flows and looks shiny. Too short = cold grainy joint. Too long = blobs, bridges or a lifted pad. 350-380°C works well for motor wires. Wire order does not matter - direction is fixed in software."},
            {"5. POWER LEAD + CAP", "Solder the XT60 pigtail: RED to +, BLACK to -. This needs a hot iron (400°C+) because the pads and 12 AWG wire soak up heat. Add the low-ESR capacitor on the same pads: the striped leg is MINUS. Its voltage rating must be well above the battery voltage (6S = 25.2 V -> use 35 V or better 50 V)."},
            {"6. FLIGHT CONTROLLER", "Mount the FC on top of the ESC, arrow forward, and plug in the ESC harness. Remember the target name printed on the board - you need it for flashing."},
            {"7. RECEIVER", "ELRS receiver: 5V -> 5V, GND -> GND, and the data lines CROSS: receiver TX -> FC Rx pad, receiver RX -> FC Tx pad, on the same UART (e.g. T2/R2). Never put 5 V devices on VBAT or 9 V."},
            {"8. CAMERA & VTX", "Camera: power + GND + VIDEO -> CAM pad. VTX: power from VBAT or 9V (if it accepts wide input; 5 V-only VTX goes on 5V), GND, VIDEO -> VTX pad, SmartAudio -> a free Tx pad (optional, lets you change channels from the configurator). ALWAYS attach the antenna before powering the VTX."},
            {"9. SMOKE TEST", "First power-up always goes through the smoke stopper. If it lights up red, there is a short - unplug and find it (multimeter!). If all is good you hear the ESC start-up tones."},
            {"10. CONFIGURE", "Plug in USB and open FC Configurator. Firmware Flasher: pick the exact target on the board, latest version, full chip erase. Then: Setup -> calibrate accelerometer (and fix Board Alignment if the FC is rotated). Ports -> Serial RX on the receiver's UART. Configuration -> receiver provider CRSF, DSHOT600, 'motor direction is reversed' for props out. Modes -> ARM on AUX1. Save and reboot."},
            {"11. BIND & TEST", "Put the receiver in bind mode (plug the battery in/out 3 times quickly, or 'Bind receiver' in the configurator) and press BIND on the radio. Check the sticks in the Receiver tab. Motors tab (PROPS OFF!): spin each motor, check order and direction, reverse the ones that spin wrong. Goggles: set the same band/channel as the VTX and check the picture."},
            {"12. PROPS & SHIP", "Install props last: a CW prop on every motor that spins clockwise, CCW on the counter-clockwise ones, and tighten the nuts. Unplug everything, then pack the drone with a battery on the packing table and print the label."},
    };

    private void drawGuide(Canvas c, Win w, float l, float t, float r, float b, boolean in) {
        float x = l + 40, y = t + 40 - w.scroll;
        g.text(c, "HOW TO BUILD AN FPV QUAD - THE DRONE FORGE WAY", x, y, 26, G.ORANGE, g.bold, Paint.Align.LEFT);
        y += 50;
        for (String[] s : GUIDE) {
            g.text(c, s[0], x, y, 22, G.TEXT, g.bold, Paint.Align.LEFT);
            y = g.para(c, s[1], x, y + 32, r - x - 60, 19, 0xFFC9D1DA, g.med, 26) + 18;
        }
    }

    // ---------------------------------------------------------------- input
    @Override
    void touch(int action, float x, float y, int id) {
        if (action == 0) {
            Win top = topWin();
            // title bar drag
            for (int i = wins.size() - 1; i >= 0; i--) {
                Win w = wins.get(i);
                if (w.min) continue;
                float[] r = rect(w);
                if (x >= r[0] && x <= r[2] && y >= r[1] && y <= r[3]) {
                    if (w != top) {
                        wins.remove(w);
                        wins.add(w);
                    }
                    if (y < r[1] + 40 && id == 0) {
                        if (w.max) {
                            w.max = false;
                            w.x = Math.max(0, Math.min(1600 - w.w, x - w.w / 2));
                            w.y = 0;
                            r = rect(w);
                        }
                        dragWin = w;
                        dragDX = x - r[0];
                        dragDY = y - r[1];
                    } else {
                        scrollWin = w;
                        scrollY0 = y;
                        scrollRight = w.app == APP_MAIL && x > r[0] + 420;
                        scrollV0 = scrollRight ? w.scroll2 : w.scroll;
                        config.touch(action, x, y, w);
                    }
                    break;
                }
            }
        } else if (action == 1) {
            if (dragWin != null) {
                dragWin.x = Math.max(-dragWin.w + 200, Math.min(1500, x - dragDX));
                dragWin.y = Math.max(0, Math.min(620, y - dragDY));
                v.consumed = true;
            } else if (scrollWin != null) {
                if (scrollWin.app == APP_CONFIG && config.touch(action, x, y, scrollWin)) {
                    v.consumed = true;
                    return;
                }
                if (v.moved) {
                    float nv = Math.max(0, Math.min(3000, scrollV0 - (y - scrollY0)));
                    if (scrollRight) scrollWin.scroll2 = nv;
                    else scrollWin.scroll = nv;
                    v.consumed = true;
                }
            }
        } else {
            if (scrollWin != null && scrollWin.app == APP_CONFIG) config.touch(action, x, y, scrollWin);
            dragWin = null;
            scrollWin = null;
        }
    }

    @Override
    void button(int id) {
        Game gm = v.game;
        if (id == B_EXIT) {
            back();
            return;
        }
        if (id >= B_ICON && id < B_ICON + N_APPS) {
            openApp(id - B_ICON);
            return;
        }
        if (id >= B_TASK && id < B_TASK + N_APPS) {
            Win w = find(id - B_TASK);
            if (w != null) {
                if (!w.min && w == topWin()) w.min = true;
                else openApp(w.app);
            }
            return;
        }
        if (id >= B_WCLOSE && id < B_WCLOSE + N_APPS) {
            Win w = find(id - B_WCLOSE);
            if (w != null) wins.remove(w);
            return;
        }
        if (id >= B_WMIN && id < B_WMIN + N_APPS) {
            Win w = find(id - B_WMIN);
            if (w != null) w.min = true;
            return;
        }
        if (id >= B_WMAX && id < B_WMAX + N_APPS) {
            Win w = find(id - B_WMAX);
            if (w != null) w.max = !w.max;
            return;
        }
        if (id >= 100) {
            int app = (id - 100) / 1000, n = (id - 100) % 1000;
            switch (app) {
                case APP_MAIL: {
                    if (n == 900 || n == 901) {
                        Game.Mail m = gm.mails.get(mailSel);
                        Game.Order o = gm.order(m.orderId);
                        if (o != null && o.status == Game.O_OFFER) {
                            if (n == 900) {
                                if (gm.activeOrder() != null && gm.activeOrder() != o) {
                                    v.info("ONE JOB AT A TIME", "Finish and ship your current job before accepting another one.");
                                    return;
                                }
                                gm.accept(o);
                                v.sfx.play(Sfx.SUCCESS, 0.5f);
                            } else gm.decline(o);
                        }
                    } else if (n < gm.mails.size()) {
                        mailSel = n;
                        Win w = find(APP_MAIL);
                        if (w != null) w.scroll2 = 0;
                    }
                    return;
                }
                case APP_SHOP: {
                    if (n >= 800) {
                        shopCat = n - 800;
                        Win w = find(APP_SHOP);
                        if (w != null) w.scroll = 0;
                    } else if (n == 700) express = false;
                    else if (n == 701) express = true;
                    else if (n == 702) checkout();
                    else if (n >= 600) {
                        ArrayList<String> uniq = new ArrayList<>();
                        for (String s : gm.cart) if (!uniq.contains(s)) uniq.add(s);
                        if (n - 600 < uniq.size()) gm.cart.remove(uniq.get(n - 600));
                    } else {
                        ArrayList<Parts.Part> list = new ArrayList<>();
                        for (Parts.Part p : Parts.ALL) if (p.cat == shopCat) list.add(p);
                        if (n < list.size()) {
                            Parts.Part p = list.get(n);
                            if (p.cat == Parts.TOOL && gm.cart.contains(p.id)) return;
                            gm.cart.add(p.id);
                            v.sfx.play(Sfx.TAP, 0.5f);
                        }
                    }
                    return;
                }
                case APP_CONFIG: config.button(n); return;
            }
        }
    }

    @Override
    boolean back() {
        v.room.view = RoomScreen.V_RIGHT;
        v.go(v.room);
        return true;
    }
}
