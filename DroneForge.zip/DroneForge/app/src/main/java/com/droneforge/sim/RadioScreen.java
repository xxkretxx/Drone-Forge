package com.droneforge.sim;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;

/** The ELRS radio transmitter: gimbals, switches and the ExpressLRS bind menu. */
final class RadioScreen extends Screen {
    private static final int B_BIND = 1, B_POWER = 2, B_SA = 3, B_SB = 4, B_EXIT = 5;
    /** Channel values in microseconds, AETR + 4 aux. */
    final float[] ch = {1500, 1500, 1000, 1500, 1000, 1000, 1000, 1000};
    private float bindT = -1;
    private int dragStick = -1;
    private final float[] stick = {0, -1, 0, 0}; // left x (yaw), left y (throttle), right x (roll), right y (pitch)

    RadioScreen(GameView v) {
        super(v);
    }

    @Override
    void update(float dt) {
        if (bindT >= 0) {
            bindT += dt;
            if (v.bindModeT > 0 && Elec.devWorks(v.game, 0, v.batteryOn, v.usbOn, v.benchBatteryPart())) {
                v.game.build.bound = true;
                v.bindModeT = 0;
                bindT = -1;
                v.sfx.play(Sfx.BIND, 0.9f);
                v.toast("RECEIVER BOUND! RX LED IS NOW SOLID", G.GREEN);
            } else if (bindT > 6) {
                bindT = -1;
                v.toast("BIND TIMED OUT - THE RECEIVER WAS NOT IN BIND MODE", G.RED);
            }
        }
        if (dragStick < 0) {
            // self-centering except throttle
            stick[0] *= 0.8f;
            stick[2] *= 0.8f;
            stick[3] *= 0.8f;
        }
        ch[3] = 1500 + stick[0] * 500;
        ch[2] = 1000 + (stick[1] + 1) * 500;
        ch[0] = 1500 + stick[2] * 500;
        ch[1] = 1500 - stick[3] * 500;
    }

    private float gimX(int i) {
        return i == 0 ? 480 : 1120;
    }

    @Override
    void draw(Canvas c) {
        g.p.setShader(new LinearGradient(0, v.T, 0, v.Bm, 0xFF1B1F25, 0xFF0D0F12, Shader.TileMode.CLAMP));
        c.drawRect(v.L, v.T, v.R, v.Bm, g.p);
        g.p.setShader(null);
        // radio body
        g.r.set(220, 120, 1380, 660);
        g.p.setShader(new LinearGradient(0, 120, 0, 660, 0xFF2E333B, 0xFF1A1D22, Shader.TileMode.CLAMP));
        c.drawRoundRect(g.r, 120, 120, g.p);
        g.p.setShader(null);
        g.s.setColor(0xFF41474F);
        g.s.setStrokeWidth(3);
        c.drawRoundRect(g.r, 120, 120, g.s);
        // gimbals
        for (int i = 0; i < 2; i++) {
            float cx = gimX(i), cy = 420;
            g.p.setColor(0xFF111317);
            c.drawCircle(cx, cy, 135, g.p);
            g.s.setColor(0xFF3A3F47);
            c.drawCircle(cx, cy, 135, g.s);
            g.s.setColor(0xFF23272D);
            c.drawLine(cx - 110, cy, cx + 110, cy, g.s);
            c.drawLine(cx, cy - 110, cx, cy + 110, g.s);
            float sx = stick[i * 2], sy = stick[i * 2 + 1];
            float px = cx + sx * 100, py = cy - sy * 100;
            g.s.setColor(0xFF8E959F);
            g.s.setStrokeWidth(10);
            c.drawLine(cx, cy, px, py, g.s);
            g.p.setColor(0xFF555B64);
            c.drawCircle(px, py, 34, g.p);
            g.p.setColor(0xFF7B828C);
            c.drawCircle(px - 6, py - 6, 20, g.p);
            g.text(c, i == 0 ? "THROTTLE / YAW" : "PITCH / ROLL", cx, cy + 165, 18, G.DIM, g.bold, Paint.Align.CENTER);
        }
        // switches
        sw(c, B_SA, 330, 190, "SA  ARM", ch[4] > 1500);
        sw(c, B_SB, 1270, 190, "SB  ANGLE", ch[5] > 1500);
        // LCD
        g.r.set(640, 160, 960, 400);
        g.p.setColor(v.radioOn ? 0xFF0E2A33 : 0xFF0A0C0E);
        c.drawRoundRect(g.r, 10, 10, g.p);
        g.s.setColor(0xFF000000);
        g.s.setStrokeWidth(4);
        c.drawRoundRect(g.r, 10, 10, g.s);
        if (v.radioOn) {
            g.text(c, "MODEL 01: QUAD", 660, 186, 20, G.CYAN, g.mono, Paint.Align.LEFT);
            g.text(c, "ExpressLRS 2.4G 250Hz", 660, 214, 17, 0xFF9ADFF2, g.mono, Paint.Align.LEFT);
            boolean link = v.game.build.bound && Elec.devWorks(v.game, 0, v.batteryOn, v.usbOn, v.benchBatteryPart());
            String st = bindT >= 0 ? "BINDING..." : link ? "CONNECTED  RSSI -38dBm" : "NO RECEIVER LINK";
            g.text(c, st, 660, 246, 17, link ? G.GREEN : (bindT >= 0 ? G.YELLOW : G.RED), g.mono, Paint.Align.LEFT);
            String[] nm = {"AIL", "ELE", "THR", "RUD", "AU1"};
            for (int i = 0; i < 5; i++) {
                float y = 280 + i * 22;
                g.text(c, nm[i], 660, y, 15, 0xFF9ADFF2, g.mono, Paint.Align.LEFT);
                g.bar(c, 700, y - 6, 900, y + 6, (ch[i] - 1000) / 1000f, G.CYAN);
                g.text(c, String.valueOf((int) ch[i]), 945, y, 14, 0xFF9ADFF2, g.mono, Paint.Align.RIGHT);
            }
        } else g.text(c, "OFF", 800, 280, 30, G.DIM2, g.mono, Paint.Align.CENTER);
        g.button(c, B_BIND, 660, 420, 790, 466, "BIND", v.radioOn ? G.B_CYAN : G.B_DISABLED);
        g.button(c, B_POWER, 810, 420, 940, 466, v.radioOn ? "POWER OFF" : "POWER ON", G.B_DARK);
        g.button(c, B_EXIT, v.R - 190, v.Bm - 70, v.R - 30, v.Bm - 22, "PUT DOWN", G.B_DARK);
        g.panel(c, v.L + 20, v.Bm - 110, v.L + 640, v.Bm - 16);
        g.text(c, "ELRS BINDING", v.L + 40, v.Bm - 86, 20, G.ORANGE, g.bold, Paint.Align.LEFT);
        g.text(c, "Put the receiver in bind mode (plug the battery in and out 3 times", v.L + 40, v.Bm - 60, 17, G.DIM, g.med, Paint.Align.LEFT);
        g.text(c, "quickly, or use 'Bind receiver' in the configurator), then press BIND.", v.L + 40, v.Bm - 38, 17, G.DIM, g.med, Paint.Align.LEFT);
    }

    private void sw(Canvas c, int id, float x, float y, String label, boolean on) {
        g.p.setColor(0xFF15181C);
        c.drawCircle(x, y, 26, g.p);
        g.s.setColor(0xFFB8BEC6);
        g.s.setStrokeWidth(10);
        c.drawLine(x, y, x, y + (on ? -50 : 50), g.s);
        g.p.setColor(0xFFDDE2E8);
        c.drawCircle(x, y + (on ? -50 : 50), 9, g.p);
        g.text(c, label, x, y + 78, 18, on ? G.GREEN : G.DIM, g.bold, Paint.Align.CENTER);
        g.hit(id, x - 60, y - 70, x + 60, y + 90);
    }

    @Override
    void touch(int action, float x, float y, int id) {
        if (action == 0 && id == 0) {
            for (int i = 0; i < 2; i++) if (Math.hypot(x - gimX(i), y - 420) < 150) dragStick = i;
        }
        if (dragStick >= 0 && (action == 0 || action == 1)) {
            float sx = Math.max(-1, Math.min(1, (x - gimX(dragStick)) / 100f));
            float sy = Math.max(-1, Math.min(1, -(y - 420) / 100f));
            stick[dragStick * 2] = sx;
            stick[dragStick * 2 + 1] = sy;
            v.consumed = true;
        }
        if (action >= 2) dragStick = -1;
    }

    @Override
    void button(int id) {
        switch (id) {
            case B_BIND:
                if (v.radioOn) {
                    bindT = 0;
                    v.sfx.play(Sfx.BIND, 0.5f);
                }
                break;
            case B_POWER:
                v.radioOn = !v.radioOn;
                v.sfx.play(v.radioOn ? Sfx.BOOT : Sfx.USB_OUT, 0.5f);
                break;
            case B_SA:
                ch[4] = ch[4] > 1500 ? 1000 : 2000;
                v.sfx.play(Sfx.SNAP, 0.5f);
                break;
            case B_SB:
                ch[5] = ch[5] > 1500 ? 1000 : 2000;
                v.sfx.play(Sfx.SNAP, 0.5f);
                break;
            case B_EXIT: back(); break;
        }
    }

    @Override
    boolean back() {
        v.room.view = RoomScreen.V_RIGHT;
        v.go(v.room);
        return true;
    }
}
