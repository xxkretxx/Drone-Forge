package com.droneforge.sim;

import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;

import java.io.InputStream;
import java.util.HashMap;

/** Lazily loaded images from assets/img (renders made in Blender). */
final class Res {
    private final AssetManager am;
    private final HashMap<String, Bitmap> cache = new HashMap<>();
    private final Paint bp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final RectF dst = new RectF();

    Res(AssetManager am) {
        this.am = am;
    }

    Bitmap get(String name) {
        if (name == null) return null;
        Bitmap b = cache.get(name);
        if (b != null || cache.containsKey(name)) return b;
        b = load("img/" + name + ".jpg");
        if (b == null) b = load("img/" + name + ".png");
        cache.put(name, b);
        return b;
    }

    private Bitmap load(String path) {
        try {
            InputStream in = am.open(path);
            Bitmap b = BitmapFactory.decodeStream(in);
            in.close();
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    /** Draws an image stretched into a rectangle. */
    boolean draw(Canvas c, String name, float l, float t, float r, float b, int alpha) {
        Bitmap bm = get(name);
        if (bm == null) return false;
        dst.set(l, t, r, b);
        bp.setAlpha(alpha);
        c.drawBitmap(bm, null, dst, bp);
        return true;
    }

    /** Draws an image centred at (cx, cy), fitted inside w x h keeping aspect. */
    boolean fit(Canvas c, String name, float cx, float cy, float w, float h, int alpha) {
        Bitmap bm = get(name);
        if (bm == null) return false;
        float k = Math.min(w / bm.getWidth(), h / bm.getHeight());
        float hw = bm.getWidth() * k / 2, hh = bm.getHeight() * k / 2;
        return draw(c, name, cx - hw, cy - hh, cx + hw, cy + hh, alpha);
    }

    /** Draws a top-down sprite centred at (cx, cy) with its real size (mm) times px-per-mm, rotated by deg. */
    boolean sprite(Canvas c, String name, float cx, float cy, float ppmm, float deg, int alpha, boolean flipX) {
        Bitmap bm = get(name);
        float[] sz = SprData.size(name);
        if (bm == null || sz == null) return false;
        float hw = sz[0] * ppmm / 2, hh = sz[1] * ppmm / 2;
        c.save();
        c.translate(cx, cy);
        if (deg != 0) c.rotate(deg);
        if (flipX) c.scale(-1, 1);
        dst.set(-hw, -hh, hw, hh);
        bp.setAlpha(alpha);
        c.drawBitmap(bm, null, dst, bp);
        c.restore();
        return true;
    }
}
