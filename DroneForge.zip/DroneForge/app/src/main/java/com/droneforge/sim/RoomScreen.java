package com.droneforge.sim;

import android.graphics.Canvas;
import android.graphics.Paint;

import java.util.ArrayList;
import java.util.Locale;

/** First-person workshop: look left / front / right / back, and down at the hardware organiser. */
final class RoomScreen extends Screen {
    static final int V_LEFT = 0, V_FRONT = 1, V_RIGHT = 2, V_BACK = 3, V_DOWN = 4;
    static final String[] BG = {"bg_left", "bg_front", "bg_right", "bg_back", "bg_down"};
    static final String[] VIEW_NAME = {"PARTS SHELF", "BUILD BENCH", "COMPUTER DESK", "SHIPPING DOCK", "HARDWARE"};

    // ids
    private static final int B_NAV_L = 1, B_NAV_R = 2, B_NAV_D = 3, B_NAV_U = 4, B_MAT = 10, B_IRON = 11, B_SMOKE = 12, B_PSU = 13,
            B_METER = 14, B_PEG = 15, B_ORG = 20, B_BIN = 40, B_SCREEN = 60, B_GOG = 61, B_RADIO = 62, B_PALLET = 70, B_PACK = 71,
            B_DOOR = 72, B_SHELF_CLOSE = 80, B_SHELF_TAKE = 100, B_SHELF_RET = 300, B_SHELF_INFO = 500;

    int view = V_FRONT;
    private int from = -1;
    private float trT = 1, trDir;
    private boolean trVert;
    private float swipeX0, swipeY0;
    private boolean swiping;
    // shelf panel
    private int shelfCat = -1;
    private float shelfScroll, shelfDrag0, shelfScroll0;
    private boolean shelfDragging;

    RoomScreen(GameView v) {
        super(v);
    }

    @Override
    void enter() {
        shelfCat = -1;
        trT = 1;
    }

    // ---------------------------------------------------------------- mapping from background pixels to design units
    float bgS() {
        return Math.max((v.R - v.L) / 1600f, (v.Bm - v.T) / 720f);
    }

    float bx(float x) {
        return 800 + (x - 800) * bgS();
    }

    float by(float y) {
        return 360 + (y - 360) * bgS();
    }

    void turn(int to, float dir, boolean vert) {
        if (trT < 1) return;
        from = view;
        view = to;
        trT = 0;
        trDir = dir;
        trVert = vert;
        shelfCat = -1;
        v.sfx.play(Sfx.WHOOSH, 0.5f);
    }

    void turnLeft() {
        if (view == V_DOWN) return;
        turn((view + 3) % 4, -1, false);
    }

    void turnRight() {
        if (view == V_DOWN) return;
        turn((view + 1) % 4, 1, false);
    }

    @Override
    void update(float dt) {
        if (trT < 1) trT = Math.min(1, trT + dt / 0.38f);
    }

    @Override
    void draw(Canvas c) {
        float e = trT < 1 ? ease(trT) : 1;
        float Wd = v.R - v.L, Hd = v.Bm - v.T;
        if (trT < 1 && from >= 0) {
            c.save();
            if (trVert) c.translate(0, -trDir * e * Hd);
            else c.translate(-trDir * e * Wd, 0);
            drawView(c, from, false);
            c.restore();
            c.save();
            if (trVert) c.translate(0, trDir * (1 - e) * Hd);
            else c.translate(trDir * (1 - e) * Wd, 0);
            drawView(c, view, false);
            c.restore();
            // motion darkening
            g.p.setShader(null);
            g.p.setColor(G.alpha(0xFF000000, (int) (90 * Math.sin(Math.PI * e))));
            c.drawRect(v.L, v.T, v.R, v.Bm, g.p);
        } else {
            drawView(c, view, true);
        }
        drawNav(c);
        v.drawHud(c, true);
        if (shelfCat >= 0) drawShelfPanel(c);
    }

    private static float ease(float t) {
        return t < 0.5f ? 2 * t * t : 1 - (float) Math.pow(-2 * t + 2, 2) / 2;
    }

    private void bg(Canvas c, int vw) {
        float s = bgS();
        if (!v.res.draw(c, BG[vw], 800 - 800 * s, 360 - 360 * s, 800 + 800 * s, 360 + 360 * s, 255)) {
            g.p.setShader(null);
            g.p.setColor(0xFF1A1E24);
            c.drawRect(v.L, v.T, v.R, v.Bm, g.p);
            g.text(c, VIEW_NAME[vw], 800, 360, 60, G.DIM2, g.bold, Paint.Align.CENTER);
        }
    }

    private void drawView(Canvas c, int vw, boolean interactive) {
        bg(c, vw);
        switch (vw) {
            case V_FRONT: drawFront(c, interactive); break;
            case V_DOWN: drawDown(c, interactive); break;
            case V_LEFT: drawLeft(c, interactive); break;
            case V_RIGHT: drawRight(c, interactive); break;
            case V_BACK: drawBack(c, interactive); break;
        }
    }

    private void hot(int id, float[] r, boolean interactive) {
        if (interactive && r != null) g.hit(id, bx(r[0]), by(r[1]), bx(r[2]), by(r[3]));
    }

    /** Small floating label that marks something you can tap. */
    private void tag(Canvas c, String s, float x, float y, int color) {
        float w = g.width(s, 18, g.bold) + 26;
        g.r.set(x - w / 2, y - 15, x + w / 2, y + 15);
        g.p.setShader(null);
        g.p.setColor(0xCC0C0F13);
        c.drawRoundRect(g.r, 6, 6, g.p);
        g.s.setColor(color);
        g.s.setStrokeWidth(1.4f);
        c.drawRoundRect(g.r, 6, 6, g.s);
        g.text(c, s, x, y, 18, G.TEXT, g.bold, Paint.Align.CENTER);
    }

    // ---------------------------------------------------------------- front: build bench
    private void drawFront(Canvas c, boolean in) {
        float[] mat = HotData.r("front", "mat");
        if (mat != null) {
            float cx = bx((mat[0] + mat[2]) / 2), cy = by((mat[1] + mat[3]) / 2 + 6);
            c.save();
            c.scale(1, 0.5f, cx, cy);
            v.buildScreen.drawDrone(c, cx, cy, 1.35f * bgS(), true);
            c.restore();
            hot(B_MAT, mat, in);
            if (in) {
                Build b = v.game.build;
                tag(c, b.hasFrame() ? "BUILD BENCH  •  TAP TO WORK" : "BUILD BENCH  •  START A BUILD", cx, by(mat[1]) - 18, G.ORANGE);
            }
        }
        float[] iron = HotData.r("front", "iron");
        if (iron != null && in) {
            hot(B_IRON, iron, true);
            tag(c, "IRON " + Elec.TEMPS[v.game.ironTemp] + "°C", bx(iron[0] + 150), by(iron[1]) - 10, G.RED);
        }
        float[] sm = HotData.r("front", "smoke");
        if (sm != null) {
            float sx = bx((sm[0] + sm[2]) / 2), sy = by(sm[1] + 26);
            boolean has = v.game.hasTool("tl_smoke");
            int led = v.smokeRedT > 0 ? G.RED : (v.batteryOn && v.game.smokeOn ? G.GREEN : 0);
            if (led != 0) {
                g.p.setShader(null);
                g.p.setColor(G.alpha(led, 90));
                c.drawCircle(sx, sy, 22, g.p);
                g.p.setColor(led);
                c.drawCircle(sx, sy, 6, g.p);
            }
            if (in && has) {
                hot(B_SMOKE, sm, true);
                tag(c, v.game.smokeOn ? "SMOKE STOPPER: IN-LINE" : "SMOKE STOPPER: BYPASSED", sx, by(sm[1]) - 18, v.game.smokeOn ? G.GREEN : G.RED);
            }
        }
        if (in) {
            hot(B_PSU, HotData.r("front", "psu"), true);
            hot(B_METER, HotData.r("front", "multimeter"), true);
            int n = v.game.itemsAt(Game.L_BENCH, -1).size();
            if (n > 0) tag(c, n + " PARTS ON THE BENCH", 800, by(625), G.CYAN);
        }
    }

    // ---------------------------------------------------------------- down: hardware organiser
    private void drawDown(Canvas c, boolean in) {
        for (int i = 0; i < 10; i++) {
            float[] r = HotData.r("down", "org_" + i);
            if (r == null) continue;
            float l = bx(r[0]), t = by(r[1]), rr = bx(r[2]), b = by(r[3]);
            boolean sel = v.game.hand == i;
            if (sel) {
                g.s.setColor(G.CYAN);
                g.s.setStrokeWidth(4);
                g.r.set(l + 2, t + 2, rr - 2, b - 2);
                c.drawRoundRect(g.r, 8, 8, g.s);
            }
            String nm = Parts.HW_NAME[i];
            float w = g.width(nm, 17, g.bold) + 14;
            float cx = (l + rr) / 2;
            g.r.set(cx - w / 2, b - 30, cx + w / 2, b - 8);
            g.p.setShader(null);
            g.p.setColor(sel ? G.CYAN : 0xDD0C0F13);
            c.drawRoundRect(g.r, 5, 5, g.p);
            g.text(c, nm, cx, b - 19, 17, sel ? 0xFF0C0F13 : G.TEXT, g.bold, Paint.Align.CENTER);
            if (in) g.hit(B_ORG + i, l, t, rr, b);
        }
        if (in) {
            g.panel(c, 800 - 420, by(530), 800 + 420, by(530) + 92);
            g.text(c, "HARDWARE ORGANISER", 800, by(530) + 28, 22, G.ORANGE, g.bold, Paint.Align.CENTER);
            String s = v.game.hand >= 0 ? "Holding " + Parts.HW_NAME[v.game.hand] + ". Use it on the bench with the hex driver."
                    : "Tap a compartment to pick up screws, nuts, grommets or standoffs.";
            g.text(c, s, 800, by(530) + 62, 20, G.DIM, g.med, Paint.Align.CENTER);
        }
    }

    // ---------------------------------------------------------------- left: shelves
    private void drawLeft(Canvas c, boolean in) {
        for (int i = 0; i < 12; i++) {
            float[] r = HotData.r("left", "bin_" + i);
            if (r == null) continue;
            float l = bx(r[0]), t = by(r[1]), rr = bx(r[2]), b = by(r[3]);
            float top = t - 150 * bgS();
            ArrayList<Game.Item> its = v.game.itemsAt(Game.L_SHELF, i);
            // peek icons of the contents
            int shown = Math.min(3, its.size());
            for (int k = 0; k < shown; k++) {
                Parts.Part p = its.get(k).p();
                float ix = l + (rr - l) * (0.3f + k * 0.2f), iy = t - 30 * bgS();
                v.res.fit(c, p.icon, ix, iy, 110 * bgS(), 90 * bgS(), 255);
            }
            // label on the bin lip
            float cx = (l + rr) / 2, cy = (t + b) / 2;
            g.text(c, Parts.CAT_SHORT[i], cx, cy - 4, 19, 0xFF1A1A1A, g.bold, Paint.Align.CENTER);
            int n = its.size();
            g.badge(c, rr - 26, t + 4, String.valueOf(n), n > 0 ? G.ORANGE : 0xFF6A7380);
            if (in) g.hit(B_BIN + i, l, top, rr, b);
        }
        if (in && shelfCat < 0) tag(c, "TAP A BIN TO TAKE PARTS TO THE BENCH", 800, v.Bm - 90, G.ORANGE);
    }

    private void drawShelfPanel(Canvas c) {
        g.p.setShader(null);
        g.p.setColor(0x99000000);
        c.drawRect(v.L, v.T, v.R, v.Bm, g.p);
        float l = 320, t = 90, r = 1280, b = 650;
        g.panelTitle(c, l, t, r, b, Parts.CAT_NAME[shelfCat]);
        g.iconButton(c, B_SHELF_CLOSE, r - 34, t + 30, 20, G.I_CLOSE, G.TEXT);
        ArrayList<Game.Item> list = new ArrayList<>();
        list.addAll(v.game.itemsAt(Game.L_SHELF, shelfCat));
        list.addAll(v.game.itemsAt(Game.L_BENCH, shelfCat));
        c.save();
        c.clipRect(l + 10, t + 60, r - 10, b - 10);
        float y = t + 70 - shelfScroll;
        if (list.isEmpty()) g.text(c, "Empty. Order parts in the PartHub shop on the PC (turn right).", 800, t + 200, 22, G.DIM, g.med, Paint.Align.CENTER);
        for (int i = 0; i < list.size(); i++) {
            Game.Item it = list.get(i);
            Parts.Part p = it.p();
            float rowT = y + i * 96;
            if (rowT > b || rowT + 90 < t + 60) continue;
            g.r.set(l + 20, rowT, r - 20, rowT + 86);
            g.p.setColor(it.loc == Game.L_BENCH ? 0xFF16283A : G.PANEL2);
            c.drawRoundRect(g.r, 8, 8, g.p);
            v.res.fit(c, p.icon, l + 75, rowT + 43, 90, 76, 255);
            g.text(c, p.full(), l + 135, rowT + 26, 24, G.TEXT, g.bold, Paint.Align.LEFT);
            g.text(c, p.spec(), l + 135, rowT + 56, 19, G.DIM, g.med, Paint.Align.LEFT);
            if (it.damaged) g.chip(c, l + 135 + g.width(p.full(), 24, g.bold) + 14, rowT + 26, "DAMAGED", G.RED, true);
            if (it.loc == Game.L_SHELF) g.button(c, B_SHELF_TAKE + i, r - 220, rowT + 20, r - 40, rowT + 66, "TO BENCH", G.B_PRIMARY);
            else g.button(c, B_SHELF_RET + i, r - 220, rowT + 20, r - 40, rowT + 66, "ON BENCH ✓", G.B_DARK);
            g.button(c, B_SHELF_INFO + i, r - 300, rowT + 20, r - 236, rowT + 66, "?", G.B_DARK);
        }
        c.restore();
    }

    private ArrayList<Game.Item> shelfList() {
        ArrayList<Game.Item> list = new ArrayList<>();
        list.addAll(v.game.itemsAt(Game.L_SHELF, shelfCat));
        list.addAll(v.game.itemsAt(Game.L_BENCH, shelfCat));
        return list;
    }

    // ---------------------------------------------------------------- right: desk
    private void drawRight(Canvas c, boolean in) {
        float[] sc = HotData.r("right", "screen");
        if (sc != null) {
            float l = bx(sc[0]) + 4, t = by(sc[1]) + 4, r = bx(sc[2]) - 4, b = by(sc[3]) - 4;
            c.save();
            c.clipRect(l, t, r, b);
            c.translate(l, t);
            c.scale((r - l) / 1600f, (b - t) / 720f);
            v.pc.drawDesktop(c, false);
            c.restore();
            if (in) {
                hot(B_SCREEN, sc, true);
                tag(c, "COMPUTER", (l + r) / 2, t - 22, G.CYAN);
            }
        }
        if (in) {
            float[] go = HotData.r("right", "goggles");
            if (go != null) {
                hot(B_GOG, go, true);
                tag(c, "FPV GOGGLES", bx((go[0] + go[2]) / 2), by(go[1]) - 18, G.PURPLE);
            }
            float[] ra = HotData.r("right", "radio");
            if (ra != null) {
                hot(B_RADIO, ra, true);
                tag(c, "RADIO", bx((ra[0] + ra[2]) / 2), by(ra[1]) - 18, G.GREEN);
            }
        }
    }

    // ---------------------------------------------------------------- back: dock
    private void drawBack(Canvas c, boolean in) {
        float[] q = HotData.pts("pallet_top");
        int n = 0;
        for (Game.Delivery d : v.game.deliveries) if (d.state == 1) n++;
        if (q != null) {
            float cx = bx((q[0] + q[2] + q[4] + q[6]) / 4), cy = by((q[1] + q[3] + q[5] + q[7]) / 4);
            int k = 0;
            for (Game.Delivery d : v.game.deliveries) {
                if (d.state != 1) continue;
                String spr = d.boxSize() == 0 ? "icon_box_s" : d.boxSize() == 1 ? "icon_box_m" : "icon_box_l";
                float ox = (k % 2 == 0 ? -1 : 1) * 70 * bgS() * (k > 0 ? 1 : 0), oy = -(k / 2) * 90 * bgS();
                float sz = (d.boxSize() == 0 ? 170 : d.boxSize() == 1 ? 230 : 290) * bgS();
                v.res.fit(c, spr, cx + ox, cy - sz * 0.32f + oy, sz, sz, 255);
                k++;
                if (k >= 5) break;
            }
            if (in) {
                float[] pr = HotData.r("back", "pallet");
                if (pr != null) {
                    g.hit(B_PALLET, bx(pr[0]), by(pr[1]) - 220 * bgS(), bx(pr[2]), by(pr[3]));
                    tag(c, n > 0 ? n + (n == 1 ? " PARCEL - TAP TO OPEN" : " PARCELS - TAP TO OPEN") : "DELIVERY PALLET (EMPTY)", cx, by(pr[1]) - 230 * bgS(),
                            n > 0 ? G.ORANGE : G.DIM);
                }
            }
        }
        float[] pt = HotData.r("back", "packtable");
        if (pt != null) {
            float cx = bx((pt[0] + pt[2]) / 2), ty = by(pt[1]);
            if (v.game.packedOrder >= 0) {
                v.res.fit(c, "icon_box_m", cx, ty - 40 * bgS(), 210 * bgS(), 210 * bgS(), 255);
                if (in) tag(c, v.game.courierAt >= 0 ? "PARCEL READY  •  COURIER IN " + Math.max(1, (int) (v.game.courierAt - v.game.time)) + " MIN" : "PARCEL READY", cx, ty - 150 * bgS(), G.GREEN);
            } else if (in) tag(c, "PACKING TABLE", cx, ty - 30, G.ORANGE);
            if (in) g.hit(B_PACK, bx(pt[0]), by(pt[1]) - 150 * bgS(), bx(pt[2]), by(pt[3]) + 160 * bgS());
        }
    }

    // ---------------------------------------------------------------- navigation
    private void drawNav(Canvas c) {
        if (shelfCat >= 0) return;
        if (view != V_DOWN) {
            float cy = 400;
            g.iconButton(c, B_NAV_L, v.L + 52, cy, 34, G.I_LEFT, G.TEXT);
            g.iconButton(c, B_NAV_R, v.R - 52, cy, 34, G.I_RIGHT, G.TEXT);
            g.text(c, VIEW_NAME[(view + 3) % 4], v.L + 52, cy + 52, 15, G.DIM, g.bold, Paint.Align.CENTER);
            g.text(c, VIEW_NAME[(view + 1) % 4], v.R - 52, cy + 52, 15, G.DIM, g.bold, Paint.Align.CENTER);
        }
        if (view == V_FRONT) {
            g.iconButton(c, B_NAV_D, 800, v.Bm - 44, 30, G.I_DOWN, G.TEXT);
        }
        if (view == V_DOWN) g.iconButton(c, B_NAV_U, 800, v.T + 110, 30, G.I_UP, G.TEXT);
    }

    // ---------------------------------------------------------------- input
    @Override
    void touch(int action, float x, float y, int id) {
        if (shelfCat >= 0) {
            if (action == 0) {
                shelfDrag0 = y;
                shelfScroll0 = shelfScroll;
                shelfDragging = true;
            } else if (action == 1 && shelfDragging && v.moved) {
                int n = shelfList().size();
                shelfScroll = Math.max(0, Math.min(Math.max(0, n * 96 - 480), shelfScroll0 - (y - shelfDrag0)));
                v.consumed = true;
            } else if (action >= 2) shelfDragging = false;
            return;
        }
        if (action == 0) {
            swipeX0 = x;
            swipeY0 = y;
            swiping = true;
        } else if (action == 1 && swiping) {
            float dx = x - swipeX0, dy = y - swipeY0;
            if (Math.abs(dx) > 140 && Math.abs(dx) > Math.abs(dy) * 1.5f) {
                swiping = false;
                v.consumed = true;
                if (dx < 0) turnRight();
                else turnLeft();
            } else if (Math.abs(dy) > 140 && Math.abs(dy) > Math.abs(dx) * 1.5f) {
                swiping = false;
                v.consumed = true;
                if (dy < 0 && view == V_FRONT) turn(V_DOWN, 1, true);
                else if (dy > 0 && view == V_DOWN) turn(V_FRONT, -1, true);
            }
        } else swiping = false;
    }

    @Override
    void button(int id) {
        Game gm = v.game;
        if (shelfCat >= 0) {
            ArrayList<Game.Item> list = shelfList();
            if (id == B_SHELF_CLOSE) shelfCat = -1;
            else if (id >= B_SHELF_TAKE && id < B_SHELF_TAKE + 200) {
                int i = id - B_SHELF_TAKE;
                if (i < list.size()) {
                    list.get(i).loc = Game.L_BENCH;
                    v.sfx.play(Sfx.PLACE, 0.7f);
                    v.toast(list.get(i).p().name.toUpperCase(Locale.US) + " MOVED TO THE BENCH", G.CYAN);
                }
            } else if (id >= B_SHELF_RET && id < B_SHELF_RET + 200) {
                int i = id - B_SHELF_RET;
                if (i < list.size()) list.get(i).loc = Game.L_SHELF;
            } else if (id >= B_SHELF_INFO && id < B_SHELF_INFO + 200) {
                int i = id - B_SHELF_INFO;
                if (i < list.size()) {
                    Parts.Part p = list.get(i).p();
                    v.info(p.full(), p.spec() + "\n\n" + p.desc + (list.get(i).damaged ? "\n\nDAMAGED: " + list.get(i).note : ""));
                }
            }
            return;
        }
        switch (id) {
            case B_NAV_L: turnLeft(); return;
            case B_NAV_R: turnRight(); return;
            case B_NAV_D: turn(V_DOWN, 1, true); return;
            case B_NAV_U: turn(V_FRONT, -1, true); return;
            case B_MAT: v.go(v.buildScreen); return;
            case B_IRON:
                v.dialog("SOLDERING STATION", "Current tip temperature: " + Elec.TEMPS[gm.ironTemp] + "°C.\n\n"
                                + "Small signal pads (receiver, camera, VTX): 320-350°C.\nMotor wires: 350-380°C.\nThick 12 AWG battery leads on big pads: 400°C+.\n\n"
                                + "Too cold = cold, grainy joints. Too hot = lifted pads and burnt flux." + (gm.hasTool("tl_t12") ? "\n\nT12 Pro tip installed." : ""),
                        new String[]{"320°C", "350°C", "380°C", "420°C"}, new int[]{G.B_DARK, G.B_DARK, G.B_DARK, G.B_DARK}, new GameView.DialogCb() {
                            @Override
                            public void on(int i) {
                                if (i >= 0) {
                                    v.game.ironTemp = i;
                                    v.sfx.play(Sfx.IRON, 0.8f);
                                }
                            }
                        });
                return;
            case B_SMOKE:
                gm.smokeOn = !gm.smokeOn;
                v.toast(gm.smokeOn ? "SMOKE STOPPER IN-LINE (SAFE FIRST POWER-UP)" : "SMOKE STOPPER BYPASSED", gm.smokeOn ? G.GREEN : G.RED);
                return;
            case B_PSU:
                v.info("BENCH POWER SUPPLY", "Handy for charging and testing, but this shop tests every drone with a real LiPo through the smoke stopper.");
                return;
            case B_METER:
                v.info("MULTIMETER", "Use the multimeter tool on the build bench to check for shorts: tap two pads and it beeps if they are connected.");
                return;
            case B_SCREEN: v.go(v.pc); return;
            case B_GOG: v.go(v.goggles); return;
            case B_RADIO: v.go(v.radio); return;
            case B_PALLET: {
                for (Game.Delivery d : gm.deliveries) {
                    if (d.state == 1) {
                        v.unbox.open(d);
                        v.go(v.unbox);
                        return;
                    }
                }
                Game.Delivery next = null;
                for (Game.Delivery d : gm.deliveries) if (d.state == 0 && (next == null || d.arriveAt < next.arriveAt)) next = d;
                v.info("DELIVERY PALLET", next == null ? "Nothing on the way. Order parts in PartHub on the PC." : "Next parcel from " + next.from + " arrives in about "
                        + Math.max(1, (int) (next.arriveAt - gm.time)) + " min.");
                return;
            }
            case B_PACK: v.go(v.pack); return;
        }
        if (id >= B_ORG && id < B_ORG + 10) {
            int i = id - B_ORG;
            gm.hand = gm.hand == i ? -1 : i;
            v.sfx.play(Sfx.SCREW, 0.4f);
            return;
        }
        if (id >= B_BIN && id < B_BIN + 12) {
            shelfCat = id - B_BIN;
            shelfScroll = 0;
        }
    }

    @Override
    boolean back() {
        if (shelfCat >= 0) {
            shelfCat = -1;
            return true;
        }
        if (view == V_DOWN) {
            turn(V_FRONT, -1, true);
            return true;
        }
        return false;
    }
}
