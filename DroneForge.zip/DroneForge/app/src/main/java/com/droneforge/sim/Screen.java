package com.droneforge.sim;

import android.graphics.Canvas;

/** A full-screen mode (room views, build bench, PC, goggles...). Coordinates are design units. */
abstract class Screen {
    final GameView v;
    final G g;

    Screen(GameView v) {
        this.v = v;
        this.g = v.g;
    }

    void enter() {}

    void update(float dt) {}

    abstract void draw(Canvas c);

    /** action: 0 down, 1 move, 2 up, 3 cancel. id = hit id under the finger at DOWN (0 = none). */
    void touch(int action, float x, float y, int id) {}

    /** Called for a tap on a registered button. */
    void button(int id) {}

    boolean back() {
        return false;
    }
}
