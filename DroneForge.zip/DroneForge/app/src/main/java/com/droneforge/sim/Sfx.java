package com.droneforge.sim;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.os.SystemClock;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Random;

/** All sounds are synthesised on first start and cached as WAV files, so the APK has no audio assets. */
final class Sfx {
    static final int CLICK = 0, TAP = 1, WHOOSH = 2, MAIL = 3, CASH = 4, TRUCK = 5, DOOR = 6, TAPE = 7, CUT = 8,
            SCREW = 9, TORQUE = 10, STRIP = 11, SIZZLE = 12, IRON = 13, ESC = 14, MOTOR = 15, ERROR = 16, SPARK = 17,
            STATIC = 18, BIND = 19, SUCCESS = 20, PLACE = 21, SNAP = 22, BOOT = 23, KEY = 24, PRINT = 25, FLASHED = 26,
            USB_IN = 27, USB_OUT = 28, ARMED = 29, N = 30;
    private static final int RATE = 22050;
    private final SoundPool pool;
    private final int[] ids = new int[N];
    private final long[] last = new long[N];
    private final Random rnd = new Random();
    volatile boolean muted;

    Sfx(final Context ctx) {
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        pool = new SoundPool.Builder().setMaxStreams(10).setAudioAttributes(aa).build();
        final File dir = ctx.getCacheDir();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Random r = new Random(7);
                for (int i = 0; i < N; i++) {
                    try {
                        File f = new File(dir, "df_sfx1_" + i + ".wav");
                        if (!f.exists()) writeWav(f, synth(i, r));
                        ids[i] = pool.load(f.getAbsolutePath(), 1);
                    } catch (Exception ignored) {
                    }
                }
            }
        }).start();
    }

    int play(int id, float vol) {
        return play(id, vol, 1f, false);
    }

    int play(int id, float vol, float rate, boolean loop) {
        if (muted || id < 0 || id >= N || ids[id] == 0) return 0;
        long now = SystemClock.uptimeMillis();
        if (!loop && now - last[id] < 40) return 0;
        last[id] = now;
        rate = Math.max(0.5f, Math.min(2f, rate * (1f + (rnd.nextFloat() - 0.5f) * 0.04f)));
        vol = Math.max(0f, Math.min(1f, vol));
        return pool.play(ids[id], vol, vol, 1, loop ? -1 : 0, rate);
    }

    void stop(int stream) {
        if (stream != 0) pool.stop(stream);
    }

    void setRate(int stream, float rate) {
        if (stream != 0) pool.setRate(stream, Math.max(0.5f, Math.min(2f, rate)));
    }

    void release() {
        pool.release();
    }

    // ---------------------------------------------------------------- synthesis

    private static float[] synth(int id, Random r) {
        switch (id) {
            case CLICK: {
                float[] b = buf(0.035f);
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    b[i] = (float) (Math.sin(t * 2 * Math.PI * 2400) * Math.exp(-t * 180) + noise(r) * 0.3 * Math.exp(-t * 400));
                }
                return norm(b, 0.5f);
            }
            case TAP: {
                float[] b = buf(0.06f);
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    b[i] = (float) (Math.sin(t * 2 * Math.PI * (900 - t * 4000)) * Math.exp(-t * 70));
                }
                return norm(b, 0.45f);
            }
            case WHOOSH: {
                float[] b = buf(0.32f);
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) b.length;
                    lp += a(300 + 1800 * (float) Math.sin(Math.PI * t)) * (noise(r) - lp);
                    b[i] = lp * (float) Math.sin(Math.PI * t);
                }
                return norm(b, 0.35f);
            }
            case MAIL: return tones(new float[]{1318, 1760}, new float[]{0.12f, 0.35f}, 0.55f, 5f);
            case CASH: {
                float[] b = buf(0.7f);
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    float bell = (float) ((Math.sin(t * 2 * Math.PI * 2093) + 0.6 * Math.sin(t * 2 * Math.PI * 3136)) * Math.exp(-t * 5));
                    float clunk = t < 0.08f ? noise(r) * (float) Math.exp(-t * 60) : 0;
                    float bell2 = t > 0.12f ? (float) (Math.sin((t - 0.12f) * 2 * Math.PI * 2637) * Math.exp(-(t - 0.12f) * 4)) : 0;
                    b[i] = bell * 0.5f + clunk * 0.6f + bell2 * 0.5f;
                }
                return norm(b, 0.6f);
            }
            case TRUCK: {
                float[] b = buf(2.6f);
                float lp = 0, ph = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    float rpm = 38 + 8 * (float) Math.sin(t * 1.7);
                    ph += rpm / RATE;
                    float eng = (float) (Math.sin(ph * 2 * Math.PI) + 0.5 * Math.sin(ph * 4 * Math.PI) + 0.3 * Math.signum(Math.sin(ph * 2 * Math.PI)));
                    lp += a(400) * (noise(r) - lp);
                    float env = Math.min(1, t * 1.5f) * Math.min(1, (2.6f - t) * 2);
                    float beep = (t > 1.2f && ((int) (t * 2.2f)) % 2 == 0) ? (float) Math.sin(t * 2 * Math.PI * 1100) * 0.35f : 0;
                    b[i] = (eng * 0.4f + lp * 0.5f) * env + beep * env;
                }
                return norm(b, 0.55f);
            }
            case DOOR: {
                float[] b = buf(1.4f);
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    float rattle = (float) Math.sin(t * 2 * Math.PI * 23) > 0.6f ? noise(r) : noise(r) * 0.2f;
                    lp += a(1800) * (rattle - lp);
                    b[i] = lp * Math.min(1, t * 4) * Math.min(1, (1.4f - t) * 3);
                }
                return norm(b, 0.5f);
            }
            case TAPE: {
                float[] b = buf(0.6f);
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) b.length;
                    float grain = (r.nextFloat() < 0.15f + t * 0.3f) ? noise(r) : 0;
                    lp += a(2500) * (grain - lp);
                    b[i] = (grain * 0.6f + lp) * (float) Math.sin(Math.PI * Math.min(1, t * 1.3f));
                }
                return norm(b, 0.5f);
            }
            case CUT: {
                float[] b = buf(0.35f);
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) b.length;
                    lp += a(5000) * (noise(r) - lp);
                    b[i] = lp * (float) Math.sin(Math.PI * t) * (0.6f + 0.4f * (float) Math.sin(t * 90));
                }
                return norm(b, 0.4f);
            }
            case SCREW: {
                float[] b = buf(0.5f);
                for (int k = 0; k < 7; k++) {
                    int o = (int) (k * 0.07f * RATE);
                    for (int i = 0; i < 300 && o + i < b.length; i++) {
                        float t = i / (float) RATE;
                        b[o + i] += (float) (Math.sin(t * 2 * Math.PI * 3400) * Math.exp(-t * 900) + noise(r) * 0.5 * Math.exp(-t * 1500));
                    }
                }
                return norm(b, 0.4f);
            }
            case TORQUE: return tones(new float[]{2600}, new float[]{0.0f}, 0.12f, 40f);
            case STRIP: {
                float[] b = buf(0.25f);
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    b[i] = noise(r) * (float) Math.exp(-t * 25) * (r.nextFloat() < 0.4f ? 1 : 0.2f);
                }
                return norm(b, 0.6f);
            }
            case SIZZLE: {
                float[] b = buf(1.2f);
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) b.length;
                    float crackle = r.nextFloat() < 0.04f ? noise(r) * 2 : 0;
                    lp += a(6000) * (noise(r) - lp);
                    b[i] = (lp * 0.35f + crackle) * Math.min(1, t * 8) * Math.min(1, (1 - t) * 4);
                }
                return norm(b, 0.35f);
            }
            case IRON: return tones(new float[]{2793}, new float[]{0f}, 0.15f, 18f);
            case ESC: {
                // classic ESC start-up: three rising tones, pause, two confirmation beeps
                float[] b = buf(1.5f);
                float[] f = {1046, 1318, 1568, 0, 1568, 1568};
                float[] st = {0f, 0.16f, 0.32f, 0.5f, 0.85f, 1.12f};
                for (int k = 0; k < f.length; k++) {
                    if (f[k] == 0) continue;
                    int o = (int) (st[k] * RATE);
                    int len = (int) ((k >= 4 ? 0.16f : 0.14f) * RATE);
                    for (int i = 0; i < len && o + i < b.length; i++) {
                        float t = i / (float) RATE;
                        float sq = Math.sin(t * 2 * Math.PI * f[k]) > 0 ? 1 : -1;
                        b[o + i] += sq * 0.5f * Math.min(1, i / 60f) * Math.min(1, (len - i) / 60f);
                    }
                }
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    lp += a(3500) * (b[i] - lp);
                    b[i] = lp;
                }
                return norm(b, 0.45f);
            }
            case MOTOR: {
                // loopable brushless whine
                float[] b = buf(1.0f);
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    float s = (float) (Math.sin(t * 2 * Math.PI * 440) * 0.5 + Math.sin(t * 2 * Math.PI * 880) * 0.3 + Math.sin(t * 2 * Math.PI * 1320) * 0.15
                            + Math.sin(t * 2 * Math.PI * 147) * 0.3);
                    lp += a(900) * (noise(r) - lp);
                    b[i] = s * 0.7f + lp * 0.5f;
                }
                return norm(b, 0.45f);
            }
            case ERROR: return tones(new float[]{220, 196}, new float[]{0f, 0.16f}, 0.38f, 9f);
            case SPARK: {
                float[] b = buf(1.3f);
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    float pop = t < 0.05f ? noise(r) * 1.5f : 0;
                    float crack = r.nextFloat() < 0.02f * (float) Math.exp(-t * 2) ? noise(r) * 1.4f : 0;
                    lp += a(2000) * (noise(r) - lp);
                    b[i] = pop + crack + lp * 0.4f * (float) Math.exp(-t * 2.5);
                }
                return norm(b, 0.75f);
            }
            case STATIC: {
                float[] b = buf(1.0f);
                float lp = 0;
                for (int i = 0; i < b.length; i++) {
                    lp += a(7000) * (noise(r) - lp);
                    b[i] = lp;
                }
                return norm(b, 0.25f);
            }
            case BIND: return tones(new float[]{1760, 1760, 2349}, new float[]{0f, 0.12f, 0.24f}, 0.5f, 14f);
            case SUCCESS: return tones(new float[]{784, 988, 1175, 1568}, new float[]{0f, 0.08f, 0.16f, 0.26f}, 0.8f, 4f);
            case PLACE: {
                float[] b = buf(0.12f);
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    b[i] = (float) (Math.sin(t * 2 * Math.PI * 180) * Math.exp(-t * 40) + noise(r) * 0.4 * Math.exp(-t * 120));
                }
                return norm(b, 0.55f);
            }
            case SNAP: {
                float[] b = buf(0.08f);
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    b[i] = (float) (noise(r) * Math.exp(-t * 300) + Math.sin(t * 2 * Math.PI * 1600) * Math.exp(-t * 120) * 0.6);
                }
                return norm(b, 0.6f);
            }
            case BOOT: return tones(new float[]{523, 659, 784, 1046}, new float[]{0f, 0.15f, 0.3f, 0.45f}, 1.4f, 2.2f);
            case KEY: {
                float[] b = buf(0.03f);
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    b[i] = noise(r) * (float) Math.exp(-t * 400);
                }
                return norm(b, 0.3f);
            }
            case PRINT: {
                float[] b = buf(1.1f);
                for (int i = 0; i < b.length; i++) {
                    float t = i / (float) RATE;
                    float buzz = (float) Math.sin(t * 2 * Math.PI * 180) > 0 ? 1 : -1;
                    b[i] = (buzz * 0.3f + noise(r) * 0.2f) * (((int) (t * 30)) % 2 == 0 ? 1 : 0.5f) * Math.min(1, (1.1f - t) * 5);
                }
                return norm(b, 0.3f);
            }
            case FLASHED: return tones(new float[]{1046, 1568}, new float[]{0f, 0.14f}, 0.6f, 5f);
            case USB_IN: return tones(new float[]{740, 1108}, new float[]{0f, 0.1f}, 0.4f, 9f);
            case USB_OUT: return tones(new float[]{1108, 740}, new float[]{0f, 0.1f}, 0.4f, 9f);
            case ARMED: return tones(new float[]{880, 1760}, new float[]{0f, 0.18f}, 0.5f, 7f);
        }
        return buf(0.05f);
    }

    private static float[] tones(float[] f, float[] st, float len, float decay) {
        float[] b = buf(len);
        for (int k = 0; k < f.length; k++) {
            int o = (int) (st[k] * RATE);
            for (int i = o; i < b.length; i++) {
                float t = (i - o) / (float) RATE;
                b[i] += (float) ((Math.sin(t * 2 * Math.PI * f[k]) + 0.25 * Math.sin(t * 4 * Math.PI * f[k])) * Math.exp(-t * decay) * Math.min(1, t * 400));
            }
        }
        return norm(b, 0.5f);
    }

    private static float[] buf(float sec) {
        return new float[(int) (sec * RATE)];
    }

    private static float a(float fc) {
        return (float) (1 - Math.exp(-2 * Math.PI * fc / RATE));
    }

    private static float noise(Random r) {
        return r.nextFloat() * 2f - 1f;
    }

    private static float[] norm(float[] b, float peak) {
        float m = 1e-6f;
        for (float v : b) m = Math.max(m, Math.abs(v));
        float k = peak / m;
        int fade = Math.min(b.length / 4, 200);
        for (int i = 0; i < b.length; i++) {
            b[i] *= k;
            if (i >= b.length - fade) b[i] *= (b.length - i) / (float) fade;
        }
        return b;
    }

    private static void writeWav(File f, float[] s) throws IOException {
        int n = s.length;
        byte[] d = new byte[44 + n * 2];
        put(d, 0, "RIFF");
        int32(d, 4, 36 + n * 2);
        put(d, 8, "WAVEfmt ");
        int32(d, 16, 16);
        int16(d, 20, 1);
        int16(d, 22, 1);
        int32(d, 24, RATE);
        int32(d, 28, RATE * 2);
        int16(d, 32, 2);
        int16(d, 34, 16);
        put(d, 36, "data");
        int32(d, 40, n * 2);
        for (int i = 0; i < n; i++) {
            int v = (int) (Math.max(-1f, Math.min(1f, s[i])) * 32767);
            d[44 + i * 2] = (byte) v;
            d[45 + i * 2] = (byte) (v >> 8);
        }
        File tmp = new File(f.getPath() + ".tmp");
        FileOutputStream o = new FileOutputStream(tmp);
        try {
            o.write(d);
        } finally {
            o.close();
        }
        if (!tmp.renameTo(f)) throw new IOException("rename");
    }

    private static void put(byte[] d, int o, String s) {
        for (int i = 0; i < s.length(); i++) d[o + i] = (byte) s.charAt(i);
    }

    private static void int32(byte[] d, int o, int v) {
        d[o] = (byte) v; d[o + 1] = (byte) (v >> 8); d[o + 2] = (byte) (v >> 16); d[o + 3] = (byte) (v >> 24);
    }

    private static void int16(byte[] d, int o, int v) {
        d[o] = (byte) v; d[o + 1] = (byte) (v >> 8);
    }
}
