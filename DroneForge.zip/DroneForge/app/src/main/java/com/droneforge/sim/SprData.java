package com.droneforge.sim;

/** Generated: real-world size (mm) of every top-down sprite. */
final class SprData {
    private SprData() {}

    static float[] size(String n) {
        switch (n) {
            case "antenna": return new float[]{26.00f, 54.00f};
            case "bat4_1300": return new float[]{60.00f, 134.00f};
            case "bat6_1100": return new float[]{60.00f, 136.00f};
            case "bat6_4000": return new float[]{60.00f, 200.00f};
            case "cam": return new float[]{26.00f, 36.00f};
            case "cap": return new float[]{14.00f, 24.00f};
            case "closedbox": return new float[]{500.00f, 500.00f};
            case "frame3": return new float[]{169.00f, 169.00f};
            case "frame5": return new float[]{263.00f, 263.00f};
            case "frame7": return new float[]{337.00f, 337.00f};
            case "frametop3": return new float[]{40.00f, 84.00f};
            case "frametop5": return new float[]{52.00f, 138.00f};
            case "frametop7": return new float[]{56.00f, 160.00f};
            case "motor_1404_black": return new float[]{24.00f, 24.00f};
            case "motor_2207_blue": return new float[]{34.40f, 34.40f};
            case "motor_2207_purple": return new float[]{34.40f, 34.40f};
            case "motor_2207_red": return new float[]{34.40f, 34.40f};
            case "motor_2806_gold": return new float[]{39.00f, 39.00f};
            case "motorb_1404_black": return new float[]{22.00f, 22.00f};
            case "motorb_2207_blue": return new float[]{32.40f, 32.40f};
            case "motorb_2207_purple": return new float[]{32.40f, 32.40f};
            case "motorb_2207_red": return new float[]{32.40f, 32.40f};
            case "motorb_2806_gold": return new float[]{37.00f, 37.00f};
            case "openbox": return new float[]{500.00f, 500.00f};
            case "prop3": return new float[]{80.00f, 80.00f};
            case "prop5": return new float[]{133.00f, 133.00f};
            case "prop7": return new float[]{182.00f, 182.00f};
            case "rx": return new float[]{14.00f, 22.00f};
            case "vtx": return new float[]{34.00f, 36.00f};
            case "xt60": return new float[]{20.00f, 22.00f};
            default: return null;
        }
    }
}
