package com.droneforge.sim;

import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;

/** Title card over the workshop. */
final class TitleScreen extends Screen {
    private static final int B_CONT = 1, B_NEW = 2;
    private float t;

    TitleScreen(GameView v) {
        super(v);
    }

    @Override
    void update(float dt) {
        t += dt;
    }

    @Override
    void draw(Canvas c) {
        float s = Math.max((v.R - v.L) / 1600f, (v.Bm - v.T) / 720f) * (1.06f + 0.02f * (float) Math.sin(t * 0.3f));
        v.res.draw(c, "bg_front", 800 - 800 * s, 360 - 360 * s, 800 + 800 * s, 360 + 360 * s, 255);
        g.p.setShader(new LinearGradient(v.L, 0, 900, 0, 0xF20A0C10, 0x330A0C10, Shader.TileMode.CLAMP));
        c.drawRect(v.L, v.T, v.R, v.Bm, g.p);
        g.p.setShader(null);
        float x = v.L + 110;
        g.p.setColor(G.ORANGE);
        c.drawRect(x, 170, x + 10, 330, g.p);
        g.text(c, "DRONE", x + 34, 205, 92, G.TEXT, g.bold, Paint.Align.LEFT);
        g.text(c, "FORGE", x + 34, 290, 92, G.ORANGE, g.bold, Paint.Align.LEFT);
        g.text(c, "FPV WORKSHOP SIMULATOR", x + 38, 352, 26, G.DIM, g.bold, Paint.Align.LEFT);
        g.text(c, "Order parts. Solder. Flash. Bind. Test. Ship.", x + 38, 392, 22, G.DIM2, g.med, Paint.Align.LEFT);
        boolean hasSave = v.prefs.contains("save");
        float y = 450;
        if (hasSave) {
            g.button(c, B_CONT, x + 34, y, x + 354, y + 62, "CONTINUE", G.B_PRIMARY);
            y += 80;
            g.button(c, B_NEW, x + 34, y, x + 354, y + 54, "NEW CAREER", G.B_DARK);
        } else {
            g.button(c, B_NEW, x + 34, y, x + 354, y + 62, "START CAREER", G.B_PRIMARY);
        }
        g.text(c, "v1.0", v.R - 20, v.Bm - 20, 16, G.DIM2, g.mono, Paint.Align.RIGHT);
    }

    @Override
    void button(int id) {
        if (id == B_CONT) {
            v.sfx.play(Sfx.BOOT, 0.5f);
            v.go(v.room);
        } else if (id == B_NEW) {
            if (v.prefs.contains("save")) {
                v.dialog("START A NEW CAREER?", "Your current workshop, money and orders will be erased.", new String[]{"CANCEL", "ERASE & START"},
                        new int[]{G.B_DARK, G.B_DANGER}, new GameView.DialogCb() {
                            @Override
                            public void on(int i) {
                                if (i == 1) {
                                    v.newGame();
                                    v.go(v.room);
                                }
                            }
                        });
            } else {
                v.newGame();
                v.go(v.room);
            }
        }
    }
}
