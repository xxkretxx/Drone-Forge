package com.droneforge.sim;

import android.graphics.Canvas;
import android.graphics.Paint;

import java.util.Locale;

/** Opening a delivery: cut the tape with the box cutter, then store the parts. */
final class UnboxScreen extends Screen {
    private static final int B_SHELF = 1, B_BENCH = 2, B_BACK = 3;
    private Game.Delivery d;
    private final boolean[] cut = new boolean[40];
    private boolean opened;
    private float openT, cutterX = -1, cutterY;

    UnboxScreen(GameView v) {
        super(v);
    }

    void open(Game.Delivery del) {
        d = del;
        opened = false;
        openT = 0;
        for (int i = 0; i < cut.length; i++) cut[i] = false;
    }

    @Override
    void update(float dt) {
        if (opened) openT += dt;
    }

    private float boxCx() {
        return 640;
    }

    private float boxScale() {
        return 1.55f; // px per mm for the box sprite
    }

    @Override
    void draw(Canvas c) {
        float s = Math.max((v.R - v.L) / 1600f, (v.Bm - v.T) / 720f);
        v.res.draw(c, "bg_pack", 800 - 800 * s, 360 - 360 * s, 800 + 800 * s, 360 + 360 * s, 255);
        float cx = boxCx(), cy = 380, k = boxScale();
        if (!opened) {
            v.res.sprite(c, "closedbox", cx, cy, k, 0, 255, false);
            // tape line with cut progress
            float top = cy - 150 * k, bot = cy + 150 * k;
            for (int i = 0; i < cut.length; i++) {
                float y0 = top + (bot - top) * i / cut.length, y1 = top + (bot - top) * (i + 1) / cut.length;
                if (cut[i]) {
                    g.p.setShader(null);
                    g.p.setColor(0xFF2A1D10);
                    c.drawRect(cx - 3, y0, cx + 3, y1, g.p);
                }
            }
            g.s.setColor(G.alpha(G.ORANGE, 160 + (int) (80 * Math.sin(v.time * 5))));
            g.s.setStrokeWidth(2);
            c.drawLine(cx - 40, top, cx - 40, bot, g.s);
            c.drawLine(cx + 40, top, cx + 40, bot, g.s);
            if (cutterX >= 0) {
                c.save();
                c.rotate(-30, cutterX, cutterY);
                g.r.set(cutterX - 10, cutterY - 5, cutterX + 60, cutterY + 14);
                g.p.setColor(G.YELLOW);
                c.drawRoundRect(g.r, 5, 5, g.p);
                g.path.reset();
                g.path.moveTo(cutterX - 10, cutterY - 3);
                g.path.lineTo(cutterX - 34, cutterY + 4);
                g.path.lineTo(cutterX - 10, cutterY + 10);
                g.path.close();
                g.p.setColor(0xFFDDDDDD);
                c.drawPath(g.path, g.p);
                c.restore();
            }
            g.panel(c, 1060, 220, 1520, 420);
            g.text(c, "PARCEL FROM " + d.from.toUpperCase(Locale.US), 1290, 260, 24, G.ORANGE, g.bold, Paint.Align.CENTER);
            g.text(c, d.parts.size() + " items inside", 1290, 300, 22, G.TEXT, g.med, Paint.Align.CENTER);
            g.text(c, "Drag the box cutter along the tape", 1290, 350, 21, G.DIM, g.med, Paint.Align.CENTER);
            g.text(c, "to open the parcel.", 1290, 380, 21, G.DIM, g.med, Paint.Align.CENTER);
        } else {
            v.res.sprite(c, "openbox", cx, cy, k, 0, 255, false);
            int n = d.parts.size();
            int cols = 4;
            float cw = 120, ch = 110, x0 = 1000, y0 = 120;
            g.panelTitle(c, x0 - 30, y0 - 70, x0 + cols * cw + 30, 660, "CONTENTS");
            for (int i = 0; i < n; i++) {
                Parts.Part p = Parts.get(d.parts.get(i));
                float a = Math.min(1, Math.max(0, openT * 3 - i * 0.12f));
                float x = x0 + (i % cols) * cw + cw / 2, y = y0 + (i / cols) * ch + ch / 2 - 10 + (1 - a) * 30;
                v.res.fit(c, p.icon, x, y, cw - 14, ch - 34, (int) (255 * a));
                g.text(c, shortName(p), x, y + ch / 2 - 10, 14, G.alpha(G.DIM, (int) (255 * a)), g.bold, Paint.Align.CENTER);
            }
            g.button(c, B_SHELF, x0, 570, x0 + 230, 630, "STORE ON SHELF", G.B_PRIMARY);
            g.button(c, B_BENCH, x0 + 250, 570, x0 + cols * cw, 630, "ALL TO BENCH", G.B_DARK);
        }
        g.iconButton(c, B_BACK, v.L + 50, v.T + 110, 30, G.I_LEFT, G.TEXT);
        v.drawHud(c, false);
    }

    private static String shortName(Parts.Part p) {
        String n = p.name;
        return n.length() > 16 ? n.substring(0, 15) + "…" : n;
    }

    @Override
    void touch(int action, float x, float y, int id) {
        if (opened || id > 0) return;
        float cx = boxCx(), k = boxScale();
        float top = 380 - 150 * k, bot = 380 + 150 * k;
        if (action == 0 || action == 1) {
            cutterX = x;
            cutterY = y;
            if (Math.abs(x - cx) < 40 && y >= top && y <= bot) {
                int i = (int) ((y - top) / (bot - top) * cut.length);
                if (i >= 0 && i < cut.length && !cut[i]) {
                    cut[i] = true;
                    if (i % 4 == 0) v.sfx.play(Sfx.CUT, 0.5f);
                }
                int n = 0;
                for (boolean b : cut) if (b) n++;
                if (n >= cut.length * 0.85f) {
                    opened = true;
                    openT = 0;
                    v.sfx.play(Sfx.TAPE, 0.8f);
                    v.vibrate(30);
                }
            }
        } else cutterX = -1;
    }

    private void unpack(int loc) {
        for (String s : d.parts) v.game.addItem(s, loc);
        d.state = 2;
        v.sfx.play(Sfx.PLACE, 0.8f);
        v.toast(d.parts.size() + " PARTS " + (loc == Game.L_SHELF ? "STORED ON THE SHELF (TURN LEFT)" : "PUT ON THE BENCH"), G.GREEN);
        v.save();
        v.room.view = RoomScreen.V_BACK;
        v.go(v.room);
    }

    @Override
    void button(int id) {
        if (id == B_SHELF) unpack(Game.L_SHELF);
        else if (id == B_BENCH) unpack(Game.L_BENCH);
        else if (id == B_BACK) back();
    }

    @Override
    boolean back() {
        v.go(v.room);
        return true;
    }
}
